--
-- PostgreSQL database dump
--

\restrict bFE5qkyyZVj22O9Tnae0bvkkDH9rcgCan5kjOKE6E6F5wew0f3vPiXKmDcc04d7

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: graphv3; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA graphv3;


ALTER SCHEMA graphv3 OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: 11_succession; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."11_succession" (
    id_mo numeric(6,0) NOT NULL,
    succession numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."11_succession" OWNER TO postgres;

--
-- Name: 12_amalgamation; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."12_amalgamation" (
    id_mo numeric(6,0) NOT NULL,
    amalgamation numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."12_amalgamation" OWNER TO postgres;

--
-- Name: 13_new_distribution_area; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."13_new_distribution_area" (
    id_mo numeric(6,0) NOT NULL,
    new_distribution_area numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."13_new_distribution_area" OWNER TO postgres;

--
-- Name: 14_new_sector; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."14_new_sector" (
    id_mo numeric(6,0) NOT NULL,
    new_sector numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."14_new_sector" OWNER TO postgres;

--
-- Name: 19_interruption; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."19_interruption" (
    id_mo numeric(6,0) NOT NULL,
    interruption numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."19_interruption" OWNER TO postgres;

--
-- Name: 21_split_off; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."21_split_off" (
    id_mo numeric(6,0) NOT NULL,
    split_off numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."21_split_off" OWNER TO postgres;

--
-- Name: 22_offshoot; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."22_offshoot" (
    id_mo numeric(6,0) NOT NULL,
    offshoot numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."22_offshoot" OWNER TO postgres;

--
-- Name: 23_merger; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."23_merger" (
    id_mo numeric(6,0) NOT NULL,
    merger numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."23_merger" OWNER TO postgres;

--
-- Name: 31_main_media_outlet; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."31_main_media_outlet" (
    id_mo numeric(6,0) NOT NULL,
    main_media_outlet numeric(6,0) NOT NULL,
    start_rel date NOT NULL,
    end_rel date NOT NULL
);


ALTER TABLE graphv3."31_main_media_outlet" OWNER TO postgres;

--
-- Name: 33_umbrella; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."33_umbrella" (
    id_mo numeric(6,0) NOT NULL,
    umbrella numeric(6,0) NOT NULL,
    start_rel date NOT NULL,
    end_rel date NOT NULL
);


ALTER TABLE graphv3."33_umbrella" OWNER TO postgres;

--
-- Name: 34_collaboration; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."34_collaboration" (
    id_mo numeric(6,0) NOT NULL,
    collaboration numeric(6,0) NOT NULL,
    start_rel date NOT NULL,
    end_rel date NOT NULL
);


ALTER TABLE graphv3."34_collaboration" OWNER TO postgres;

--
-- Name: mo_constant; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.mo_constant (
    id_mo numeric(6,0) NOT NULL,
    mo_title character varying(120) NOT NULL,
    id_sector numeric(2,0) NOT NULL,
    mandate numeric(2,0) NOT NULL,
    location character varying(25) NOT NULL,
    primary_distr_area numeric(2,0) NOT NULL,
    local numeric(1,0) NOT NULL,
    language character varying(25) NOT NULL,
    start_date date NOT NULL,
    start_fake_date numeric(1,0) NOT NULL,
    end_date date NOT NULL,
    end_fake_date numeric(1,0) NOT NULL,
    editorial_line_s character varying(1800) NOT NULL,
    editorial_line_e character varying(250) NOT NULL,
    comments character varying(1000) NOT NULL
);


ALTER TABLE graphv3.mo_constant OWNER TO postgres;

--
-- Name: mo_year; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.mo_year (
    id_mo numeric(6,0) NOT NULL,
    year date NOT NULL,
    mo_year numeric(10,0) NOT NULL,
    calc integer NOT NULL,
    circulation numeric(7,0) NOT NULL,
    circulation_source numeric(7,0) NOT NULL,
    unique_users numeric(8,0) NOT NULL,
    unique_users_source numeric(7,0) NOT NULL,
    reach_nat numeric(3,1) NOT NULL,
    reach_nat_source numeric(7,0) NOT NULL,
    reach_reg numeric(3,1) NOT NULL,
    reach_reg_source numeric(7,0) NOT NULL,
    market_share numeric(3,1) NOT NULL,
    market_share_source numeric(7,0) NOT NULL,
    comments character varying(1000) NOT NULL
);


ALTER TABLE graphv3.mo_year OWNER TO postgres;

--
-- Name: nd_company; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.nd_company (
    nd_id text NOT NULL,
    name character varying(300) NOT NULL,
    legal_form character varying(50),
    registry_id character varying(100),
    jurisdiction character varying(5) DEFAULT 'DE'::character varying NOT NULL,
    northdata_url text,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    is_media_company boolean DEFAULT false NOT NULL,
    sector character varying(50),
    region character varying(50),
    scraped_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE graphv3.nd_company OWNER TO postgres;

--
-- Name: nd_crawl_log; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.nd_crawl_log (
    id bigint NOT NULL,
    url text NOT NULL,
    company_name character varying(300),
    slice_id character varying(50),
    nodes_found integer DEFAULT 0 NOT NULL,
    edges_found integer DEFAULT 0 NOT NULL,
    svg_bytes integer DEFAULT 0 NOT NULL,
    success boolean DEFAULT false NOT NULL,
    error_msg text,
    duration_ms integer,
    crawled_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE graphv3.nd_crawl_log OWNER TO postgres;

--
-- Name: nd_crawl_log_id_seq; Type: SEQUENCE; Schema: graphv3; Owner: postgres
--

CREATE SEQUENCE graphv3.nd_crawl_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE graphv3.nd_crawl_log_id_seq OWNER TO postgres;

--
-- Name: nd_crawl_log_id_seq; Type: SEQUENCE OWNED BY; Schema: graphv3; Owner: postgres
--

ALTER SEQUENCE graphv3.nd_crawl_log_id_seq OWNED BY graphv3.nd_crawl_log.id;


--
-- Name: nd_ownership; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.nd_ownership (
    id bigint NOT NULL,
    owner_company_id text,
    owner_person_id text,
    owned_company_id text NOT NULL,
    share_pct real,
    role character varying(200),
    is_current boolean DEFAULT true NOT NULL,
    source_url text,
    scraped_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE graphv3.nd_ownership OWNER TO postgres;

--
-- Name: nd_ownership_id_seq; Type: SEQUENCE; Schema: graphv3; Owner: postgres
--

CREATE SEQUENCE graphv3.nd_ownership_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE graphv3.nd_ownership_id_seq OWNER TO postgres;

--
-- Name: nd_ownership_id_seq; Type: SEQUENCE OWNED BY; Schema: graphv3; Owner: postgres
--

ALTER SEQUENCE graphv3.nd_ownership_id_seq OWNED BY graphv3.nd_ownership.id;


--
-- Name: nd_person; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.nd_person (
    nd_id text NOT NULL,
    full_name character varying(200) NOT NULL,
    scraped_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE graphv3.nd_person OWNER TO postgres;

--
-- Name: sources_names; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.sources_names (
    id_source numeric(7,0) NOT NULL,
    source_name character varying(250) NOT NULL
);


ALTER TABLE graphv3.sources_names OWNER TO postgres;

--
-- Name: nd_crawl_log id; Type: DEFAULT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_crawl_log ALTER COLUMN id SET DEFAULT nextval('graphv3.nd_crawl_log_id_seq'::regclass);


--
-- Name: nd_ownership id; Type: DEFAULT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_ownership ALTER COLUMN id SET DEFAULT nextval('graphv3.nd_ownership_id_seq'::regclass);


--
-- Data for Name: 11_succession; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."11_succession" (id_mo, succession) FROM stdin;
100421	100750
100700	104100
100750	100821
100821	100422
100900	115100
101101	116030
101460	107310
101470	105850
101900	102500
102700	101800
103701	112700
103702	110831
104100	104200
106400	106500
106670	100103
106750	101250
106751	101251
106850	104830
106851	104831
106930	108370
107110	106930
108100	102200
108200	102000
108350	103701
108480	111480
109001	116040
109172	109173
109800	109500
110100	114300
110601	108100
110700	108200
110831	106850
111700	109800
111800	105700
111920	107020
112300	101900
112750	107250
116030	101102
116040	116050
116050	116060
116060	116070
116070	109002
119090	116080
120320	120160
123190	140210
123190	120180
123330	140350
123710	120700
130070	130122
130071	130072
130111	130310
130121	131100
130310	130112
130340	130180
130460	130962
130480	130111
130951	130952
130952	130953
130961	131030
131030	130460
131100	130070
140022	140300
140300	140400
140350	140180
144500	107110
150070	150912
150282	150530
150361	156370
150362	150180
150491	150492
150492	150493
150530	152280
150560	150290
150571	150572
150572	150775
150660	150680
150700	150630
150710	150630
150771	150772
150772	150773
150774	150571
150790	150010
150880	150361
151280	150282
151281	151282
151282	151283
156370	150362
160020	150771
160061	160641
160380	160200
160520	160780
160600	160740
160631	160632
160632	160633
160633	160910
160641	160642
160642	160520
160662	160665
160740	181610
170008	170070
170070	170420
170390	170220
170621	170622
170680	170720
170811	170812
171041	171042
171042	171043
180031	180830
180061	180480
180400	180200
180430	189931
180480	180062
180830	180032
180851	180451
180860	180430
180971	180120
180972	180031
186010	186020
186030	186040
189931	180920
189931	190940
190040	190980
190123	191990
190410	190200
190820	190440
191000	190820
191020	190040
191990	191980
604100	604101
611201	601201
653280	650911
670151	170152
670631	670632
681832	683830
690121	690122
690122	690123
300011	300012
300012	300013
300021	300022
300030	300040
300030	300050
300049	300050
300200	300210
300220	300231
300231	300232
300232	300233
300251	300252
300270	300271
300280	300281
300290	300291
300310	300320
300391	300392
300400	300401
300570	300571
300581	300582
300700	300710
300743	303743
300747	301747
300750	300760
300760	300770
300760	300970
300822	300820
301746	300746
302744	300744
350010	350011
350020	350021
450551	450552
460621	460622
480871	480872
200035	200036
200051	200052
200052	200053
109173	116120
174001	196001
151001	113101
130348	130188
670560	670561
101202	106751
101200	106750
150530	150531
107250	104851
112750	612750
107210	607211
140140	140141
104602	104603
101153	101154
101152	101153
101151	101152
101150	101151
104500	105600
104600	104700
100103	110700
101154	101155
100200	106000
\.


--
-- Data for Name: 12_amalgamation; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."12_amalgamation" (id_mo, amalgamation) FROM stdin;
101102	112300
107020	102770
107310	102770
170633	170640
181610	160750
183830	189060
609002	112300
670623	170640
191980	189060
104700	104800
104601	104800
104302	104800
112700	104800
\.


--
-- Data for Name: 13_new_distribution_area; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."13_new_distribution_area" (id_mo, new_distribution_area) FROM stdin;
109792	609793
111920	171051
609792	109792
109794	609794
109791	609792
\.


--
-- Data for Name: 14_new_sector; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."14_new_sector" (id_mo, new_sector) FROM stdin;
101380	601380
105700	605700
109002	609002
116110	616112
150741	650741
150911	650912
153280	653280
160231	660231
160661	660661
170623	670623
170631	670631
190121	690124
190122	690125
601201	101201
609001	109001
609791	109791
616111	116110
650741	150742
650911	150911
660020	160020
660231	160232
660600	160600
660652	160653
660661	160662
666010	166010
670331	170331
670621	170621
670632	170632
670680	170680
676030	176030
680061	180061
680971	180971
681831	181830
683830	183830
690123	190121
690124	190122
690125	190123
200081	200082
616120	116120
170560	670560
670559	170560
670300	170300
651283	151283
181830	681832
189060	681833
109793	109794
630480	130480
641041	171041
\.


--
-- Data for Name: 19_interruption; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."19_interruption" (id_mo, interruption) FROM stdin;
100101	100102
100102	106670
100103	100104
101201	101202
104601	104602
109500	108480
114501	114502
130151	130152
140021	140022
150270	150220
150282	150283
150773	150774
160652	660652
166010	160061
170151	670151
170622	170623
170812	670680
171051	171052
176030	170500
180120	180972
180251	180252
191011	191012
199990	190990
650701	650702
300070	300080
106800	609180
109171	109172
170632	170633
160750	160661
103701	103702
170331	170332
631480	630480
\.


--
-- Data for Name: 21_split_off; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."21_split_off" (id_mo, split_off) FROM stdin;
109172	106800
\.


--
-- Data for Name: 22_offshoot; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."22_offshoot" (id_mo, offshoot) FROM stdin;
104850	300760
604101	100700
609180	109180
650701	150700
150550	350011
300010	300060
300233	300240
300291	300300
300430	300470
300500	300060
300500	300480
300500	300490
300500	300501
300510	300060
300510	300480
300510	300490
300600	300601
103680	403680
104850	400290
104850	404850
108240	408240
109180	409180
109850	409850
114502	414502
150550	450551
150550	450552
170150	470150
190990	490990
400640	300640
400780	300780
490980	390980
104830	400780
103680	410010
404830	106850
108240	300790
\.


--
-- Data for Name: 23_merger; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."23_merger" (id_mo, merger) FROM stdin;
200060	200070
102770	110831
180062	183830
186040	186010
660220	160020
676040	176030
109172	116120
176001	177001
106800	177001
\.


--
-- Data for Name: 31_main_media_outlet; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."31_main_media_outlet" (id_mo, main_media_outlet, start_rel, end_rel) FROM stdin;
100200	114300	1933-09-21	1933-10-21
100300	113900	1935-04-02	1938-07-30
100421	102770	1960-09-29	1960-10-28
100422	102770	1962-05-15	1970-11-26
100600	105700	1932-11-02	1932-11-25
100750	109180	1960-10-31	1961-02-24
100800	110001	1928-03-23	1928-09-30
100821	109180	1961-02-27	1961-10-13
100900	107200	1933-05-31	1933-09-13
101300	101201	1914-09-17	1919-05-17
101800	102200	1938-03-22	1938-07-30
102000	102200	1938-03-18	1938-09-15
102400	102500	1923-02-05	1924-01-31
102700	110601	1934-02-19	1938-03-11
103000	111800	1931-06-23	1931-10-01
104900	111800	1930-05-18	1930-07-23
106000	114300	1933-10-23	1933-11-11
106400	100700	1933-04-05	1933-04-29
106400	104100	1933-06-20	1933-06-19
108200	108100	1938-03-14	1938-03-17
108350	116120	1900-01-02	1904-12-15
109181	109180	1948-10-19	9999-01-01
109860	109850	2013-02-26	9999-01-01
110001	110100	1928-11-06	1930-06-29
110001	114300	1930-07-01	1932-01-03
110601	100103	1932-04-18	1934-02-16
110700	110601	1934-02-17	1938-03-11
112100	114501	1982-06-12	1989-11-30
114503	114502	1945-09-21	2023-06-30
114601	114600	1995-06-10	2016-09-02
115100	107200	1933-09-14	1934-01-12
116010	109173	1896-02-02	1896-10-31
116020	109173	1896-02-02	1896-10-31
116100	101201	1900-10-27	1903-12-31
120700	170720	1970-11-20	1971-03-11
123510	107210	1970-07-22	1970-12-03
123710	170720	1971-03-12	1987-03-31
130151	170151	1937-07-01	1945-04-01
130580	160590	1950-01-19	1950-04-21
130952	171042	1952-05-01	1971-01-31
140540	150282	1971-04-05	1974-09-27
150010	160590	1949-12-01	1950-03-20
150290	150550	1948-02-02	1948-09-30
150560	150550	1947-05-05	1948-01-31
150610	160620	1957-01-01	1958-11-28
150680	150912	1938-08-01	1938-12-31
150720	150912	1938-09-01	1938-12-30
150772	101201	1932-10-18	1933-06-30
150790	160590	1949-09-15	1949-10-22
150880	110831	1968-05-16	1972-08-31
160061	150774	1951-01-02	1972-07-31
160632	150492	1950-07-01	1957-07-01
160641	150571	1975-11-28	1984-08-31
160641	150744	1972-08-01	1975-11-27
160641	150774	1972-08-01	1975-11-27
160662	130460	1982-06-12	1985-02-28
160662	130961	1971-11-03	1974-04-12
160662	131030	1974-04-13	1982-06-11
170050	170633	1949-12-10	1953-08-29
170332	170633	1949-05-14	1961-12-30
171052	111920	1952-09-01	1957-02-28
176020	109180	2003-02-28	2005-12-31
180430	190440	1950-06-01	1956-12-29
180451	130961	1973-05-26	1974-04-12
181910	181900	2006-06-26	2007-10-16
189931	108480	1957-01-01	1957-02-20
190820	180860	1945-11-20	1950-05-31
191000	180860	1945-11-16	9145-11-19
191020	180972	1945-11-15	1957-02-28
191980	183830	1940-07-09	1944-08-29
300070	300022	1997-01-01	2008-06-07
300080	300022	2004-07-05	9999-01-01
300070	300030	1997-01-01	2000-12-31
302747	301747	2019-01-01	9999-01-01
400820	300821	1998-01-01	9999-01-01
200053	200020	2003-07-01	2009-12-31
200082	200020	2009-01-01	9999-01-01
200085	200081	1999-04-26	2002-12-31
200086	200081	2000-01-01	2002-10-26
200090	200020	2003-01-01	2011-04-30
196001	177001	1938-10-06	1939-05-20
151001	177001	1936-11-03	1938-09-30
174001	177001	1868-12-26	1938-09-30
140838	104831	2003-01-10	9999-01-01
140140	104602	1960-01-01	1962-09-30
140141	104603	1962-10-02	1966-10-21
180830	101200	1862-02-01	1868-04-02
180451	131030	1974-04-13	1982-06-11
180451	130460	1982-06-12	1989-11-30
180451	130962	1989-12-01	1990-01-31
180851	130961	1971-10-16	1973-05-25
118002	118001	1920-07-01	1943-12-31
104700	101155	1918-11-14	1944-08-31
104600	101154	1905-04-01	1918-11-13
104500	101154	1893-12-31	1905-03-31
\.


--
-- Data for Name: 33_umbrella; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."33_umbrella" (id_mo, umbrella, start_rel, end_rel) FROM stdin;
101251	101250	1989-12-12	1991-10-31
103681	103680	2004-09-06	9999-01-01
103682	103680	2006-06-12	2007-07-06
103683	103680	2006-08-28	9999-01-01
103684	103680	2006-05-15	9999-01-01
104831	104830	2000-11-02	9999-01-01
104851	104850	1959-06-15	9999-01-01
106751	106750	1987-06-03	1989-12-11
106851	106850	1972-09-01	2000-10-31
108241	108240	2006-09-01	9999-01-01
108251	108250	2018-08-29	9999-01-01
110081	110080	1993-02-01	1999-01-03
111481	111480	1957-02-21	1991-03-03
120160	104830	2000-11-02	9999-01-01
120180	104850	1978-03-01	9999-01-01
120320	106850	1986-04-06	2000-10-31
120730	110080	1993-06-04	1999-01-03
123190	104850	1973-10-02	1978-02-28
123330	106850	1977-11-18	1986-04-05
130152	170150	1948-10-31	9999-01-01
130180	104830	2000-11-02	9999-01-01
130200	104850	1991-01-12	1993-04-19
130340	106850	1983-11-06	2000-10-31
138250	108250	2018-08-29	2019-11-29
140180	104830	2000-11-02	9999-01-01
140210	104850	1978-03-01	9999-01-01
140300	106750	1985-10-16	1989-12-11
140350	106850	1986-04-06	2000-10-31
140400	101250	1989-12-12	1991-10-31
140740	110080	1992-08-11	1999-01-03
150180	104830	2000-11-02	9999-01-01
150220	104850	1992-08-29	9999-01-01
150270	104850	1961-11-18	1962-03-03
150361	106850	1972-09-01	1974-08-31
150362	106850	1974-12-31	2000-10-31
150493	108480	1946-01-04	1957-02-20
150493	111480	1957-02-21	2001-04-29
150572	106750	1987-06-02	1989-12-11
150750	110080	1992-09-15	1999-01-03
150775	101250	1989-12-12	1991-10-31
156370	106850	1974-09-01	1974-12-30
158240	108240	2006-09-01	9999-01-01
158250	108250	2018-08-29	9999-01-01
160200	104830	2000-11-02	9999-01-01
160231	104850	1976-06-01	1977-09-10
160232	104850	1992-08-29	1993-04-19
160380	106850	1975-01-01	2000-10-31
160520	106750	1985-10-16	1989-12-11
160621	160629	1989-03-01	9999-01-01
160633	111480	1957-07-02	1963-12-31
160780	101250	1989-12-12	1990-10-20
160910	111480	1964-01-01	1975-10-31
168240	108240	2007-03-04	2021-12-31
170152	170150	1948-10-01	9999-01-01
170220	104830	2000-11-02	9999-01-01
170240	104850	1987-04-03	1993-04-19
170390	106850	1972-10-01	2000-10-21
170760	110080	1992-10-11	1999-01-03
171043	111480	1971-02-02	1989-12-31
178250	108250	2018-08-29	2021-12-31
180200	104830	2000-11-02	9999-01-01
180251	104850	1976-06-01	1977-09-10
180252	104850	1983-11-11	2012-12-31
180400	106850	1992-09-13	2000-10-31
180870	182870	2008-05-15	9999-01-01
180920	111480	1957-07-03	1963-05-31
189931	111480	1957-02-21	1957-07-02
190200	104830	2000-11-02	9999-01-01
190260	104850	1983-11-11	1993-04-19
190410	106850	1988-03-06	2000-10-31
190940	111480	1957-07-03	1960-11-30
119850	109850	1988-10-19	9999-01-01
300770	104850	2023-02-01	9999-01-01
300520	200500	2012-01-01	9999-01-01
300012	300010	1961-09-11	1992-10-25
300013	300010	1992-10-26	9999-01-01
300021	300010	1961-09-11	1992-10-25
300022	300010	1992-10-26	9999-01-01
300030	300010	1997-10-01	2011-10-25
300040	300010	2011-10-26	9999-01-01
300049	300010	2006-05-01	2011-10-25
300050	300010	2011-10-26	9999-01-01
300600	300520	2012-01-01	9999-01-01
300741	300740	2005-03-10	9999-01-01
300742	300740	1999-01-01	9999-01-01
300743	300740	2001-01-01	2022-11-01
300744	300740	2001-01-01	9999-01-01
300745	300740	2009-11-04	9999-01-01
300746	300740	2011-01-01	9999-01-01
300760	300740	2011-01-01	9999-01-01
300970	300740	2012-02-01	2023-02-01
301747	300740	2014-01-02	9999-01-01
303743	300740	2022-11-01	9999-01-01
390982	300740	2007-01-01	9999-01-01
300010	923400	1961-09-11	9999-01-01
300011	923400	1955-08-01	1961-09-10
409851	409850	1995-02-02	9999-01-01
409852	409850	2000-01-01	9999-01-01
409853	409850	2010-01-01	9999-01-01
409854	409850	1998-01-01	9999-01-01
400013	923400	1997-07-24	9999-01-01
200018	923400	1967-10-01	9999-01-01
200020	200018	1967-10-01	9999-01-01
200035	200018	1967-10-01	1990-05-01
200036	200018	1990-05-02	9999-01-01
200041	200018	1967-10-01	9999-01-01
200051	200018	1955-01-01	1985-12-31
200052	200018	1985-01-01	2003-06-30
200060	200018	1979-08-23	2000-01-31
200070	200018	1995-01-16	9999-01-01
200081	200018	1997-03-21	2008-12-31
200135	200036	1990-05-02	9999-01-01
200235	200036	1990-05-02	9999-01-01
200335	200036	1990-05-02	9999-01-01
200435	200036	1990-05-02	9999-01-01
200535	200036	1990-05-02	9999-01-01
200635	200036	1990-05-02	9999-01-01
200735	200036	1990-05-02	9999-01-01
200835	200036	1990-05-02	9999-01-01
200935	200036	1990-05-02	9999-01-01
400161	400160	1999-01-01	9999-01-01
400162	400160	1999-01-01	9999-01-01
400181	400180	1997-01-01	9999-01-01
400182	400180	1997-01-01	9999-01-01
400371	400370	1998-01-01	9999-01-01
400372	400370	1998-01-01	9999-01-01
400373	400370	1998-01-01	9999-01-01
400374	400370	1998-01-01	9999-01-01
400375	400370	1998-01-01	9999-01-01
400376	400370	1998-01-01	9999-01-01
400377	400370	1998-01-01	9999-01-01
400378	400370	1998-01-01	9999-01-01
400379	400370	1998-01-01	9999-01-01
101202	101200	1948-04-01	1985-10-15
140021	101200	1948-04-01	1948-06-04
140022	101200	1957-01-03	1985-10-15
160642	101200	1984-09-01	1985-10-15
180031	101200	1957-03-01	1962-01-31
180032	101200	1968-04-03	1971-06-30
190040	101200	1957-03-01	1962-01-31
190980	101200	1962-02-01	1968-04-02
108480	108481	1945-08-05	1957-02-20
160620	160629	1989-03-01	9999-01-01
140901	108481	1948-05-05	1948-05-05
140901	111480	1957-02-21	1967-05-07
130953	111480	1971-02-02	1989-12-31
108240	108259	2018-08-29	0999-09-09
108250	108259	2018-08-29	0999-09-09
\.


--
-- Data for Name: 34_collaboration; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3."34_collaboration" (id_mo, collaboration, start_rel, end_rel) FROM stdin;
160668	150530	1993-06-01	2014-07-07
170152	300560	2022-03-15	9999-01-01
300233	300260	2019-09-01	9999-01-01
300251	300271	2005-08-29	2008-01-27
300252	300271	2008-01-28	9999-01-01
300251	300281	2005-08-29	2008-01-27
300252	300281	2008-01-28	9999-01-01
300251	300291	2005-08-29	2007-10-31
300233	300352	2017-04-06	2022-12-31
300240	300352	2017-04-06	2022-12-31
300260	300352	2019-09-01	2022-12-31
300450	300460	2008-10-28	2021-06-01
300010	300490	1984-12-01	9999-01-01
300010	300501	2014-06-29	9999-01-01
300010	300601	2000-06-01	2014-06-28
301744	300744	2001-01-01	9999-01-01
300743	301743	2001-01-01	2022-11-01
303743	301743	2022-11-01	9999-01-01
300743	302743	2010-01-01	2022-11-01
301743	302743	2010-01-01	9999-01-01
300743	320010	2021-09-01	2022-11-01
200020	200081	2009-01-01	9999-01-01
200052	200081	1999-04-26	2002-12-31
200335	230010	2001-06-01	9999-01-01
200735	230010	2012-05-21	9999-01-01
200135	200035	1967-10-01	1990-05-01
200235	200035	1967-10-01	1990-05-01
200335	200035	1967-10-01	1990-05-01
200435	200035	1967-10-01	1990-05-01
200535	200035	1967-10-01	1990-05-01
200635	200035	1967-10-01	1990-05-01
200735	200035	1967-10-01	1990-05-01
200835	200035	1967-10-01	1990-05-01
200935	200035	1967-10-01	1990-05-01
181900	170152	2004-09-25	2008-03-31
190470	170152	1975-05-31	9999-01-01
300260	300252	2023-01-01	9999-01-01
300240	300252	2023-01-01	9999-01-01
300233	300252	2023-01-01	9999-01-01
180870	182870	2008-05-15	9999-01-01
190990	192990	2004-01-01	9999-01-01
190470	192990	2004-01-01	9999-01-01
158240	158259	2006-09-29	9999-01-01
158250	158259	2018-08-29	9999-01-01
108241	108258	2018-08-29	9999-01-01
108251	108258	2018-08-29	9999-01-01
181870	182870	2008-05-15	9999-01-01
\.


--
-- Data for Name: mo_constant; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3.mo_constant (id_mo, mo_title, id_sector, mandate, location, primary_distr_area, local, language, start_date, start_fake_date, end_date, end_fake_date, editorial_line_s, editorial_line_e, comments) FROM stdin;
100101	Abend, Der [1]	11	2	Wien	11	0	deutsch	1915-06-14	9	1917-02-20	9	KA	KA	21.02.1917-06.03.1917 aus Zensurgründen nicht erschienen
100102	Abend, Der [2]	11	2	Wien	11	0	deutsch	1917-03-07	9	1918-03-18	9	KA	KA	19.03.1918-31.05.1918 polizeilich verboten
100103	Abend, Der [3]	11	2	Wien	11	0	deutsch	1918-10-31	9	1934-02-16	9	KA	KA	KA
100200	AbendAusgabe	11	2	Wien	11	0	deutsch	1933-09-21	9	1933-10-21	9	KA	KA	KA
100300	Abendausgabe	11	2	Wien	11	0	deutsch	1935-04-02	9	1938-07-30	9	KA	KA	Hervorgegangen aus der seit 20.02.1934 erschienenen Abendausgabe von > 113900 Wiener Neueste Nachrichten
100400	Abend-Express	11	2	Wien	11	0	deutsch	1933-01-04	9	1933-01-07	9	KA	KA	KA
100500	Abendfunk, Der	11	2	Wien	11	0	deutsch	1933-06-20	9	1933-07-01	9	KA	KA	KA
100600	Abendpost	11	2	Wien	11	0	deutsch	1932-11-02	9	1932-11-25	9	KA	KA	KA
100700	Abendpost, Die	11	4	Wien	11	0	deutsch	1933-04-18	9	1933-04-29	9	KA	KA	KA
100750	Abend-Presse	11	2	Wien	11	0	deutsch	1960-10-31	9	1961-02-24	9	KA	KA	KA
100800	Abendzeitung	11	2	Wien	11	0	deutsch	1928-03-23	9	1928-09-30	9	KA	KA	KA
100821	Abend-Zeitung	11	2	Wien	11	0	deutsch	1961-02-27	9	1962-05-11	9	KA	KA	Die Abend-Zeitung bezeichnet sich ab 14.10.1961 nicht mehr als Abendausgabe der > 109180 Presse. Sie und die Presse wurden an zwei unterschiedliche Eigentümer verkauft, die jedoch personell verbunden waren, vgl. Zeitungs-Verlag und Zeitschriften-Verlag 59(1962), S. 784.
100900	Acht-Uhr-Blatt	11	2	Wien	11	0	deutsch	1933-05-31	9	1933-09-13	9	KA	KA	KA
101000	Adler, Der	11	2	Wien	11	0	deutsch	1933-07-07	9	1933-07-25	9	KA	KA	KA
101101	Alldeutsches Tagblatt	11	4	Wien	11	0	deutsch	1903-04-01	9	1914-08-08	9	KA	KA	KA
101102	Alldeutsches Tagblatt 	11	4	Wien	11	0	deutsch	1917-06-01	9	1920-06-15	9	KA	KA	Zusammengelegt mit > 109001 Ostdeutsche Rundschau zu > 112300 Wiener Deutsche Tageszeitung                   
101201	Arbeiter-Zeitung 	11	4	Wien	11	0	deutsch	1893-10-31	9	1934-02-12	9	KA	KA	25.02.1934 - 15.03.1938 als Wochenzeitung bzw. 2 mal monatlich im Exil in Brünn, Paris und Böhmisch-Trübau und ab Herbst 1937 illegal in Wien erschienen
101251	AZ -Ausgabe für Wien	11	4	Wien	11	0	deutsch	1989-12-12	9	1991-10-31	9	KA	KA	KA
101300	AZ am Abend	11	4	Wien	11	0	deutsch	1914-09-17	9	1919-05-17	9	KA	KA	Bis 29.04.1922 zweite Ausgabe der > 101201 Arbeiter-Zeitung
101380	Bécsi Magyar Híradó 	11	4	Wien	11	0	ungarisch	1957-01-11	9	1957-07-12	9	KA	KA	KA
101450	Bild-Telegraf	11	3	Wien	11	0	deutsch	1954-04-03	9	1958-07-23	9	KA	KA	13.03.1958 - 16.03.1958 infolge des ersten Wiener Zeitungskrieges nicht erschienen.
101460	Bild-Telegramm	11	2	Wien	11	0	deutsch	1958-03-13	9	1958-03-21	9	KA	KA	KA
101470	British Morning News	11	7	Wien	11	0	englisch	1945-11-20	9	1946-07-19	9	KA	KA	Zeitung der britischen Besatzungsmacht
101800	Deutsche Echo, Das	11	4	Wien	11	0	deutsch	1938-03-22	9	1938-07-30	9	KA	KA	KA
101900	Deutsche Tageszeitung	11	4	Wien	11	0	deutsch	1920-08-08	9	1921-03-31	9	KA	KA	KA
102000	Deutsche Telegraf am Mittag, Der	11	4	Wien	11	0	deutsch	1938-03-18	9	1938-09-15	9	KA	KA	KA
102200	Deutscher Telegraf	11	4	Wien	11	0	deutsch	1938-03-18	9	1938-09-15	9	KA	KA	KA
102400	Deutschösterreichische Abend-Zeitung	11	4	Wien	11	0	deutsch	1923-02-05	9	1924-01-31	9	KA	KA	KA
102500	Deutschösterreichische Tages-Zeitung	11	4	Wien	11	0	deutsch	1921-04-01	9	1933-07-22	9	KA	KA	08.02.1928 - 29.03.1928 in Krems bei Josef Faber hergestellt
102700	Echo, Das	11	4	Wien	11	0	deutsch	1934-02-19	9	1938-03-11	9	KA	KA	KA
102770	Express	12	4	Wien	11	0	deutsch	1958-03-26	9	1971-04-28	9	KA	KA	1960 - 1970 im Eigentum des zur SPÖ gehörenden Vorwärts-Verlags 
103000	Freie Tribüne, Die	11	2	Wien	11	0	deutsch	1931-06-23	9	1931-10-01	9	KA	KA	3 mal wöchentlich
103670	Groschen-Blatt, Das	11	2	Wien	11	0	deutsch	1947-06-03	9	1947-06-26	9	KA	KA	KA
103701	Illustrierte Kronen-Zeitung	11	2	Wien	11	0	deutsch	1905-06-01	9	1941-06-30	9	KA	KA	Am 12.03.1938 von den Nationalsozialisten übernommen
103702	Illustrierte Kronen-Zeitung	11	2	Wien	11	0	deutsch	1959-04-11	9	1967-10-21	9	KA	KA	KA
104100	Kampfruf, Der	12	4	Wien	11	0	deutsch	1933-05-03	9	1933-06-17	9	KA	KA	KA
104200	Kampfruf	11	4	Wien	11	0	deutsch	1933-06-21	9	1933-07-06	9	KA	KA	KA
104301	Kleine Blatt, Das [1]	11	4	Wien	11	0	deutsch	1927-03-01	9	1934-02-12	9	KA	KA	KA
104302	Kleine Blatt, Das [2]	11	4	Wien	11	0	deutsch	1934-02-28	9	1944-08-31	9	KA	KA	Zusammenlegung mit > 104601 Das Kleine Volksblatt und > 104700 Kleine Volks-Zeitung > 112700 Wiener Kronen-Zeitung u > 104800 Kleine Wiener Kriegszeitung
100104	Abend, Der [4]	11	2	Wien	11	0	deutsch	1948-02-25	9	1956-09-29	9	KA	KA	KA
104601	Kleine Volksblatt, Das [1]	11	2	Wien	11	0	deutsch	1929-01-27	9	1944-08-31	9	KA	KA	Zusammenlegung mit > 104302 Das Kleine Blatt und > 104700 Kleine Volkszeitung und > Wiener Kronen-Zeitung zu > 104800 Kleine Wiener Kriegszeitung
104602	Kleine Volksblatt, Das [2]	11	4	Wien	11	0	deutsch	1945-08-05	9	1962-09-30	9	KA	KA	KA
104700	Kleine Volkszeitung	11	2	Wien	11	0	deutsch	1918-11-14	9	1944-08-31	9	KA	KA	KA
104800	Kleine Wiener Kriegszeitung	11	4	Wien	11	0	deutsch	1944-09-01	9	1945-04-07	9	KA	KA	Hervorgegangen aus der Zusammenlegung von > 104302 Das Kleine Blatt mit > 104601 Das Kleine Volksblatt und > 104700 Kleine Volks-Zeitung > 112700 Wiener Kronen-Zeitung
104900	Letzte Nachrichten	11	2	Wien	11	0	deutsch	1930-05-18	9	1930-07-23	9	KA	KA	KA
105700	Morgenpost	11	2	Wien	11	0	deutsch	1932-10-02	9	1932-12-18	9	KA	KA	KA
105850	Morning News, The	11	7	Wien	11	0	englisch	1946-07-20	9	1949-06-19	9	KA	KA	Zeitung der britischen Besatzungsmacht
106000	Nachtausgabe	11	2	Wien	11	0	deutsch	1933-10-23	9	1933-11-11	9	KA	KA	KA
106400	Nachtpost, Die	11	4	Wien	11	0	deutsch	1933-04-05	9	1933-06-19	9	KA	KA	KA
106500	Nachtpost	11	4	Wien	11	0	deutsch	1933-06-20	9	1933-06-22	9	KA	KA	Aus Zensurgründen neue Ausgabenzählung gegenüber > 106400 Die Nachtpost
106670	Neue Abend, Der	11	2	Wien	11	0	deutsch	1918-06-01	9	1918-10-30	9	KA	KA	KA
106800	Neue Freie Presse	11	2	Wien	11	0	deutsch	1864-01-09	9	1939-01-31	9	KA	KA	Gegründet von Redakteuren der Tageszeitung > 109172 Die Presse / Zusammengelegt mit > 107600 Neues Wiener Journal zu > 107700 Neues Wiener Tagblatt
106851	Neue Kronen Zeitung - Wiener Ausgabe	11	2	Wien	11	0	deutsch	1972-09-01	9	2000-10-31	9	KA	KA	Beginndatum der Wiener Ausgabe möglicherweise später
106930	Neue Tageszeitung	11	4	Wien	11	0	deutsch	1955-03-01	9	1955-03-26	9	KA	KA	KA
107020	Neue Weltpresse	12	2	Wien	11	0	deutsch	1957-11-04	9	1958-03-25	9	KA	KA	KA
107110	Neue Wiener Tageszeitung	11	4	Wien	11	0	deutsch	1950-01-15	9	1955-02-28	9	KA	KA	KA
107200	Neue Zeitung, Die	11	2	Wien	11	0	deutsch	1907-11-01	9	1934-01-13	9	KA	KA	KA
107210	Neue Zeitung, Die	11	4	Wien	11	0	deutsch	1967-10-03	9	1970-12-03	9	KA	KA	KA
107250	Neuer Kurier	11	2	Wien	11	0	deutsch	1954-10-18	9	1959-06-13	9	KA	KA	KA
107310	Neues Bild-Telegramm	11	2	Wien	11	0	deutsch	1958-03-22	9	1958-03-25	9	KA	KA	KA
106750	Neue AZ [[Dach/überregional]]	11	4	Wien	20	0	deutsch	1985-10-16	9	1989-12-11	9	KA	KA	KA
106751	Neue AZ - Wiener Tagblatt	11	4	Wien	11	0	deutsch	1985-10-16	9	1989-12-11	9	KA	KA	Beginndatum lt. https://de.wikipedia.org/wiki/Arbeiter-Zeitung#cite_note-AZ-19870603-35
106850	Neue Kronen Zeitung [[Dach/überregional]]	11	2	Wien	20	0	deutsch	1972-09-01	9	2000-10-31	9	KA	KA	KA
107360	Neues Österreich	11	4	Wien	11	0	deutsch	1945-04-23	9	1967-01-28	9	KA	KA	Dreiparteienblatt
108100	NS Telegraf	11	4	Wien	11	0	deutsch	1938-03-12	9	1938-03-17	9	KA	KA	KA
108200	NS Telegraf am Mittag	11	4	Wien	11	0	deutsch	1938-03-14	9	1938-03-17	9	KA	KA	KA
108241	Österreich - Wien	11	2	Wien	11	0	deutsch	2006-09-01	9	9999-01-01	9	Die Tageszeitung ÖSTERREICH ist unabhängig, kritisch, modern und ausschließlich ihren Lesern verpflichtet. In ihrer grundlegenden Richtung bekennt sich die Tageszeitung ÖSTERREICH zur demokratischen Republik Österreich und ihren Prinzipien, zu den Menschenrechten und zu einer an Gerechtigkeit und Nachhaltigkeit orientierten Gesellschaft. Daher tritt die Tageszeitung ÖSTERREICH insbesondere dafür ein, die parlamentarische Demokratie und den Rechtsstaat zu bewahren und zu fördern sowie die wirtschaftliche Wettbewerbsfähigkeit, beruhend auf den Grundsätzen der sozialen Marktwirtschaft, und die Eigenständigkeit Österreichs zu stärken. Zur grundlegenden Richtung des Mediums zählen auch Berichte über gesetzlich zulässige Werbeaktionen zur Förderung des Absatzes des Druckwerks ÖSTERREICH und allfälliger weiterer mit diesem Konzern verbundenen Print- und Onlinemedien. Die Tageszeitung ÖSTERREICH ist für Toleranz gegenüber allen ethnischen und religiösen Gruppen, lehnt politischen Extremismus und Totalitarismus ab. Die Redaktion der Tageszeitung ÖSTERREICH ist dem Ehrenkodex der österreichischen Presse verpflichtet. Sie bemüht sich in allen Bereichen um Fairness und Objektivität.	KA	KA
108350	Oesterreichische Kronen Zeitung	11	2	Wien	11	0	deutsch	1900-01-02	9	1905-05-31	9	KA	KA	KA
108370	Österreichische Neue Tageszeitung	11	4	Wien	11	0	deutsch	1955-03-27	9	1964-05-15	9	KA	KA	KA
108550	Österreichische Zeitung	11	7	Wien	11	0	deutsch	1945-04-30	9	1955-07-31	9	KA	KA	Zeitung der russischen Besatzungsmacht
109001	Ostdeutsche Rundschau [1]	11	4	Wien	11	0	deutsch	1893-10-01	9	1903-12-31	9	KA	KA	KA
109002	Ostdeutsche Rundschau [2]	11	4	Wien	11	0	deutsch	1908-05-03	9	1919-08-01	9	KA	KA	KA
112100	Wiener Abendpost	11	6	Wien	11	0	deutsch	1863-07-01	9	1921-12-31	9	KA	KA	KA
109171	Presse, Die [1]	11	2	Wien	11	0	deutsch	1848-07-03	9	1849-12-08	9	KA	KA	1849 von der Militärverwaltung Wiens verboten, danach kurzfristig in Brünn hergestellt
109172	Presse, Die [2]	11	2	Wien	11	0	deutsch	1851-09-25	9	1896-02-01	9	KA	KA	KA
109173	Morgen-Presse	11	2	Wien	11	0	deutsch	1896-02-03	9	1896-10-31	9	KA	KA	Nach der Einstellung der Zeitung wurden die Abonnements von der > 116120 Reichswehr übernommen, der Hauptausgabe der ab 02.01.1900 erschienenen > 1083500 Oesterreichische Kronen Zeitung.
114601	WirtschaftsBlatt - [[Wien]]	11	2	Wien	11	0	deutsch	1995-06-10	9	2016-09-02	9	KA	KA	KA
109181	Presse, Die - [[Wien]]	11	2	Wien	11	0	deutsch	1948-10-19	9	9999-01-01	9	„Die Presse“ vertritt in Unabhängigkeit von den politischen Parteien bürgerlich-liberale Auffassungen auf einem gehobenen Niveau. Sie tritt für die parlamentarische Demokratie auf der Grundlage des Mehrparteiensystems und für ihre Rechtsstaatlichkeit ein. „Die Presse“ bekennt sich zu den Grundsätzen der sozialen Gerechtigkeit bei Aufrechterhaltung der Eigenverantwortlichkeit des Menschen, zur Wahrung des privaten Eigentums unter Beobachtung seiner Verpflichtungen gegenüber der Gesellschaft, zu den Grundsätzen der sozialen Marktwirtschaft, zur freien unternehmerischen Initiative und zum Leistungswettbewerb. Sie verteidigt die Grundfreiheiten und Menschenrechte und bekämpft alle Bestrebungen, die geeignet sind, diese Freiheiten und Rechte oder die demokratische rechtsstaatliche Gesellschaftsordnung zu gefährden. „Die Presse“ betrachtet es als journalistische Standespflicht, ihre Leserinnen und Leser objektiv und so vollständig wie nur möglich über alle Ereignisse von allgemeinem Interesse zu informieren. Stellung zu nehmen und Kritik zu üben wird von der „Presse“ als ihre Aufgabe und ihr unveräußerliches Recht angesehen.	KA	KA
109500	Rote Fahne, Die	11	4	Wien	11	0	deutsch	1919-07-26	9	1933-07-22	9	KA	KA	Von Mitte August 1933 bis Mai/Juni 1939 im Exil unregelmäßig (etwa vierzehntäglich bis monatlich) erschienen.
109791	Slovenski vestnik [1]	11	5	Wien	11	0	slowenisch	1947-02-18	9	1947-06-27	9	KA	KA	kA
109792	Slovenski vestnik [2]	11	5	Klagenfurt	13	0	slowenisch	1948-02-27	9	1949-07-02	9	KA	KA	KA
109793	Slovenski vestnik [3]	11	5	Wien	11	0	slowenisch	1949-08-27	9	1950-11-29	9	KA	KA	KA
109794	Slovenski vestnik [4]	11	5	Klagenfurt	13	0	slowenisch	1950-12-02	9	1953-04-02	9	KA	KA	KA
109800	soziale Revolution, Die	11	4	Wien	11	0	deutsch	1919-01-15	9	1919-07-23	9	KA	KA	KA
109860	Standard Kompakt, Der	11	2	Wien	20	0	deutsch	2013-02-26	9	9999-01-01	9	DER STANDARD ist ein liberales Medium. Es ist unabhängig von politischen Parteien, Institutionen und Interessengruppen und wendet sich an alle Lesende, die hohe Ansprüche an eine gründliche und umfassende Berichterstattung sowie an eine fundierte, sachgerechte Kommentierung auf den Gebieten von Wirtschaft, Politik, Kultur und Gesellschaft stellen.DER STANDARD lebt die Blattphilosophie in einer ebenso klaren wie anspruchsvollen Weise. Er trennt zwischen Bericht und Kommentar, gewichtet die Ereignisse und lässt seinen Leser:innen den nötigen Spielraum für die eigene Meinung. So fördert er, was zugleich sein Ziel ist: eine mündige Leserschaft.	KA	KA
110001	Stunde , Die	11	2	Wien	11	0	deutsch	1923-03-02	9	1938-03-13	9	KA	KA	KA
110090	U-Express	11	2	Wien	11	0	deutsch	2001-03-19	9	2004-03-31	9	KA	KA	Gratiszeitung
110601	Telegraf	11	2	Wien	11	0	deutsch	1932-04-18	9	1938-03-11	9	KA	KA	KA
110700	Telegraf am Mittag	11	4	Wien	11	0	deutsch	1934-02-17	9	1938-03-11	9	KA	KA	KA
110831	Unabhängige Kronen-Zeitung	11	2	Wien	11	0	deutsch	1967-10-22	9	1972-08-31	9	KA	KA	KA
111360	14-Groschen-Blatt , Das	11	2	Wien	11	0	deutsch	1947-06-03	9	1947-06-26	9	KA	KA	KA
111481	Volksstimme - [Wien]	11	4	Wien	11	0	deutsch	1957-02-21	9	1991-03-03	9	KA	KA	03.05.1991-26.02.1993  als Wochenzeitung unter dem Titel Salto,  25.11.1993-16.10.2003 wieder als Volksstimme erschienen. 01.06.2004-05.2009 als Monatsmagazin unter dem Titel Volksstimmen erschienen, ab 01.09.2009 wieder als Volksstimme.
111700	Weckruf, Der	11	4	Wien	11	0	deutsch	1918-11-25	9	1919-01-11	9	KA	KA	Ab 01.05.1918 unregelmäßig erschienen
111750	Welt am Abend	11	7	Wien	11	0	deutsch	1946-10-01	9	1948-10-30	9	KA	KA	Zeitung der französischen Besatzungsmacht, ab 01.03.1948 von einer der SPÖ nahestehenden Verlagsgesellschaft übernommen
111800	Welt am Morgen , Die	11	2	Wien	11	0	deutsch	1927-03-27	9	1932-10-01	9	KA	KA	KA
111920	Weltpresse	11	7	Wien	11	0	deutsch	1945-09-18	9	1957-11-02	9	KA	KA	Zeitung der britischen Besatzungsmacht, 01.09.1950-28.02.1957 im Eigentum einer der SPÖ nahestehenden Verlagsgesellschaft, danach an eine ÖGB-nahe Gesellschaft verkauft, von der sie Fritz Molden gekauft und weitergeführt hatte
110100	Tag, Der	11	2	Wien	11	0	deutsch	1922-11-25	9	1930-06-29	9	KA	KA	KA
112300	Wiener Deutsche Tageszeitung	11	4	Wien	11	0	deutsch	1920-07-01	9	1920-08-07	9	KA	KA	Hervorgegangen aus der Zusammenlegung von > 101102 Alldeutsches Tagblatt mit > 609002 Ostdeutsche Rundschau
112700	Wiener Kronen-Zeitung	11	4	Wien	11	0	deutsch	1941-07-01	9	1944-08-31	9	KA	KA	Zusammenlegung mit > 104302 Das Kleine Blatt mit > 104601 Das Kleine Volksblatt und > 104700 Kleine Volks-Zeitung zu > 104800 Kleine Wiener Kriegszeitung
112750	Wiener Kurier	11	7	Wien	11	0	deutsch	1945-08-27	9	1954-10-16	9	KA	KA	Zeitung der US-amerikanischen Besatzungsmacht
113900	Wiener Neueste Nachrichten	11	2	Wien	11	0	deutsch	1925-10-30	9	1945-04-05	9	KA	KA	KA
114300	Wiener Tag, Der	11	2	Wien	11	0	deutsch	1930-07-01	9	1938-03-12	9	KA	KA	KA
114501	Wiener Zeitung	11	6	Wien	11	0	deutsch	1780-01-01	9	1940-02-29	9	KA	KA	Gegründet 08.08.1703 unter dem Titel Wiennerisches Diarium
114503	Wiener Zeitung - [[Wien]]	11	6	Wien	11	0	deutsch	1945-09-21	9	2023-06-30	9	KA	KA	KA
115100	12-Uhr-Blatt	11	2	Wien	11	0	deutsch	1933-09-14	9	1934-01-12	9	KA	KA	KA
116010	Abend-Presse	11	2	Wien	11	0	deutsch	1896-02-02	9	1896-10-31	9	KA	KA	Hervorgegangen aus der Abendausgabe von > 109172 Die Presse
116020	7 Uhr-Presse	11	2	Wien	11	0	deutsch	1896-02-02	9	1896-10-31	9	KA	KA	KA
116030	Deutsche Presse	11	4	Wien	11	0	deutsch	1914-08-19	9	1917-02-11	9	KA	KA	KA
116040	Deutsches Tagblatt	11	4	Wien	11	0	deutsch	1904-01-01	9	1904-10-23	9	KA	KA	KA
116050	Neues Deutsches Tagblatt	11	4	Wien	11	0	deutsch	1904-10-25	9	1904-11-20	9	KA	KA	KA
116060	Wiener Deutsches Tagblatt	11	4	Wien	11	0	deutsch	1904-12-18	9	1907-12-22	9	KA	KA	KA
116070	Deutsches Tagblatt	11	4	Wien	11	0	deutsch	1907-12-24	9	1908-05-01	9	KA	KA	KA
116080	Allgemeine Volkszeitung	11	2	Wien	11	0	deutsch	1868-08-01	9	1873-12-31	4	KA	KA	Dürfte bis 1873 erschienen sein, vgl. Eberlein (1969, S. 1835)
116100	Wiener Volkswacht	11	4	Wien	11	0	deutsch	1900-10-27	9	1903-12-31	9	KA	KA	Eberlein (1969, S. 1827)
116110	Arbeit, Die	11	5	Wien	11	0	deutsch	1897-01-03	9	1901-05-05	9	KA	KA	KA
116120	Reichswehr , Die 	11	2	Wien	11	0	deutsch	1889-04-01	9	1904-12-15	9	KA	KA	KA
119090	Telegraf	11	2	Wien	11	0	deutsch	1868-03-25	9	1868-07-31	1	KA	KA	25.03.1868 - 07.1868 wurde die Morgenausgabe des Grazer > 176010 Telegraf (nach Eigentumswechsel) vorübergehend in Wien hergestellt und in Graz und Wien vertrieben, aber die Abendausgabe weiterhin in Graz hergesetellt / der Wiener Ausgabe folgte (nach neuerlichem Eigentumswechsel) die > 116080 Allgemeine Volkszeitung nach, vgl. Fruhmann (2013)
119850	Standard, Der - [[Wien]]	11	2	Wien	11	0	deutsch	1988-10-19	9	9999-01-01	9	KA	KA	KA
120320	Neue Kronen-Zeitung - Burgenland	11	2	Wien	12	0	deutsch	1986-04-06	9	2000-10-31	9	KA	KA	KA
120700	Südost-Tagespost - [Ausgabe für das Burgenland]	11	4	Graz	12	0	deutsch	1971-03-12	9	1987-03-31	9	KA	KA	KA
120730	täglich Alles für das Burgenland	11	2	KA	12	0	deutsch	1993-06-04	9	1999-01-03	9	KA	KA	KA
123190	Kurier - Niederösterreich/Burgenland	11	2	KA	14	0	deutsch	1973-10-02	9	1978-02-28	9	KA	KA	KA
123330	Neue Kronen-Zeitung - [Ausgabe für Niederösterreich und Burgenland]	11	2	Wien	14	0	deutsch	1977-11-18	9	1986-04-05	9	KA	KA	Beginndatum möglicherweise früher
123510	Neue Zeitung, Die - NÖ/Burgenland	11	4	Wien	14	0	deutsch	1970-07-22	9	1970-12-03	9	KA	KA	KA
123710	Südost-Tagespost - [Ausgabe für das Burgenland und Niederösterreich]	11	4	Graz	12	0	deutsch	1970-11-20	9	1971-03-11	9	KA	KA	KA
130070	Kärntner Grenzruf	11	4	Klagenfurt	13	0	deutsch	1938-09-01	9	1942-05-15	9	KA	KA	ab 01.07.1939: Ausgabe für Klagenfurt und Unterkärnten
130071	Kärntner Grenzruf - Ausgabe für Villach und Oberkärnten	11	4	Klagenfurt	13	1	deutsch	1939-07-01	9	1942-05-15	9	KA	KA	täglich
130072	Kärntner Zeitung - Ausgabe für Villach und Oberkärnten	11	4	Klagenfurt	13	1	deutsch	1942-05-16	9	1945-05-07	9	KA	KA	täglich
130100	Kärntner Nachrichten	11	7	Villach	13	0	deutsch	1945-05-16	9	1945-12-31	9	KA	KA	Zeitung der britischen Besatzungsmacht
130111	Kärntner Tageszeitung	11	4	Klagenfurt	13	0	deutsch	1965-10-24	9	1993-05-05	9	KA	KA	KA
130112	Kärntner Tageszeitung	11	2	Klagenfurt	13	0	deutsch	2010-01-31	9	2014-02-28	9	KA	KA	KA
130121	Kärntner Zeitung	11	2	Klagenfurt	13	0	deutsch	1894-01-03	9	1905-12-22	9	KA	KA	KA
130122	Kärntner Zeitung - Ausgabe für Klagenfurt und Unterkärnten	11	4	Klagenfurt	13	1	deutsch	1942-05-16	9	1945-05-07	9	KA	KA	täglich
130151	Kleine Zeitung - [Kärntner Ausgabe]	11	2	Graz	13	0	deutsch	1937-07-01	9	1945-04-01	9	KA	KA	Beginndatum möglicherweise früher
120160	Kronen-Zeitung - Burgenland	11	2	Eisenstadt	12	1	deutsch	2000-11-02	9	9999-01-01	9	Die Vielfalt der Meinungen ihres Herausgebers und der Redakteure.	KA	Erscheint ab 10.01.2003 in 2 Lokalausgaben / Redaktion in Eisenstadt ab 2020
130152	Kleine Zeitung - [Kärnten]	11	2	Klagenfurt	13	1	deutsch	1948-10-31	9	9999-01-01	9	Die KLEINE ZEITUNG ist eine von allen politischen Parteien und Interessenvertretungen unabhängige Tageszeitung. Sie steht auf dem Boden christlicher Weltanschauung, tritt für eine plurale, demokratische Gesellschaftsordnung, die Eigenständigkeit der Bundesländer und die völkerrechtliche Unabhängigkeit der Republik Österreich ein und begrüßt den europäischen Einigungsprozess.	KA	Erscheint ab 24.11.1984 in 2, ab 03.01.1990 in 7, ab 14.03.2006 in 8 Lokalausgaben
130180	Kronen-Zeitung - Kärntner Krone	11	2	Klagenfurt	13	1	deutsch	2000-11-02	9	9999-01-01	9	Die Vielfalt der Meinungen ihres Herausgebers und der Redakteure.	KA	Erscheint in 2 Lokalausgaben 
130200	Kurier - Kärnten	11	2	KA	13	0	deutsch	1991-01-12	9	1993-04-19	9	KA	KA	Beginndatum möglicherweise früher
130460	Neue Volkszeitung	11	4	Klagenfurt	13	0	deutsch	1982-06-12	9	1989-11-30	9	KA	KA	KA
130480	Neue Zeit, Die	11	4	Klagenfurt	13	0	deutsch	1946-01-04	9	1965-10-23	9	KA	KA	KA
130580	Österreichische Allgemeine Zeitung mit Kärntner Beilage der Ö.A.Z.	11	4	KA	13	0	deutsch	1950-01-19	9	1950-04-21	9	KA	KA	KA
130951	Volkswille	11	4	Klagenfurt	13	0	deutsch	1946-01-05	9	1952-04-30	9	KA	KA	ab 05.01.1946 2-3 mal wöchentlich, ab 01.11.1946 täglich erschienen
130952	Wahrheit und Volkswille - Tageszeitung für Kärnten und Osttirol	11	4	Graz	13	0	deutsch	1952-05-01	9	1971-01-31	9	KA	KA	KA
130961	Volkszeitung	11	4	Klagenfurt	13	0	deutsch	1946-01-04	9	1974-04-12	9	KA	KA	Ab 14.09.1971 VZ Volkszeitung
130962	Volkszeitung	11	4	Klagenfurt	13	0	deutsch	1989-12-01	9	1990-02-04	9	KA	KA	KA
131030	VZ	11	4	Klagenfurt	13	0	deutsch	1974-04-13	9	1982-06-11	9	KA	KA	KA
131100	Kärntner Tagblatt	11	2	Klagenfurt	13	0	deutsch	1905-12-24	9	1938-08-31	9	KA	KA	KA
140021	Arbeiter-Zeitung - Ausgabe für Niederösterreich [1]	11	4	KA	14	0	deutsch	1948-04-01	9	1948-06-04	9	KA	KA	KA
140022	Arbeiter-Zeitung - Ausgabe für Niederösterreich [2]	11	4	KA	14	0	deutsch	1957-01-03	9	1985-10-15	9	KA	KA	KA
140090	Guten Tag Niederösterreich	11	2	St. Pölten	14	0	deutsch	1990-10-02	9	1990-10-31	9	KA	KA	KA
140140	Kleine Volksblatt, Das - Ausgabe für Niederösterreich	11	4	Wien	14	0	deutsch	1960-01-01	9	1962-09-30	9	KA	KA	KA
140300	Neue AZ - Niederösterreich Tagblatt	11	4	KA	14	0	deutsch	1985-10-16	9	1989-12-11	9	KA	KA	KA
140350	Neue Kronen-Zeitung - Niederösterreich	11	2	Wien	14	0	deutsch	1986-04-06	9	2000-10-31	9	KA	KA	KA
140400	AZ - Ausgabe für Niederösterreich	11	2	KA	14	0	deutsch	1989-12-12	9	1991-10-31	9	KA	KA	KA
140540	Niederösterreichisches Volksblatt	11	4	Linz	14	0	deutsch	1971-04-05	9	1974-09-27	9	KA	KA	Aufgegangen in > 150530 Neues Volksblatt
140740	täglich Alles für Niederösterreich	11	2	KA	14	0	deutsch	1992-08-11	9	1999-01-03	9	KA	KA	KA
140901	Volksstimme - Ausgabe für Niederösterreich	11	4	Wien	14	0	deutsch	1948-05-05	9	1967-05-07	9	KA	KA	KA
144500	Wiener Tageszeitung	11	4	Wien	11	0	deutsch	1947-06-22	9	1950-01-14	9	KA	KA	KA
160631	Salzburger Tagblatt	11	4	Salzburg	16	0	deutsch	1945-10-23	9	1950-06-30	9	KA	KA	KA
130340	Neue Kronen-Zeitung - Kärntner Krone	11	2	Klagenfurt	13	1	deutsch	1983-11-06	9	2000-10-31	9	KA	KA	Erscheint ab1993? In 2 Lokalausgaben
138250	oe24 - Kärnten [[Gratis]]	11	2	Wien	13	0	deutsch	2018-08-29	9	2019-11-29	9	KA	KA	KA
140180	Kronen-Zeitung - Niederösterreich	11	2	St. Pölten	14	1	deutsch	2000-11-02	9	9999-01-01	9	Die Vielfalt der Meinungen ihres Herausgebers und der Redakteure.	KA	Erscheint ab 10.01.2003 in 4 Lokalausgaben
130953	VW Volkswille	11	4	Wien	13	0	deutsch	1971-02-02	9	1989-12-31	9	KA	KA	KA
150010	Allgemeine Tagespost	11	4	Linz	15	0	deutsch	1949-12-01	9	1950-03-20	9	KA	KA	Nach Einstellung der Zeitung erschien 160590 > Österreichische Allgemeine Zeitung mit Regionalnachrichten für Oberösterreich
150070	Arbeitersturm	11	4	Linz	15	0	deutsch	1938-03-13	9	1938-06-30	9	KA	KA	KA
150130	Kleine Tageszeitung	11	4	Linz	15	0	deutsch	1949-07-01	9	1949-12-31	9	KA	KA	KA
150240	Lambacher Nachrichtenblatt	11	99	Lambach	15	1	deutsch	1945-05-10	9	1945-06-30	1	KA	KA	KA
150270	Linzer Kurier	11	2	Linz	15	0	deutsch	1961-11-18	9	1962-03-03	9	KA	KA	KA
150282	Linzer Volksblatt [1]	11	4	Linz	15	0	deutsch	1869-01-02	9	1938-06-30	9	KA	KA	KA
150283	Linzer Volksblatt [2]	11	4	Linz	15	0	deutsch	1945-10-08	9	1974-09-27	9	KA	KA	3 mal wöchentlich erschienen, ab 29.12.1945 täglich
150290	Nachrichten am Abend	11	2	Linz	15	0	deutsch	1948-02-02	9	1948-09-30	9	KA	KA	KA
150361	Neue Kronen-Zeitung - Ausgabe für Oberösterreich [1]	11	2	Linz	15	0	deutsch	1972-09-01	9	1974-08-31	9	KA	KA	KA
150362	Neue Kronen-Zeitung - Ausgabe für Oberösterreich [2]	11	2	Linz	15	0	deutsch	1974-12-31	9	2000-10-31	9	KA	KA	ab 31.03.1977: Oberösterreich
150491	Neue Zeit [1]	11	4	Linz	15	0	deutsch	1945-10-09	9	1950-06-30	9	KA	KA	3 mal wöchentlich erschienen, ab 02.01.1946 täglich
150492	Neue Zeit und Salzburger Tagblatt 	11	4	Linz	15	0	deutsch	1950-07-01	9	1957-07-01	9	KA	KA	KA
150530	Neues Volksblatt	11	4	Linz	15	0	deutsch	1974-09-28	9	2018-09-10	9	KA	KA	KA
150540	Oberdonauzeitung	11	4	Linz	15	1	deutsch	1943-01-01	9	1945-05-04	9	KA	KA	KA
150560	Oberösterreichische Nachrichten am Abend	11	2	Linz	15	0	deutsch	1947-05-05	9	1948-01-31	9	KA	KA	KA
150571	Oberösterreichisches Tagblatt	11	4	Linz	15	0	deutsch	1975-11-28	9	1987-06-01	9	KA	KA	KA
150572	Oberösterreichisches Tagblatt - Neue AZ	11	4	Linz	15	0	deutsch	1987-06-02	9	1989-12-11	9	KA	KA	KA
150610	Salzburger Nachrichten - [Ausgabe für Oberösterreich]	11	2	Salzburg	15	0	deutsch	1957-01-01	4	1958-11-28	9	KA	KA	KA
150630	Salzkammergut Beobachter - Tagesausgabe	11	4	Gmunden	15	1	deutsch	1938-03-12	9	1938-04-23	9	KA	KA	Unter gleichem Titel erschien auch eine Wochenausgabe
150650	Salzkammergut Stimmen	11	5	Bad Ischl	15	1	deutsch	1945-05-23	9	1945-05-26	9	KA	KA	2 mal wöchentlich / Österreichische Freiheitsbewegung für Bad Ischl und Umgebung
150660	Salzkammergut Tageszeitung	11	4	Gmunden	15	1	deutsch	1938-04-25	9	1930-07-30	9	KA	KA	KA
150680	Salzkammergut Volksstimme	11	4	Gmunden	15	1	deutsch	1938-08-01	9	1938-12-31	9	KA	KA	KA
150700	Salzkammergut-Zeitung	11	99	Gmunden	15	1	deutsch	1914-08-01	9	1916-10-31	9	KA	KA	KA
150710	Neueste Post	11	99	Gmunden	15	1	deutsch	1916-11-01	9	1938-03-11	9	KA	KA	KA
150720	Steyrer Volksstimme	11	4	Linz	15	1	deutsch	1938-09-01	9	1938-12-30	9	KA	KA	KA
150741	Steyrer Zeitung [1]	11	99	Steyr	15	1	deutsch	1876-01-02	9	1936-12-30	9	KA	KA	3 mal wöchentlich
150742	Steyrer Zeitung [2]	11	99	Steyr	15	1	deutsch	1937-07-04	9	1938-08-30	9	KA	KA	2-3 mal wöchentlich
150750	täglich Alles für Oberösterreich	11	2	KA	15	0	deutsch	1992-09-15	9	1999-01-03	9	KA	KA	KA
150771	Tagblatt	11	4	Linz	15	0	deutsch	1916-01-01	9	1932-10-17	9	KA	KA	KA
150772	Tagblatt mit Arbeiter-Zeitung	11	4	Wien	15	0	deutsch	1932-10-18	9	1933-06-30	9	KA	KA	KA
150773	Tagblatt [1]	11	4	Linz	15	0	deutsch	1933-07-01	9	1938-03-11	9	KA	KA	KA
150774	Tagblatt [2]	11	4	Linz	15	0	deutsch	1945-10-08	9	1975-11-27	9	KA	KA	3 mal wöchentlich, ab 01.01.1946 täglich
150775	AZ Tagblatt	11	2	Linz	15	0	deutsch	1989-12-12	9	1991-10-31	9	KA	KA	KA
150790	Tages-Echo	11	4	Linz	15	0	deutsch	1949-09-15	9	1949-10-22	9	KA	KA	3 mal wöchentlich
150880	Unabhängige Kronen-Zeitung - Ausgabe für Oberösterreich	11	2	Linz	15	0	deutsch	1968-05-16	9	1972-08-31	9	KA	KA	KA
150911	Volksstimme [1]	11	4	Linz	15	0	deutsch	1931-04-03	9	1931-08-29	9	KA	KA	KA
150912	Volksstimme [2]	11	4	Linz	15	0	deutsch	1938-07-01	9	1942-12-31	9	KA	KA	KA
150990	Welser Zeitung	11	99	Wels	15	1	deutsch	1945-05-08	9	1945-05-09	9	KA	KA	KA
151280	Linzer Abendbote	11	2	Linz	15	0	deutsch	1855-07-02	9	1868-12-31	9	KA	KA	KA
151281	Österreichische Nachrichten	11	4	Linz	15	0	deutsch	1945-06-01	9	1945-08-24	9	KA	KA	KA
151282	Mühlviertler Post	11	4	Linz	15	1	deutsch	1945-08-27	9	1946-01-31	9	KA	KA	Dreiparteienblatt / 3 mal wöchentlich
151283	Mühlviertler Bote	11	4	Linz	15	1	deutsch	1946-02-02	9	1956-06-30	9	KA	KA	2-3 mal wöchentlich
150180	Kronen-Zeitung - Oberösterreich	11	2	Linz	15	1	deutsch	2000-11-02	9	9999-01-01	9	Die Vielfalt der Meinungen ihres Herausgebers und der Redakteure.	KA	Erscheint ab 2004 in 2, ab ? in 4 Lokalausgaben
150493	Neue Zeit [2]	11	4	Linz	15	1	deutsch	1957-07-02	9	1990-01-02	9	KA	KA	Erscheint ab 02.04.1946? in 3, ab 01.05.1969? in 4, ab 14.11.1970 in 5, ab 01.02.1972 in 6, ab 19.04.1985 in 8 Lokalausgaben / ab 01.07.1987 im Eigentum der Mitarbeiter:innen
150550	Oberösterreichische Nachrichten	11	2	Linz	15	1	deutsch	1945-06-11	9	9999-01-01	9	Die Oberösterreichischen Nachrichten sind eine überparteiliche und unabhängige Tageszeitung. Sie bekennen sich zur pluralistischen Gesellschaftsordnung der parlamentarischen Demokratie, zu den Prinzipien der sozialen Marktwirtschaft sowie zur Integration Europas und fühlen sich den Menschenrechten verpflichtet.	KA	 zunächst Zeitung der US-amerrikanischen Besatzungsmacht, ab 08.10.1945-29.08.1946 Dreiparteienblatt /  ab 1989? in 5, ab 1998 in 6 Lokalausgaben 
152280	Oberösterreichisches Volksblatt	11	4	Linz	15	0	deutsch	2018-09-11	9	2023-12-30	9	Das „Oberösterreichische Volksblatt“ versteht sich als regionales oberösterreichisches Medienhaus, das dem christlich-sozialen Gedankengut verpflichtet ist. Das „Oberösterreichische Volksblatt“ ist redaktionell unabhängig und widmet sich insbesondere den Interessen der Bewohner der Region im politischen, wirtschaftlichen, sportlichen, kulturellen und sozialen Bereich. Das „Oberösterreichische Volksblatt“ ist dem Ehrenkodex der österreichischen Presse verpflichtet.	KA	Soll ab 2024 als Monatsmagazin weitergeführt werden.
153280	Linzer Volksstimme 	11	99	Linz	15	0	deutsch	1923-03-31	9	1924-02-27	9	KA	KA	2 mal wöchentlich / Erscheint bis 25.09.1926 als Wochenzeitung
153900	Oberösterreichs Neue	11	2	Linz	15	0	deutsch	2006-08-21	9	2009-06-10	9	KA	KA	Gratiszeitung
156370	Neue Kronen-Zeitung - Ausgabe für Oberösterreich und Salzburg	11	2	Linz	15	0	deutsch	1974-09-01	9	1974-12-30	9	KA	KA	KA
158240	Österreich - Oberösterreich	11	2	Wien	15	0	deutsch	2006-09-01	9	9999-01-01	9	Die Tageszeitung ÖSTERREICH ist unabhängig, kritisch, modern und ausschließlich ihren Lesern verpflichtet. In ihrer grundlegenden Richtung bekennt sich die Tageszeitung ÖSTERREICH zur demokratischen Republik Österreich und ihren Prinzipien, zu den Menschenrechten und zu einer an Gerechtigkeit und Nachhaltigkeit orientierten Gesellschaft. Daher tritt die Tageszeitung ÖSTERREICH insbesondere dafür ein, die parlamentarische Demokratie und den Rechtsstaat zu bewahren und zu fördern sowie die wirtschaftliche Wettbewerbsfähigkeit, beruhend auf den Grundsätzen der sozialen Marktwirtschaft, und die Eigenständigkeit Österreichs zu stärken. Zur grundlegenden Richtung des Mediums zählen auch Berichte über gesetzlich zulässige Werbeaktionen zur Förderung des Absatzes des Druckwerks ÖSTERREICH und allfälliger weiterer mit diesem Konzern verbundenen Print- und Onlinemedien. Die Tageszeitung ÖSTERREICH ist für Toleranz gegenüber allen ethnischen und religiösen Gruppen, lehnt politischen Extremismus und Totalitarismus ab. Die Redaktion der Tageszeitung ÖSTERREICH ist dem Ehrenkodex der österreichischen Presse verpflichtet. Sie bemüht sich in allen Bereichen um Fairness und Objektivität.	KA	KA
160020	Wahrheit!	11	4	Linz	15	0	deutsch	1906-01-01	9	1915-12-30	9	KA	KA	KA
160061	Demokratisches Volksblatt	11	4	Salzburg	16	0	deutsch	1945-10-23	9	1972-07-31	9	KA	KA	KA
160200	Kronen-Zeitung - Salzburg Krone	11	2	Salzburg	16	0	deutsch	2000-11-02	9	9999-01-01	9	Die Vielfalt der Meinungen ihres Herausgebers und der Redakteure.	KA	KA
160231	Kurier Ausgabe für Salzburg	11	2	KA	16	0	deutsch	1976-06-01	9	1977-09-10	9	KA	KA	KA
160232	Kurier - Salzburg	11	2	KA	16	0	deutsch	1992-08-29	9	1993-04-19	9	KA	KA	KA
160380	Neue Kronen-Zeitung - Ausgabe für Salzburg	11	2	Salzburg	16	0	deutsch	1975-01-01	9	2000-10-31	9	KA	KA	ab 08.04.1977 Salzburg , ab 06.11.1983 Salzburg Krone
160520	Neues Salzburger Tagblatt - Neue AZ	11	4	KA	16	0	deutsch	1985-10-16	9	1989-12-11	9	KA	KA	KA
160590	Österreichische Allgemeine Zeitung	11	4	Salzburg	16	0	deutsch	1949-12-01	9	1950-04-20	9	KA	KA	Nach Einstellung der 150010 Allgemeinen Tagespost mit Regionalnachrichten für Oberösterreich erschienen
160600	Salzburger Chronik 	11	4	Salzburg	16	0	deutsch	1867-01-02	9	1938-03-11	9	KA	KA	02.01.1867-29.12.1881 3 mal wöchentlich erschienen, ab 01.01.1882 täglich
160632	Neue Zeit und Salzburger Tagblatt - [Ausgabe für Salzburg]	11	4	Linz	15	0	deutsch	1950-07-01	9	1957-07-01	9	KA	KA	KA
160633	Salzburger Tagblatt	11	4	Wien	16	0	deutsch	1957-07-02	9	1963-12-31	9	KA	KA	KA
160641	Salzburger Tagblatt	11	4	Salzburg	16	0	deutsch	1972-08-01	9	1984-08-31	9	KA	KA	KA
160642	Salzburger Tagblatt AZ	11	4	KA	16	0	deutsch	1984-09-01	9	1985-10-15	9	KA	KA	KA
160651	Salzburger Volksblatt [1]	11	4	Salzburg	16	0	deutsch	1871-01-03	9	1942-11-14	9	KA	KA	3 mal wöchentlich, ab 02.01.1874 täglich, ab 02.07.1874 3 mal wöchentlich, ab 02.01.1882 täglich
160652	Salzburger Volksblatt [2]	11	4	Salzburg	16	0	deutsch	1950-06-15	9	1979-04-14	9	KA	KA	Nach vorübergehender Einstellung 07.03.1985-10.01.1986 als Wochenzeitung erschienen
160653	Salzburger Volksblatt [3]	11	4	Salzburg	16	0	deutsch	1986-01-14	9	1991-05-14	9	KA	KA	2 mal wöchentlich erschienen
160661	Salzburger Volkszeitung	11	4	Salzburg	16	0	deutsch	1945-10-23	9	1968-03-30	9	KA	KA	05.04.1968-29.10.1971 als Wochenzeitung unter dem Titel SVZ Salzburger Volkszeitung und Salzburger Volksbote erschienen (der Salzburger Volksbote war die Wochenzeitung des ÖVP-Bauernbundes)
160662	SVZ Salzburger Volkszeitung und Salzburger Volksbote 	11	4	Salzburg	16	0	deutsch	1971-11-03	9	1985-02-28	9	KA	KA	KA
160665	SVZ Salzburger Volkszeitung	11	4	Salzburg	16	0	deutsch	1985-03-01	9	2014-07-07	9	KA	KA	KA
160740	Salzburger Zeitung	11	4	Salzburg	16	0	deutsch	1938-03-12	9	1938-08-13	9	KA	KA	KA
160750	Salzburger Zeitung	11	4	Salzburg	16	0	deutsch	1942-11-16	9	1945-05-03	9	KA	KA	Zusammenlegung von > 160651 Salzburger Volksblatt mit > 181610 Salzburger Landeszeitung
160780	Tagblatt AZ	11	2	KA	16	0	deutsch	1989-12-12	9	1990-10-20	9	KA	KA	KA
160910	Volksstimme - Salzburg	11	4	Wien	16	0	deutsch	1964-01-01	9	1975-10-31	9	KA	KA	KA
166010	Salzburger Wacht	11	4	Salzburg	16	0	deutsch	1907-01-01	9	1934-02-12	9	KA	KA	KA
168240	Österreich - Salzburg	11	2	Wien	16	0	deutsch	2007-03-04	9	2021-12-31	1	KA	KA	KA
170008	Grazer Volkszeitung	11	2	Graz	17	0	deutsch	1945-05-10	9	1945-05-10	9	KA	KA	Am 09.05.1945 war bereits die letzte Ausgabe der > 7080 Tagespost im Verlag der demokratischen Grazer Volkszeitung erschienen.
170050	Eisenerzer Zeitung	11	99	Leoben	17	1	deutsch	1949-12-10	9	1953-08-29	9	KA	KA	2 mal wöchentlich
170070	Grazer antifaschistische Volkszeitung	11	6	Graz	17	0	deutsch	1945-05-11	9	1945-05-24	9	KA	KA	KA
170151	Kleine Zeitung	11	2	Graz	17	0	deutsch	1904-11-22	9	1945-05-24	9	KA	KA	KA
170240	Kurier - Steiermark	11	2	KA	17	0	deutsch	1987-04-03	9	1993-04-19	9	KA	KA	KA
170300	Mürztaler Volksstimme	11	5	Bruck an der Mur	17	1	deutsch	1945-09-26	9	1949-06-28	9	KA	KA	2 mal wöchentlich erschienen
170331	Mürztaler, Der 	11	99	Leoben	17	1	deutsch	1934-10-03	9	1938-03-12	9	KA	KA	KA
170332	Mürztaler Zeitung	11	99	Leoben	17	0	deutsch	1949-05-14	9	1961-12-30	9	KA	KA	2-3 mal wöchentlich
170420	Neue Steirische Zeitung	11	6	Graz	17	0	deutsch	1945-05-25	9	1945-12-30	9	KA	KA	Organ der demokratischen Einigung, ab 25.07.1945 Zeitung der britischen Besatzungsmacht
170500	Neue Zeit	11	4	Graz	17	0	deutsch	1946-01-01	9	2001-04-29	9	KA	KA	KA
170508	Neue Zeit [[lokal]]	11	4	Graz	17	1	deutsch	1946-04-02	9	9999-01-01	9	KA	KA	Erscheint ab 02.04.1946? in 3, ab 01.05.1969? in 4, ab 14.11.1970 in 5, ab 01.02.1972 in 6, ab 19.04.1985 in 8 Lokalausgaben / ab 01.07.1987 im Eigentum der Mitarbeiter:innen
170560	Obersteirer Volksstimme	11	2	Bruck an der Mur	17	1	deutsch	1949-07-02	9	1951-06-30	9	KA	KA	2 mal wöchentlich
170622	Obersteirische Volkszeitung [1]	11	99	Leoben	17	1	deutsch	1895-01-03	9	1945-05-05	9	KA	KA	KA
170623	Obersteirische Volkszeitung [2]	11	99	Leoben	17	1	deutsch	1949-12-10	9	1969-03-29	9	KA	KA	2-3 mal wöchentlich / erscheint bis 20.12.1980 als Wochenzeitung, dann aufgegangen in > 170640 Obersteirische Zeitung - Obersteirische Volkszeitung
170631	Leobener Zeitung	11	99	Leoben	17	1	deutsch	1924-12-17	9	1929-08-31	9	KA	KA	2 mal wöchentlich / fortgeführt 08.09.1929-27.11.1932 als Wochenzeitung Leobener Sonntagspost
170632	Obersteirische Volkspresse	11	99	Leoben	17	1	deutsch	1934-10-03	9	1938-03-12	9	KA	KA	2 mal wöchentlich / gegründet 04.12.1932 als Wochenzeitung
170633	Obersteirische Zeitung	11	99	Leoben	17	1	deutsch	1946-11-09	9	1980-12-30	9	KA	KA	Erschien am 02.11.1946 zunächst als Wochenzeitung (nur eine Nummer), dann 2-3 mal wöchentlich
170640	Obersteirische Zeitung – OVZ Obersteirische Volkszeitung	11	99	Leoben	17	1	deutsch	1981-01-10	9	1997-12-31	9	KA	KA	Zusammenlegung mit > 170623 Obersteirische Volkszeitung / erschienen bis 20.12.2008 als Wochenzeitung
170650	Obersteirisches Tagblatt	11	5	Leoben	17	1	deutsch	1945-05-15	9	1945-07-29	9	KA	KA	Zeitung der Obersteirischen Freiheitskämpfer
170660	Obersteirisches Volksblatt	11	7	Leoben	17	1	deutsch	1945-08-18	9	1945-11-14	9	KA	KA	Zeitung der britischen Besatzungsmacht
170220	Kronen-Zeitung - Steirerkrone 	11	2	Graz	17	1	deutsch	2000-11-02	9	9999-01-01	9	Die Vielfalt der Meinungen ihres Herausgebers und der Redakteure.	KA	Erscheint in 2, ab 2004 in 5 Lokalausgaben
170390	Neue Kronen-Zeitung - Ausgabe für die Steiermark	11	2	Graz	17	1	deutsch	1972-10-01	9	2000-10-21	9	KA	KA	ab 13.02.1977 Steirerkrone / Erscheint ab 07.1985 in 2, ab 1989 in 3, ab 1991 in 5, ab 09.1993 in 2 Lokalausgaben
170680	Steirerblatt, Das 	11	4	Graz	17	1	deutsch	1946-01-01	9	1951-09-30	9	KA	KA	KA
170760	täglich Alles für die Steiermark	11	2	KA	17	0	deutsch	1992-10-11	9	1999-01-03	9	KA	KA	KA
170812	Tagespost - [Parteiamtliches Organ des Gaues Steiermark der NSDAP]	11	4	Graz	17	0	deutsch	1938-01-12	9	1945-05-09	9	KA	KA	Die Ausgabe vom 09.05.1945 ist bereits im Verlag der demokratischen > 17008 Grazer Volkszeitung erschienen.
171041	Wahrheit, Die	11	4	Graz	17	0	deutsch	1946-01-01	9	1952-04-30	9	KA	KA	KA
171042	Wahrheit und Volkswille	11	4	Graz	13	0	deutsch	1952-05-01	9	1971-01-31	9	KA	KA	KA
171043	W Wahrheit	11	4	Graz	17	0	deutsch	1971-02-02	9	1989-12-31	9	KA	KA	Das W im Titel fiel ab 14.04.1989 weg
171051	Weltpresse - Graz am Abend	11	7	Graz	17	0	deutsch	1947-12-08	9	1950-08-31	9	KA	KA	01.09.1950 - 31.08.1952 wurde die Abendausgabe der Wiener > 111920 Weltpresse nach Graz geliefert
171052	Weltpresse - Grazer Ausgabe	11	2	Graz	17	0	deutsch	1952-09-01	9	1957-02-28	9	KA	KA	KA
176010	Telegraf	11	2	Graz	17	0	deutsch	1855-01-01	4	1868-12-31	9	KA	KA	25.03.1868 - 07.1868 wurde die Morgenausgabe (nach Eigentumswechsel) vorübergehend in Wien hergestellt und in Graz und Wien vertrieben, die Abendausgabe aber weiterhin in Graz hergesetellt, vgl.Fruhmann (2013)
176020	Presse, Die - Steiermark	11	2	Wien	17	0	deutsch	2003-02-28	9	2005-12-31	9	KA	KA	KA
176030	Arbeiterwille 	11	4	Graz	17	0	deutsch	1900-10-16	9	1934-02-11	9	KA	KA	01.07.1905 mit der 1900 gegründeten Kärntner Wochenzeitung Volkswille zusammengelegt
180031	Arbeiter-Zeitung - Ausgabe für Tirol	11	4	KA	18	0	deutsch	1957-03-01	9	1962-01-31	9	KA	KA	KA
180032	Arbeiter-Zeitung - Tiroler AZ	11	4	KA	18	0	deutsch	1968-04-03	9	1971-06-30	9	KA	KA	KA
180061	Außferner Bote [1]	11	99	Reutte	18	1	deutsch	1927-10-08	9	1936-02-08	9	KA	KA	2 mal wöchentlich
180062	Außferner Bote [2]	11	4	Reutte	18	1	deutsch	1938-03-16	9	1940-07-22	9	KA	KA	2 mal wöchentlich
180120	Deutsche Volks-Zeitung	11	4	Innsbruck	18	0	deutsch	1938-03-14	9	1939-04-25	9	KA	KA	KA
170811	Tagespost	11	2	Graz	17	0	deutsch	1856-01-17	9	1938-01-11	9	KA	KA	KA
180200	Kronen-Zeitung - Tiroler Krone	11	2	Innsbruck	18	0	deutsch	2000-11-02	9	9999-01-01	9	Die Vielfalt der Meinungen ihres Herausgebers und der Redakteure.	KA	KA
180251	Kurier Ausgabe für Tirol	11	2	KA	18	0	deutsch	1976-06-01	9	1977-09-10	9	KA	KA	11.09.1977-06.11.1983 erschien eine Sonntagsausgabe für Tirol
180252	Kurier - Tirol	11	2	KA	18	0	deutsch	1983-11-11	9	2012-12-31	9	KA	KA	KA
180400	Neue Kronen-Zeitung - Tiroler Krone	11	2	Innsbruck	18	0	deutsch	1992-09-13	9	2000-10-31	9	KA	KA	KA
180430	Neue Tageszeitung - [Ausgabe für Tirol]	11	4	KA	18	0	deutsch	1950-06-01	9	1956-12-29	9	KA	KA	KA
180451	Neue Tiroler Zeitung - neue 	11	4	KA	18	0	deutsch	1973-05-26	9	1990-01-31	9	KA	KA	KA
180480	Neuer Außferner Bote	11	99	Reutte	18	1	deutsch	1936-02-29	9	1938-03-12	9	KA	KA	2 mal wöchentlich
180830	Tiroler AZ	11	4	KA	18	0	deutsch	1962-02-01	9	1968-04-02	9	KA	KA	KA
180840	Tiroler Nachrichten	11	5	Innsbruck	18	0	deutsch	1945-05-04	9	1945-05-04	9	KA	KA	In einer einzigen Ausgabe erschienene Zeitung der Österreichischen Widerstandsbewegung in Tirol
180851	Tiroler Nachrichten	11	4	KA	18	0	deutsch	1971-10-16	9	1973-05-25	9	KA	KA	KA
180860	Tiroler Neue Zeitung	11	4	Innsbruck	18	0	deutsch	1945-11-16	9	1950-05-31	9	KA	KA	KA
180920	Volksstimme - Ausgabe für Tirol	11	4	Wien	18	0	deutsch	1957-07-03	9	1963-05-31	9	KA	KA	KA
180971	Volkszeitung [1]	11	4	Innsbruck	18	0	deutsch	1907-01-01	9	1938-03-12	9	KA	KA	3 mal wöchentlich (vermutlich bereits vor 01.01.1907), ab 26.04.1911 täglich / Gegründet 10.12.1892 als 2-3 mal monatlich erscheinende Zeitung, vermutlich ab 01.1900 Wochenzeitung
180972	Volkszeitung [2}	11	4	Innsbruck	18	0	deutsch	1945-11-15	9	1957-02-28	9	KA	KA	KA
181610	Salzburger Landeszeitung	11	4	Salzburg	16	0	deutsch	1938-08-16	9	1942-11-15	9	KA	KA	Zusammengelegt mit > 160651 Salzburger Volksblatt
181830	Tiroler Bauern-Zeitung 	11	4	Innsbruck	18	0	deutsch	1938-03-22	9	1938-04-06	9	KA	KA	KA
300240	ATV2	30	2	Wien	20	0	deutsch	2011-12-01	9	9999-01-01	9	Erklärung über die grundlegende Richtung: ATV und ATV2 sind unabhängige private österreichische Fernsehsender.	KA	KA
300251	Puls TV	30	2	Wien	11	0	deutsch	2004-06-21	9	2008-01-27	9	KA	KA	Seit 29.08.2005 Puls Café  auf Puls TV, Sat.1 Österreich, ProSieben Austria und kabel eins Austria (dort nur bis 2007) / Im August 2007 wurde der Sender von der damaligen ProSiebenSat.1 Media AG übernommen (Seit 29.08.2005 Puls Café  auf Puls TV, Sat.1 Österreich, ProSieben Austria und kabel eins Austria (dort nur bis 2007))
178250	oe24 - Steiermark [[Gratis]]	11	2	Wien	17	0	deutsch	2018-08-29	9	2021-12-31	1	KA	KA	KA
181900	Neue - Zeitung für Tirol	11	2	Innsbruck	18	0	deutsch	2004-09-25	9	2008-03-31	9	KA	KA	KA
183830	Tiroler Landbote 	11	4	Innsbruck	18	0	deutsch	1940-07-09	9	1944-08-29	9	KA	KA	KA
186010	Allgemeiner Tiroler Anzeiger	11	4	Innsbruck	18	0	deutsch	1907-12-15	9	1922-12-30	9	KA	KA	KA
186020	Tiroler Anzeiger	11	4	Innsbruck	18	0	deutsch	1923-01-02	9	1938-03-11	9	KA	KA	KA
186030	Tiroler Stimmen	11	99	Innsbruck	18	0	deutsch	1861-01-01	4	1868-12-31	4	KA	KA	KA
186040	Neue Tiroler Stimmen	11	99	Innsbruck	18	0	deutsch	1868-05-11	9	1919-11-15	9	KA	KA	Aufgegangen am 17.11.1919 in > 186010 Allgemeiner Tiroler Anzeiger
189060	Landbote	11	4	Innsbruck	18	0	deutsch	1944-09-01	9	1945-04-27	9	KA	KA	2 mal wöchentlich
189931	Volksstimme - Ausgabe für Tirol und Vorarlberg	11	4	Wien	18	0	deutsch	1957-01-01	9	1957-07-02	9	KA	KA	KA
190040	Arbeiter-Zeitung - Ausgabe für Vorarlberg	11	4	KA	19	0	deutsch	1957-03-01	9	1962-01-31	9	KA	KA	KA
190121	Feldkircher Anzeiger [1]	11	99	Feldkirch	19	1	deutsch	1912-01-03	9	1917-05-19	9	KA	KA	2-3 mal wöchentlich
190122	Feldkircher Anzeiger [2]	11	99	Feldkirch	19	1	deutsch	1919-01-01	9	1920-12-29	9	KA	KA	2 mal wöchentlich 
190200	Kronen-Zeitung - Vorarlberg	11	2	Bregenz	19	0	deutsch	2000-11-02	9	9999-01-01	9	Die Vielfalt der Meinungen ihres Herausgebers und der Redakteure.	KA	Redaktion ab 03.2015 in Bregenz
190260	Kurier - Vorarlberg	11	2	KA	19	0	deutsch	1983-11-11	9	1993-04-19	9	KA	KA	KA
190410	Neue Kronen-Zeitung - Vorarlberg	11	2	KA	19	0	deutsch	1988-03-06	9	2000-10-31	9	KA	KA	KA
190440	Neue Tageszeitung	11	4	Bregenz	19	0	deutsch	1950-06-01	9	1956-12-29	9	KA	KA	01.01.1957-02.07.1957 aufgegangen in > 189931, 189932 Volksstimme - Ausgabe für Tirol und Vorarlberg
190470	Neue Vorarlberger Tageszeitung	11	2	Bregenz	19	0	deutsch	1972-05-02	9	9999-01-01	9	Die NEUE Vorarlberger Tageszeitung ist eine von allen politischen Parteien und Interessensvertretungen unabhängige Tageszeitung. Sie steht auf dem Boden christlicher Weltanschauung, tritt vorbehaltlos für eine plurale, demokratische Gesellschaftsordnung, die Eigenständigkeit der Bundesländer und die Unabhängigkeit der Republik ein.	KA	Ab 02.05.1975 redaktionelle Kooperation mit > 170150 Kleine Zeitung
190820	Tageszeitung	11	4	Bregenz	19	0	deutsch	1945-11-20	9	1950-05-31	9	KA	KA	KA
190940	Volksstimme - Ausgabe für Vorarlberg	11	4	Wien	19	0	deutsch	1957-07-03	9	1960-11-30	9	KA	KA	bis 05.05.1967 erschien noch eine Wochenendausgabe für Vorarlberg
190980	Vorarlberger AZ	11	4	KA	19	0	deutsch	1962-02-01	9	1968-04-02	9	KA	KA	KA
191000	Vorarlberger Tagesnachrichten	11	4	Bregenz	19	0	deutsch	1945-11-16	9	1945-11-19	9	KA	KA	KA
191011	Vorarlberger Volksblatt [1]	11	4	Bregenz	19	0	deutsch	1887-01-01	9	1938-03-11	9	KA	KA	2 mal wöchentlich, ab 01.01.1887 täglich
191012	Vorarlberger Volksblatt [2]	11	4	Bregenz	19	0	deutsch	1945-11-16	9	1972-04-28	9	KA	KA	KA
191020	Vorarlberger Volkswille	11	4	Feldkirch	19	0	deutsch	1945-11-15	9	1957-02-28	9	KA	KA	Feldkirch bis 04.01.1950 Redaktionsort, danach Innsbruck
191980	Vorarlberger Landbote	11	4	Innsbruck	18	0	deutsch	1940-07-10	9	1944-08-30	9	KA	KA	2 mal wöchentlich /Aufgegangen in > 189060 Landbote
191990	Vorarlberger Oberland	11	4	Feldkirch	19	0	deutsch	1938-08-03	9	1940-06-01	9	KA	KA	2-3 mal wöchentlich
199990	Vorarlberger Landes-Zeitung	11	2	Bregenz	19	0	deutsch	1963-08-11	9	1938-03-11	9	KA	KA	3 mal wöchentlich, ab 03.01.1887 täglich
200018	ORF Radio [[Dach]]	20	1	Wien	20	0	deutsch	1967-10-01	9	9999-01-01	9	KA	KA	KA
300252	PULS 4	30	2	Wien	20	0	deutsch	2008-01-28	9	9999-01-01	9	Erklärung über die grundlegende Richtung: PULS 4 ist ein unabhängiger privater österreichischer Fernsehsender.	KA	KA
300260	PULS 24	30	2	Wien	20	0	deutsch	2019-09-01	9	9999-01-01	9	Erklärung über die grundlegende Richtung: PULS 24 ist ein unabhängiger privater österreichischer Fernsehsender.	KA	Start am 20.10.2016 als HbbTV-Sender u.d.T. 4NEWS, der 2018 eingestellt wurde
190990	Vorarlberger Nachrichten	11	2	Bregenz	19	1	deutsch	1945-09-01	9	9999-01-01	9	demokratisch, föderalistisch, unabhängig	KA	Bis 15.11.1945 Dreiparteienblatt / Ort: ab 03.09.1996 Schwarzach - ab 1989? in 4 Lokalausgaben, zunächst mit einmal wöchentlicher, ab 24.08.2020 täglicher Berichterstattung
200020	Österreich 1 (Ö1)	20	1	Wien	20	0	deutsch	1967-10-01	9	9999-01-01	9	Österreich 1, einer der erfolgreichsten Kultursender Europas, bietet täglich 24 Stunden Programm auf höchstem Niveau. Information, Kultur, Literatur, Wissenschaft, Bildung, Religion und natürlich viel Musik – von der Klassik über zeitgenössische Musik bis zum Jazz - sind die Eckpfeiler von Ö1. Seine Position als DER „Festspielsender“ des ORF unterstreicht Ö1 mit über 150 Live-Übertragungen heimischer Festivals und einer Vielzahl an hochwertigen Konzertmitschnitten. Aber auch Diskussionen kontroversieller gesellschaftlicher Themen, Kabarett, Service, Neue Medien und Audiokunst haben hier ihren prominenten Platz. Mehr auf: https://der.orf.at/unternehmen/programmangebote/radio/oe-eins/index.html	KA	Nachrichten in deutscher und englischer Sprache
200035	Österreich Regional	20	1	Wien	20	0	deutsch	1967-10-01	9	1990-05-01	9	KA	KA	Gemeinsames Rahmenprogramm der ORF-Regionalradios, das nur stundenweise durch Regionalfenster unterbrochen wurde
200036	Österreich 2 (Ö2)  [[Dach]]	20	1	Wien	20	0	deutsch	1990-05-02	9	9999-01-01	9	KA	KA	Bis Mitte der 1990er Jahre bestand noch ein gemeinsames Rahmenprogramm, das nur stundenweise durch Regionalfenster unterbrochen wurde.
200041	Ö3 - Hitradio Ö3	20	1	Wien	20	0	deutsch	1967-10-01	9	9999-01-01	9	Topaktuelle Nachrichten, die Themen des Tages, der schnellste Verkehrsservice Österreichs und der beste Musikmix machen Ö3 zum Lieblingsradio der Österreicher/innen. Hitradio Ö3 ist Österreichs Informations- und Serviceradio mit dem besten Musikmix. Ö3 spielt aktuellen Pop im Mix mit den Top-Songs aus dem Bereich Pop Rock der 80er, 90er und 2000er. Mehr auf: https://der.orf.at/unternehmen/programmangebote/radio/oe-drei/index.html	KA	KA
200051	Kurzwellendienst des Österreichischen Rundfunks	20	1	Wien	20	0	mehrsprachig	1955-01-01	1	1985-12-31	4	KA	KA	KA
200052	Radio Österreich International 	20	1	Wien	20	0	mehrsprachig	1985-01-01	4	2003-06-30	9	KA	KA	KA
200053	Ö1 International	20	1	Wien	20	0	mehrsprachig	2003-07-01	9	2009-12-31	9	KA	KA	KA
200060	Blue Danube Radio	20	1	Wien	20	0	mehrsprachig	1979-08-23	9	2000-01-31	9	KA	KA	KA
200070	FM4	20	1	Wien	20	0	mehrsprachig	1995-01-16	9	9999-01-01	9	FM4 ist ein Sender mit einem hohen Wortanteil, der zudem seine Musik als ebenso eigenständige kulturelle Äußerung darstellt und damit, ähnlich wie Österreich 1, zu seinem öffentlich-rechtlichen Auftrag auch einen umfassenden Kulturbegriff lebt. Die lineare On-Air-Performance sowie die FM4-Website fm4.ORF.at samt FM4-App, Player, Stream oder On-Demand- bzw. Podcast-Angebote machen FM4 als öffentlich-rechtlichen Hauptansprechpartner der „Digital Natives“ für alle und zu jeder Zeit hörbar und erlebbar. Mehr auf: https://der.orf.at/unternehmen/programmangebote/radio/fm-vier/index.html	KA	KA
200081	Radio 1476	20	1	Wien	20	0	mehrsprachig	1997-03-21	9	2008-12-31	9	KA	KA	KA
200082	Ö1 Campus - https://oe1.orf.at/campus	40	1	Wien	20	0	mehrsprachig	2009-01-01	9	9999-01-01	9	KA	KA	Internetradio
200085	Radio Nachbar in Not	20	1	Wien	20	0	mehrsprachig	1999-04-26	9	2002-12-31	4	KA	KA	KA
200086	donaudialog	20	1	Wien	20	0	mehrsprachig	2000-01-01	4	2002-10-26	9	KA	KA	KA
200090	Ö1 Inforadio - https://oe1.orf.at/inforadio	40	1	Wien	20	0	deutsch	2003-01-01	4	2011-04-30	4	KA	KA	Internetradio
200135	Radio Wien	20	1	Wien	11	0	deutsch	1967-10-01	9	9999-01-01	9	KA	KA	KA
200235	Radio Burgenland	20	1	Eisenstadt	12	0	mehrsprachig	1967-10-01	9	9999-01-01	9	KA	KA	KA
200335	Radio Kärnten	20	1	Klagenfurt	13	0	mehrsprachig	1967-10-01	9	9999-01-01	9	KA	KA	KA
200435	Radio Niederösterreich	20	1	St. Pölten	14	0	deutsch	1967-10-01	9	9999-01-01	9	KA	KA	KA
200535	Radio Oberösterreich	20	1	Linz	15	0	deutsch	1967-10-01	9	9999-01-01	9	KA	KA	KA
200635	Radio Salzburg	20	1	Salzburg	16	0	deutsch	1967-10-01	9	9999-01-01	9	KA	KA	KA
200735	Radio Steiermark	20	1	Graz	17	0	deutsch	1967-10-01	9	9999-01-01	9	KA	KA	KA
200835	Radio Tirol	20	1	Innsbruck	18	0	deutsch	1967-10-01	9	9999-01-01	9	KA	KA	KA
200935	Radio Vorarlberg	20	1	Dornbirn	19	0	deutsch	1967-10-01	9	9999-01-01	9	KA	KA	KA
230010	Radio Agora	20	3	Klagenfurt	20	0	mehrsprachig	1998-10-26	9	9999-01-01	9	adio AGORA 105 I 5 ist seit dem Sendestart 1998 ein medialer (Kunst- und Experimentier-) Raum für slowenisch-, deutsch-, zwei- und mehrsprachige Hörer_innen und Radiomacher_innen in Kärnten und der Südsteiermark und für zugewanderte Menschen, ihre Sprache und Kultur, mit dem Ziel, zur Förderung der Verständigung zwischen den Bevölkerungsgruppen beizutragen. Wir verstehen uns als mehrsprachiges Forum - mit einem Schwerpunkt auf Musik und Literatur aus dem Alpen-Adria-Raum - und als Plattform zur Mitgestaltung für Künstler_innen und Kulturarbeiter_innen, sowie zivilgesellschaftlich engagierte Menschen und Initiativen aus der Region. Als Freies Radio sind wir Sprachrohr für in Gesellschaft und Medien marginalisierte und/oder diskriminierte Menschen und brisante Themen. Wir gestalten Programm, vermitteln Medienkompetenz, beteiligen uns an medienpolitischen Entwicklungen und sind Kooperationspartner für Kulturveranstalter_innen und Bildungseinrichtungen, sowie sozial, feministisch, queer, integrativ, ökologisch und zeitgeschichtlich engagierte Initiativen. Wir verschaffen Un.er.hörtem Gehör! Mehr auf: https://www.agora.at/home	KA	https://de.wikipedia.org/wiki/Radio_AGORA
300010	Österreichischer Rundfunk - ORF Fernsehen [[Dach]]	30	1	Wien	20	0	deutsch	1961-09-11	9	9999-01-01	9	Veranstaltung eines Informations- und Kultur-Spartenprogramms gem. § 4c ORF-G sowie der Betrieb eines entsprechenden Online-Dienstes und Teletext.	KA	KA
300011	Österreichisches Fernsehen	30	1	Wien	20	0	deutsch	1955-08-01	9	1961-09-10	9	KA	KA	3 mal wöchentlich, ab 01.01.1957 6 mal wöchentlich, ab 10.1959 täglich (https://der.orf.at/unternehmen/chronik/index.html)
300012	FS 1	30	1	Wien	20	0	deutsch	1961-09-11	9	1992-10-25	9	KA	KA	KA
300013	ORF 1	30	1	Wien	20	0	deutsch	1992-10-26	9	9999-01-01	9	ORF 1 ist der beim jungen Publikum erfolgreichste österreichische TV-Sender. ORF 1 bietet seinen Seherinnen und Sehern unter anderem ein umfangreiches Angebot aus österreichischer Unterhaltung und Comedy, beliebten österreichischen Filmen und Serien, umfassender speziell für junges Publikum gestalteter Information, attraktiven Sport-Live-Übertragungen, eigenproduziertem Kinderprogramm und vielem mehr. Internationale Top-Filme und –Serien runden das ORF 1- Programmbouquet ab.	KA	01.2011 - 04.2018 ORF eins
300021	FS 2	30	1	Wien	20	0	deutsch	1961-09-11	9	1992-10-25	9	KA	KA	3 mal wöchentlich, ab ???? 5 mal wöchentlich, ab 01.09.1970 täglich, ab 02.04.1989 mit Informationsangebot in Kroatisch und Serbisch und der mehrsprachigen Sendung Heimat, fremde Heimat
300270	ProSieben	30	2	KA	20	0	deutsch	1993-01-01	4	1998-06-30	4	KA	KA	ab 1993 Marktanteilsdaten verfügbar, 1998: österreichisches Werbefenster
300022	ORF 2	30	1	Wien	20	0	deutsch	1992-10-26	9	9999-01-01	9	ORF 2 ist der mit großem Abstand meistgenutzte TV-Sender Österreichs. ORF 2 präsentiert seinem Publikum ein umfassendes Programmangebot aus aktuellster Information, innovativem Frühfernsehen, hochwertiger Kultur und Bildung, attraktiver Unterhaltung, Service, Wirtschaft, Wissenschaft, Religion uvm. aus Österreich. Erfolgreiche, österreichische Filme, Serien und Dokumentationen stehen ebenso auf dem Programm wie hochwertige Live-Übertragungen aus den unterschiedlichsten Genres und Bereichen, Magazine, Talk- und Diskussionsformate uvm. Die erfolgreichen Programme der neun ORF-Landesstudios sind ebenso unverzichtbarer Bestandteil des ORF 2- Programmbouquets.	KA	KA
300030	TW1	30	1	Wien	20	0	deutsch	1997-10-01	9	2011-10-25	9	KA	KA	TW1 war zwar seit Oktober 2005 zu 100 % im Besitz des ORF (zuvor 50%) und der rechtliche Rahmen war nach § 9 des ORF-Gesetzes vorgegeben, für die Finanzierung des Senders durften jedoch keine Mittel aus den Rundfunkgebühren verwendet werden. TW1 galt daher nicht als öffentlich-rechtlicher Sender. / Die inhaltliche Nachfolge wird eher durch Sport+ erfüllt, die Frequenz bekam jedoch ORF III
300040	ORF III	30	1	Wien	20	0	deutsch	2011-10-26	9	9999-01-01	9	Der Spartenkanal ORF III Kultur und Information bietet eine breite Bühne für Kunst, Kultur, Zeitgeschichte, Dokumentation, Wissenschaft, Information und österreichischen Film. Eine der wesentlichen Säulen von ORF III Kultur und Information ist die Live-Berichterstattung aus dem österreichischen Parlament mit mehr als 400 Stunden Politik-Live-Übertragungen der Plenarsitzungen des Nationalrats, des Bundesrats, von Enqueten und Ausschüssen. ORFIII hat sich seit seinem Start 2011 beim kulturinteressierten Publikum sehr gut etabliert und gilt als einer der erfolgreichsten Kultursender im deutschsprachigen Raum.	KA	KA
300049	ORF Sport Plus	30	8	Wien	20	0	deutsch	2006-05-01	9	2011-10-25	9	KA	KA	Seit Mai 2000 gab es eine eigene Sportschiene im Programm von TW1 / Bis 25.10.2011 teilte sich der Sender, der kein Vollprogramm ausstrahlte, die Frequenz mit TW1
300050	ORF Sport+	30	8	Wien	20	0	deutsch	2011-10-26	9	9999-01-01	9	Der Sportspartensender ORF SPORT + bietet seit seinem Start 2011 eine mediale Plattform für Spitzen- und Breitensport sowie sogenannte Randsportarten aus Österreich. Mit der Berichterstattung über Sportdisziplinen, die in der Regel weniger im medialen Rampenlicht stehen, leistet ORF SPORT + einen wichtigen Beitrag zur Absicherung der Vielfalt der heimischen Sportlandschaft. Starker Österreichbezug und die enge Zusammenarbeit mit heimischen Verbänden und Veranstaltern spielt bei ORF SPORT + eine zentrale Rolle. 	KA	26.10.2011 SPORT+ zu einem 24-Stunden-Spartenkanal ausgebaut
300060	3sat	30	1	KA	20	0	deutsch	1984-12-01	9	9999-01-01	9	Seit 1. Dezember 1984 bietet der ORF gemeinsam mit dem Zweiten Deutschen Fernsehen (ZDF) und der Schweizerischen Rundfunkanstalt (SF DRS) ein internationales deutschsprachiges Satelliten-Fernsehprogramm. Seit dem Beitritt des Ersten Deutschen Fernsehens (ARD) Ende 1993 sind alle vier öffentlich-rechtlichen Rundfunkanstalten des deutschen Sprachraums an 3sat beteiligt.Einziges Gemeinschaftsprogramm des deutschen Sprachraums, Vollprogramm mit kulturellem Schwerpunkt, keine Werbung. Der ORF steuert 25 Prozent des Programms bei. Das Schwergewicht liegt auf Kultur und Information. Theater, Oper, Ballett, Konzertübertragungen, Magazine und Dokumentationen aus Österreich werden via 3sat einem internationalen Publikum zugänglich. 	KA	Von ARD, ORF, SRG und ZDF gemeinsam betrieben
300070	ORF Sat	30	1	Wien	20	0	deutsch	1997-01-01	4	2000-12-31	4	KA	KA	Europaweit ausgestrahlte Sendungen von ORF 2 und TW1
300080	ORF 2 Europe	30	1	Wien	20	0	deutsch	2004-07-05	9	9999-01-01	9	ORF 2 Europe (ORF 2E) ist das über Digitalsatellit frei empfangbare europaweite TV-Angebot von ORF 2. Damit ist es möglich, Informationen, Unterhaltung und Kultur aus Österreich auch im Ausland unmittelbar zu erfahren und zu erleben.	KA	Europaweit ausgestrahlte Sendungen von ORF2
300100	OKTO	30	3	Wien	11	0	mehrsprachig	2005-11-28	9	9999-01-01	9	Okto ist urbanes Fernsehen, bei dem engagierte Menschen und\nGruppen selbst Programminhalte gestalten und produzieren können. Okto steht für die Förderung einer modernen parlamentarischen Demokratie, die im hohen Maße von einer aktiven und\nselbstbewussten Zivilgesellschaft mitgetragen und mitbestimmt werden soll. Zivilgesellschaft und Rechtsstaatlichkeit\nstehen dabei als Garanten gegen jede Form der Xenophobie,\nsowie des Totalitarismus und des Extremismus.\nOkto steht für eine gerechtere und tolerantere Gesellschaft ein.\nFür Okto bilden die Menschenrechte im Sinne der Europäischen Menschenrechtskonvention, vor allem aber Werte wie\nFreiheit der Meinungsäußerung, die Würde des Menschen\nsowie die Gleichberechtigung aller Menschen, unabhängig\nvon ihrer ethnischen oder sozialen Herkunft, ihrer sexuellen\noder religiösen Orientierung, die Grundlage der gesamten\nFirmenpolitik.	KA	KA
300110	Dorf tv	30	3	Linz	15	0	mehrsprachig	2010-06-22	9	9999-01-01	9	DORFTV. Mach dir selbst ein Bild! Medien und Gesellschaft im 21. Jahrhundert. Monokultur, Profitdenken und Desinformation bedrohen den demokratischen Zusammenhalt. Wir leisten jedoch Widerstand, kämpfen für Unabhängigkeit und öffentlichen Zugang, für Teilhabe und Vielfalt, für Community-TV.\n\nMach dir selbst ein Bild! Zeigen wir's ihnen!\n\nSeit 22. Juni 2010 sendet DORFTV als nicht kommerzieller regionaler Sender in Oberösterreich.	KA	KA
300120	FS1 - Freies Fernsehen Salzburg	30	3	Salzburg	16	0	mehrsprachig	2012-02-16	9	9999-01-01	9	FS1 ist das Freie Fernsehen Salzburg. Wir sind Alternative zu ORF und Kommerz. Produziert von Salzburger:innen für Salzburg. Dein Fernsehen heißt, jede*r kann mitmachen. Wir sind werbefrei. Wir sind das Bild von Salzburg, das sonst nicht vorkommt. Wir sind unabhängig. Wir sind das, was die Zivilgesellschaft des Landes interessiert. Wir sind Kunst, Kultur, Jugend, Soziales. Wir sind Salzburger Bands. Wir sind mehrsprachig. Wir sind intelligent. Wir sind ein Programm von vielen für viele. Und wir bilden Dich zu dem allen aus.	KA	KA
300200	Salzburg TV	30	2	Salzburg	16	0	deutsch	1995-09-17	9	2009-12-31	4	KA	KA	Bis zur Lizenzierung (2002) nach Inkrafttreten des Privatfernsehgesetzes als Piratensender betrieben
300220	W1	30	2	Wien	11	0	deutsch	1997-01-01	4	2000-01-16	9	KA	KA	Ausschließlich im Wiener Kabelnetz empfangbar
300231	ATV [1]	30	2	Wien	20	0	deutsch	2000-01-17	9	2003-05-31	9	KA	KA	Ausschließlich im Kabelnetz empfangbar
300232	ATV+	30	2	Wien	20	0	deutsch	2003-06-01	9	2006-06-01	9	KA	KA	Erster bundesweiter terrestischer Privatfernsehsender
300233	ATV [2]	30	2	Wien	20	0	deutsch	2006-06-02	9	9999-01-01	9	Erklärung über die grundlegende Richtung: ATV und ATV2 sind unabhängige private österreichische Fernsehsender.	KA	Nach Auslaufen der der Auflagen der Bundeswettbewerbsbehörde zum Jahresende 2023 wurde die Fusion von ATV mit den beiden Puls4-Sendern komplett umgesetzt (https://kurier.at/kultur/medien/weniger-show-mehr-leben-was-der-neue-chef-von-atv-und-puls4-plant/402299288
300271	ProSieben Austria	30	2	KA	20	0	deutsch	1998-07-01	4	9999-01-01	9	KA	KA	ab 1993 Marktanteilsdaten verfügbar, 1998: österreichisches Werbefenster, 26.01.2004: Start einer österreichischen Nachrichtensendung (damals: ProSieben AustriaNews) (https://www.prosiebensat1puls4.com/n/anderezeitenanderenews_austriatopnews_060418), ab 29.08.2005 Puls Café übernommen (https://de.wikipedia.org/wiki/Caf%C3%A9_Puls, Seit 29.08.2005 Puls Café  auf Puls TV, Sat.1 Österreich, ProSieben Austria und kabel eins Austria )
300280	SAT.1	30	2	KA	20	0	deutsch	1993-01-01	4	2000-06-30	4	KA	KA	ab 1993 Marktanteilsdaten verfügbar, 2000: Start von GO! Das Motormagazin
300281	SAT.1 Österreich	30	2	KA	20	0	deutsch	2000-07-01	4	9999-01-01	9	KA	KA	ab 1993 Marktanteilsdaten verfügbar, 2000: Start von GO! Das Motormagazin, ab 29.08.2005 Puls Café übernommen (https://de.wikipedia.org/wiki/Caf%C3%A9_Puls, Seit 29.08.2005 Puls Café  auf Puls TV, Sat.1 Österreich, ProSieben Austria und kabel eins Austria ), ab 17.03.2008 eine österreichische Nachrichtensendung (damals: Puls 4 News)
300290	Kabel Eins	30	2	KA	20	0	deutsch	1993-01-01	4	1999-06-30	4	KA	KA	ab 1993 als in Österreich verbreitetes MA geführt, ab 1995 Marktanteilsdaten verfügbar, ab 1999 österreichisches Werbefenster
300291	Kabel Eins Austria	30	2	KA	20	0	deutsch	1999-07-01	4	9999-01-01	9	KA	KA	ab 1999 österreichisches Werbefenster, die ab 2004 [?] gesendeten täglichen österreichischen Nachrichten (damals: AustriaNews) werden mittlerweile - wie seit 2007 auch Café Puls - nicht mehr übernommen und laufen nur mehr auf Puls 4, ProSieben Austria und Sat.1 Österreich
300300	Kabel Eins Doku Austria	30	2	KA	20	0	deutsch	2016-09-22	9	9999-01-01	9	KA	KA	Doku-Sender mit regelmäßigen 4NEWS Updates (=eigener HbbTV Sender, integriert in Kabel Eins Doku Austria und am 21.03.2018 in 4mediathek umgewandelt) aus der PULS 4 Redaktion
300310	Austria 9	30	2	Wien	20	0	deutsch	2007-12-12	9	2012-07-02	9	KA	KA	KA
300320	sixx Austria	30	2	KA	20	0	deutsch	2012-07-03	9	9999-01-01	9	KA	KA	KA
300330	Sat.1 GOLD Österreich	30	2	KA	20	0	deutsch	2014-06-01	1	9999-01-01	9	KA	KA	KA
300340	ProSieben MAXX Austria	30	2	KA	20	0	deutsch	2014-06-01	1	9999-01-01	9	KA	KA	KA
300350	RTL	30	2	KA	20	0	deutsch	1993-01-01	4	9999-01-01	9	KA	KA	ab 1993 Marktanteilsdaten verfügbar, 01.04.1996: österreichisches Werbefenster (https://www.derstandard.at/story/2000100991166/rtl-gruppe-beendet-ihr-oesterreich-zoelibat-programmfenster-in-planung)
300360	RTL II	30	2	KA	20	0	deutsch	1993-03-06	9	9999-01-01	9	KA	KA	ab 07.10.2019: RTL Zwei
300370	Super RTL	30	2	KA	20	0	deutsch	1995-04-28	9	9999-01-01	9	KA	KA	KA
300380	RTL Nitro A	30	2	KA	20	0	deutsch	2014-10-16	9	9999-01-01	9	KA	KA	Österreichisches Werbefenster
300391	RTLplus	30	2	KA	20	0	deutsch	2016-06-04	9	2021-09-15	9	KA	KA	KA
300392	RTL UP	30	2	KA	20	0	deutsch	2021-09-16	9	9999-01-01	9	KA	KA	KA
300400	n-tv	30	2	KA	20	0	deutsch	1996-01-01	4	2019-04-23	9	KA	KA	ab 1996 Marktanteilsdaten verfügbar, davor als in Österreich verbreitetes MA geführt, 23.04.2019 Zulassung n-tv Austria
300401	n-tv Austria	30	2	KA	20	0	deutsch	2019-04-24	9	9999-01-01	9	KA	KA	23.04.2019 Zulassung n-tv Austria, 24.04.2019 erste österreichische Sendung (gemeinsam mit krone.tv), n-tv Austria ist der erste Sender der Mediengruppe RTL mit Programminhalten aus Österreich (https://brutkasten.com/artikel/n-tv-programmfenster-oesterreich) / Österreich-Fenster vermutlich 2021 oder 2022 wieder eingestellt
300410	VOX	30	2	KA	20	0	deutsch	1993-01-25	9	9999-01-01	9	KA	KA	ab 1996 Marktanteilsdaten verfügbar, davor als in Österreich verbreitetes MA geführt
300420	VIVA Austria	30	2	KA	20	0	deutsch	2001-01-01	9	2018-12-31	9	KA	KA	KA
300430	Nickelodeon Austria	30	2	KA	20	0	KA	2006-06-01	9	9999-01-01	9	KA	KA	01.10.2014 - 30.09.2021 mit 24-Stunden-Programm.
300440	Comedy Central Austria	30	2	KA	20	0	KA	2011-01-01	9	9999-01-01	9	KA	KA	KA
300450	MTV	30	2	KA	20	0	KA	1997-03-07	9	9999-01-01	9	KA	KA	MTV Europe, ab 07.03.1997: MTV Germany
300460	MTV Music 24	30	2	KA	20	0	KA	2008-10-28	9	2021-06-01	9	KA	KA	https://dewiki.de/Lexikon/MTV_Music
300470	Nick Music	30	2	KA	20	0	KA	2021-06-01	9	9999-01-01	9	KA	KA	https://dewiki.de/Lexikon/Nick_Music
300480	Kika	30	2	KA	20	0	deutsch	1997-01-01	9	9999-01-01	9	KA	KA	Von ARD und ZDF gemeinsam betrieben
300490	arte	30	2	KA	20	0	deutsch	1998-01-01	4	9999-01-01	9	Seit 1998 gibt es eine Kooperation des ORF mit dem deutsch-französischen Kulturkanal ARTE, seit April 2001 ist der ORF assoziiertes Mitglied von ARTE und damit in das institutionelle Leben der ARTE-Zentrale in Straßburg eingebunden. Für den ORF bietet die Kooperation mit ARTE die Chance, die Stimme Österreichs in Europa zu verstärken und vor allem auf dem von 3sat kaum berührten französischen Markt als Kulturproduzent aufzutreten.	KA	ARD (Vertretung durch den SWR), ZDF und France Télévisions, Französischer Staat, Radio France, Institut national de l’audiovisuel
300491	eXXpressTV	30	2	Wien	20	0	deutsch	2021-06-16	9	9999-01-01	1	eXXpress ist ein bürgerlich-liberales Digitalmedium für Politik und Wirtschaft, dessen objektive, wahrheitsgetreue und kritische Berichterstattung der Information der Öffentlichkeit dienen soll. eXXpress ist von politischen Parteien und Interessenvertretungen unabhängig. eXXpress tritt für eine der Würde des Menschen angemessene und seine freie Entfaltung auf allen Gebieten fördernde Gesellschaftsordnung ein, ebenso für eine Stärkung der persönlichen Freiheitsrechte, der Meinungsfreiheit sowie für eine Förderung von Toleranz im Sinne des Humanismus und der Aufklärung. eXXpress bekennt sich hierbei zur Demokratie, zur Rechtsstaatlichkeit auf allen Ebenen, zur sozialen Gerechtigkeit, zur Eigenverantwortlichkeit des Menschen und zur Stärkung des Individuums an sich, zum Erhalt des privaten Eigentums, zu den Grundsätzen der sozialen Marktwirtschaft, zum freien Unternehmertum und zum Leistungswettbewerb.	KA	Internet-TV: exxpress.at, www.youtube.com/c/eXXpressTV (https://de.wikipedia.org/wiki/Exxpress#cite_note-diepresse-14, https://extradienst.at/exxpress-at-startet-mit-tv-sender/)
300500	ARD	30	1	KA	20	0	deutsch	1993-01-01	4	9999-01-01	9	KA	KA	ab 1993 Marktanteilsdaten verfügbar
300501	ARD alpha	30	1	KA	20	0	deutsch	2014-06-29	9	9999-01-01	9	KA	KA	KA
300510	ZDF	30	1	KA	20	0	deutsch	1993-01-01	9	9999-01-01	9	KA	KA	ab 1993 Marktanteilsdaten verfügbar
300520	ARD 3 [[Dach]]	30	1	KA	20	0	deutsch	2012-01-01	9	9999-01-01	9	KA	KA	Dach der neun Landesrundfunkanstalten der ARD] / schon ab 2012 in Österreich empfangbar? (https://www.wikidata.de-de.nina.az/Fernsehen_in_%C3%96sterreich.html) 
300530	DMAX Austria	30	2	KA	20	0	deutsch	2012-01-01	9	9999-01-01	9	KA	KA	Österreichisches Werbefenster
300540	TLC	30	2	KA	20	0	englisch	2019-01-01	9	9999-01-01	9	KA	KA	KA
300550	Discovery	30	2	KA	20	0	KA	2019-01-01	4	9999-01-01	9	KA	KA	ab 2019 Marktanteilsdaten verfügbar
300560	CANAL+ First	30	2	KA	20	0	deutsch	2022-03-15	9	9999-01-01	9	KA	KA	Canal+ Austria ist der erste österreichische Streaming-Dienst mit einem eigenen Fernsehsender, Kooperation mit Kleine Zeitung
300570	N24 Austria	30	2	KA	20	0	deutsch	2016-04-02	9	2018-01-17	9	KA	KA	KA
300571	N24 Doku Austria	30	2	KA	20	0	deutsch	2018-01-18	9	9999-01-01	9	KA	KA	Änderung aufgrund eines Eigentumwechsels von ProSieben Sat.1 zu Die Welt
300581	DSF	30	2	KA	20	0	deutsch	1993-01-01	9	2010-04-11	9	KA	KA	https://de.wikipedia.org/wiki/Sport1%2B
300582	Sport1	30	2	KA	20	0	deutsch	2010-04-11	9	9999-01-01	9	KA	KA	https://de.wikipedia.org/wiki/Sport1 / zusätzlich ab 04.10.2010: Pay-TV-Variante Sport1+ (https://de.wikipedia.org/wiki/Sport1%2B)
300590	Eurosport	30	2	KA	20	0	deutsch	1993-01-01	4	9999-01-01	9	KA	KA	1993 Marktanteilsdaten verfügbar / ab 13.11.2015: Eurosport 1
300600	Bayerisches Fernsehen	30	1	KA	20	0	deutsch	1993-01-01	4	9999-01-01	9	Da bin ich daheim	KA	ab 11.04.2016: BR Fernsehen
300601	BR alpha	30	1	KA	20	0	deutsch	2000-06-01	9	2014-06-28	9	KA	KA	Gegründet 07.01.1998, doch alpha Österreich wird erst seit 01.06.2000 ausgestrahlt
300640	laola1.tv	30	2	Wien	20	0	deutsch	2007-07-10	9	9999-01-01	4	LAOLA1.at ist Österreichs größtes Sportportal und ein Unternehmen der Sportradar Media Services GmbH.	KA	Seit 01.07.2021 leitet laola1.tv auf laola1.at weiter, das Videoportal wurde, bis auf wenige Sparten, gänzlich eingestellt. (https://de.wikipedia.org/wiki/Laola1.tv)
300700	TIV	30	2	Wien	11	0	deutsch	1999-05-01	9	2001-12-01	9	KA	KA	Mitgründer von TIV wie Amina Handke und Alf Altendorf waren ab 2002 an der Konzeption des Wiener Community-TV Okto und des Salzburger Freien Fernsehens FS1 beteiligt.
300710	gotv	30	2	Wien	20	0	deutsch	2002-10-01	9	2022-06-01	9	KA	KA	KA
300720	Jedermann TV	30	2	Salzburg	16	0	deutsch	2011-10-11	9	2012-04-30	9	KA	KA	Von Ferdinand Wegscheider, dem Gründer von Salzburg TV, zusammen mit weiteren Gesellschaftern betrieben. 2014 ging er zu Servus TV, den von Red Bull erworbenen Nachfolger von Salzburg TV.
300730	Salzburg Plus	30	2	Wals-Himmelreich	16	0	deutsch	2010-10-11	9	2012-01-31	9	KA	KA	KA
300740	R9 [[Dach]]	30	2	Wien	20	0	deutsch	2013-09-01	1	9999-01-01	9	Regionales Fernsehen Österreich	KA	R9 Regional TV Austria GmbH ist ein Fernsehvermarkter von 9 Regionalsendern, seit 2015 mit eigenem Fernsehprogramm
300741	W24	30	6	Wien	11	0	deutsch	2005-03-10	9	9999-01-01	9	Die aktuellen Geschehnisse des Tages in 24 Stunden Wien, Hintergrunddokumentationen aus den Bezirken, aktuelle Großereignisse in Wien, Kultur, Fashion- und Lifestylemagazine oder Zukunfts- und Wirtschaftsthemen aus einer der am schnellsten wachsenden europäischen Großstädte. W24 setzt sich wie kein anderer Sender intensiv mit aktuellen Themen der Stadt und ihrer Bewohnerinnen und Bewohner auseinander. Durch seine Nachrichtenkompetenz, seine „Live & vor Ort“-Präsenz und seine aktuellen TV-Formate bietet das Wiener Stadtfernsehen Information, Service und Unterhaltung für alle Wienerinnen und Wiener. Mehr auf: https://www.w24.at/Ueber-uns/Uebersicht	KA	Einziger Kabelsender im Besitz der Stadt Wien 
300742	KT1 - Kärnten 1	30	2	Klagenfurt	13	0	deutsch	1999-01-01	4	9999-01-01	9	KT1 ist ein von allen Parteien und Interessenvertretungen unabhängiger privater Fernsehveranstalter. Er stützt sich auf demokratische und humanitäre Grundrechte und ist der Meinungsvielfalt verpflichtet. Sein Programm gestaltet sich besonders nach regionalen Ereignissen aus Politik, Wirtschaft, Kultur, Sport und Gesundheit und bietet bunte und thematisch abwechslungsreiche Inhalte. (https://www.kt1.at/impressum/)	KA	Bis 2009 noch unter der Schirmherrschaft der Styria Media AG wurde der Sender dann von drei Kärntnern übernommen.
300743	N1 TV	30	2	St. Pölten	14	1	deutsch	2001-06-15	9	2022-11-01	1	N1 TV produziert ein regionales niederösterreichisches Fernsehprogramm aus den Bereichen Gesellschaft, Politik, Kultur und Sport im Rahmen einer mindestens einstündigen Wochenausgabe mit täglicher 24-stündiger Wiederholung.	KA	https://regiowiki.at/w/index.php?title=N1_Nieder%C3%B6sterreich_TV&mobileaction=toggle_view_desktop
300744	LT1	30	2	Linz	15	1	deutsch	2001-01-01	4	9999-01-01	9	KA	KA	Partnersender von WT1
300745	RTS - Regional TV Salzburg	30	2	Wals-Himmelreich	16	0	deutsch	2009-11-04	9	9999-01-01	9	Wir sind das regionale Fernsehen für das Bundesland Salzburg. Wir produzieren ein redaktionelles Bewegtbild-Programm für Fernsehen, Internet und soziale Netzwerke. Unsere Inhalte geben das Leben im Bundesland Salzburg wieder. Wir befassen uns mit einer großen Bandbreite an Themen wie Politik, Kultur, Sport, Wirtschaft, Brauchtum sowie dem ganz alltäglichen Vereins- und Gemeindeleben. Wir verstehen uns als journalistisches Medium, das eine große Verantwortung gegenüber seinem Publikum hat und das für gewissenhafte Informationsverarbeitung steht. Unser Programm bietet kritische Information und familienfreundliche Unterhaltung. Wir machen Fernsehen das frei ist von Gewalt, Sensationslust und reißerischen Aufmachungen. Wir und unsere Inhalte sind stets respektvoll aber kritisch, modern aber bodenständig sowie sachlich und politisch neutral. Land und Leute stehen im Mittelpunkt unserer Berichterstattung.	KA	KA
300746	Kanal3 - das regionale Fernsehen	30	2	Judenburg	17	1	deutsch	2011-01-01	4	9999-01-01	9	„Informationen aus und für die Region - wir halten Sie auf dem Laufenden.	KA	KA
300747	Tirol TV [1]	30	2	Innsbruck	18	1	deutsch	1997-06-01	1	2013-01-01	4	KA	KA	KA
300750	BKF	30	2	Eisenstadt	12	0	deutsch	1997-01-01	4	2011-12-01	1	Unabhängig - Parteifrei - Neutral	KA	KA
300760	Schau TV	30	2	Wien	12	0	deutsch	2012-02-01	1	2023-02-01	1	KA	KA	KA
300780	Krone TV	30	2	Wien	20	0	deutsch	2020-09-27	9	9999-01-01	9	krone.at versteht sich als das Internet-Portal für alle Österreicher und Internet-Nutzer des gesamten deutschsprachigen Raumes. krone.at ist unabhängig. krone.at bündelt mediengerecht das Beste aus allen Informations- und Unterhaltungsbereichen.	KA	KA
300781	Kronehit TV	30	2	Wien	20	0	deutsch	2015-04-22	9	9999-01-01	9	Unterhaltungssender (und dessen Webauftritt) für erwachsene ÖstereicherInnen mit den Programmschwerpunkten Musik, unterhaltende Information aus Österreich und der Welt sowie zielgruppenrelevantem Content und diversen Serviceangeboten	KA	Internet-TV, https://www.digitalfernsehen.de/ratgeber/digital-tv/kronehit-tv-592505/
390980	vol.at TV	30	2	Schwarzach	20	0	deutsch	2019-07-01	4	9999-01-01	9	Vorarlberg Online (www.vol.at) ist ein regionales Onlineportal mit Schwerpunkt News, Services und Unterhaltung für Vorarlberg und ein Teil der Austria.com-Gruppe.	KA	Programmfenster von Ländle TV, terrestrisch digital, auch Internet: https://www.vol.at/specials/tv (https://www.derstandard.at/story/2000105686773/russmedia-oeffnet-tv-fenster-im-laendle)
670640	Obersteirische Zeitung – OVZ Obersteirische Volkszeitung	12	99	Leoben	17	1	deutsch	1998-04-09	1	2008-12-20	9	KA	KA	KA
300790	oe24.tv	30	2	Wien	20	0	deutsch	2016-09-26	9	9999-01-01	9	oe24 ist unabhängig, kritisch, modern und ausschließlich ihren Lesern verpflichtet. In ihrer grundlegenden Richtung bekennt sich oe24 zur demokratischen Republik Österreich und ihren Prinzipien, zu den Menschenrechten und zu einer an Gerechtigkeit und Nachhaltigkeit orientierten Gesellschaft. Daher tritt oe24 insbesondere dafür ein, die parlamentarische Demokratie und den Rechtsstaat zu bewahren und zu fördern sowie die wirtschaftliche Wettbewerbsfähigkeit, beruhend auf den Grundsätzen der sozialen Marktwirtschaft, und die Eigenständigkeit Österreichs zu stärken. oe24 ist für Toleranz gegenüber allen ethnischen und religiösen Gruppen, lehnt politischen Extremismus und Totalitarismus ab. Die Redaktion ist dem Ehrenkodex der österreichischen Presse verpflichtet. Sie bemüht sich in allen Bereichen um Fairness und Objektivität.	KA	KA
300820	Sky	30	2	Wien	20	0	deutsch	2009-07-04	7	9999-01-01	9	Die Website informiert über Aktivitäten und Angebote der Sky Österreich Fernsehen GmbH, insbesondere aus den Bereichen Film, Serien und Sport.	KA	KA
300821	Sky Sport Austria	30	2	Wien	20	0	deutsch	2009-07-04	7	9999-01-01	9	Sky ist einer der führenden Entertainment-Anbieter in Österreich, Deutschland und der Schweiz. Das Programmangebot besteht aus bestem Live-Sport, exklusiven Serien, neuesten Filmen, vielfältigen Kinderprogrammen, spannenden Dokumentationen und unterhaltsamen Shows – viele davon Sky Original Productions. Neben dem frei empfangbaren Sender Sky Sport News HD können Zuschauer in Österreich das Programm zuhause und unterwegs über Sky Q und jetzt auch via Sky X sehen. Sky Österreich mit Hauptsitz in Wien ist Teil der Comcast Group und gehört zu Europas führendem Unterhaltungskonzern Sky Limited.	KA	Satellit, auch Internet: www.youtube.com/user/skysportaustria u.a.
300822	Premiere Austria	30	2	Wien	20	0	deutsch	2002-10-26	9	2009-07-03	9	KA	KA	Pay-TV
300970	Kurier TV	30	2	Wien	20	0	deutsch	2023-02-01	1	9999-01-01	9	KURIER.at versteht sich als Internet Portal für alle Österreicher und Internet-Nutzer des gesamten deutschsprachigen Raumes. KURIER.at ist ein von Parteien und Interessensgruppen unabhängiger Beitrag zur demokratischen Meinungsbildung im Sinne einer umfassenden Informationsfreiheit auf der Basis der parlamentarischen Demokratie, des Rechtsstaates, einer jeden Extremismus ausschließenden freien Gesellschaftsordnung sowie der Sozialen Marktwirtschaft. KURIER.at bündelt mediengerecht das Beste aus allen Informations- und Unterhaltungsbereichen.	KA	KA
301743	SW1 - Stadtfernsehen Schwechat	30	2	St. Pölten	14	1	deutsch	2000-01-01	4	9999-01-01	9	SW1 TV produziert ein lokales Schwechater Stadtfernsehen mit Beiträgen aus den Bereichen Gesellschaft, Politik, Kultur und Sport im Rahmen einer halbstündigen Wochenausgabe mit täglicher 24-stündiger Wiederholung.	KA	https://extradienst.at/eine-regionale-erfolgsstory/ + weiterer Sender: SW1 Bezirks TV Bruck an der Leitha?
301744	WT1	30	2	Wels	15	1	deutsch	1996-05-01	1	9999-01-01	9	KA	KA	der erste regionale TV-Sender Österreichs / Partnersender von LT1
301746	WKK Lokal TV	30	2	Judenburg	17	1	deutsch	1995-01-01	4	2010-01-01	7	KA	KA	KA
301747	Tirol TV [2]	30	2	Innsbruck	18	1	deutsch	2014-01-02	1	9999-01-01	9	Tirol TV ist ein unabhängiges Tiroler Medium. Es ist unabhängig von politischen Parteien, Institutionen und Interessensgruppen. Tirol TV berichtet und kommentiert gründlich und umfassend mit Schwerpunkt Tirol über Politik, Wirtschaft, Kultur, Gesellschaft und Sport und betrachtet sich als Instrument der demokratischen Meinungsbildung im Sinne der umfassenden Informationsfreiheit. Tirol TV tritt ein für: die Wahrung und Förderung der parlamentarischen Demokratie, der Menschenrechte und des Rechtsstaates, sowie für den föderalistischen Aufbau der Republik Österreich und deren konstruktiven Beitrag zum europäischen Einigungsprozess, die Vertiefung der Toleranz gegenüber allen ethnischen und religiösen Gemeinschaften, eine freie Gesellschaftsordnung, die jeden Extremismus ausschließt, Meinungsfreiheit und Meinungsvielfalt. https://www.tiroltoday.at/impressum/	KA	Im April 2023 übernahm die Moser Holding AG die Tirol Tv GmbH.
302743	RT24 - Regionale Television	30	2	St. Pölten	14	1	deutsch	2010-01-01	4	9999-01-01	9	KA	KA	 https://extradienst.at/eine-regionale-erfolgsstory/, https://www.n1tv.at/
302744	TV3	30	2	Linz	15	1	deutsch	1997-01-01	4	2000-12-31	7	KA	KA	KA
302747	Munde TV - [Telfs]	30	2	Innsbruck	18	1	deutsch	2019-01-01	4	9999-01-01	9	Tirol TV ist ein unabhängiges Tiroler Medium. Es ist unabhängig von politischen Parteien, Institutionen und Interessensgruppen. Tirol TV berichtet und kommentiert gründlich und umfassend mit Schwerpunkt Tirol über Politik, Wirtschaft, Kultur, Gesellschaft und Sport und betrachtet sich als Instrument der demokratischen Meinungsbildung im Sinne der umfassenden Informationsfreiheit. Tirol TV tritt ein für: die Wahrung und Förderung der parlamentarischen Demokratie, der Menschenrechte und des Rechtsstaates, sowie für den föderalistischen Aufbau der Republik Österreich und deren konstruktiven Beitrag zum europäischen Einigungsprozess, die Vertiefung der Toleranz gegenüber allen ethnischen und religiösen Gemeinschaften, eine freie Gesellschaftsordnung, die jeden Extremismus ausschließt, Meinungsfreiheit und Meinungsvielfalt. (https://www.mundetv.at/impressum/)	KA	Im April 2023 übernahm die Moser Holding AG die Tirol Tv GmbH.
303743	NÖN N1	30	2	St. Pölten	14	1	deutsch	2022-11-01	1	9999-01-01	9	N1 TV produziert ein regionales niederösterreichisches Fernsehprogramm aus den Bereichen Gesellschaft, Politik, Kultur und Sport im Rahmen einer mindestens einstündigen Wochenausgabe mit täglicher 24-stündiger Wiederholung.	KA	https://extradienst.at/eine-regionale-erfolgsstory/
320010	B1 Burgenland TV	30	2	Pottendorf	12	1	deutsch	2013-01-01	1	2022-11-01	7	KA	KA	2013 erste Nennung im RTR-Kommunikationsbericht, im September 2021 von der RMG Regional-Media-Group (N1 TV) überrnommen. Vermutlich mit der Übernahme von N1 TV durch die NÖN im November 2022 eingestellt (https://extradienst.at/eine-regionale-erfolgsstory/).
350010	BTV	30	2	Linz	15	1	deutsch	1998-01-01	7	2018-11-04	9	KA	KA	https://www.nachrichten.at/oberoesterreich/salzkammergut/Neuer-Name-und-neues-Programm-Aus-BTV-wird-TV1,art71,3050417
350011	TV1 Oberösterreich - Oön TV	30	2	Vöcklabruck	15	1	deutsch	2018-11-05	7	9999-01-01	9	Nachrichten und Unterhaltung – direkt aus den Regionen und mit Aktuellem aus dem Newsroom der OÖNachrichten.	KA	https://www.leadersnet.at/news/33794,aus-btv-wird-tv1-oberoesterreich.html
350020	MF1 - Mühlviertel Fernsehen 1	30	2	Freistadt	15	1	deutsch	1998-01-01	4	2009-02-01	4	KA	KA	KA
350021	Mühlviertel.TV	30	2	Freistadt	15	1	deutsch	2009-02-01	1	9999-01-01	9	Der Sender „Mühlviertel.TV“ gehört zu keinem Medienkonzern, sondern ist ein eigenständig geführtes Unternehmen, das im Februar 2009 von MMag. Elisabeth Keplinger-Radler gegründet wurde und seither als Einzelunternehmen geführt wird. Hauptsitz der Firma ist in Freistadt, Industriestr. 6.	KA	KA
390982	Ländle TV - Das Lokalfernsehen	30	2	Schwarzach	20	0	deutsch	2007-01-01	7	9999-01-01	9	Nah am Geschehen, regional und politisch unabhängig.	KA	KA
400013	orf.at	40	1	Wien	20	0	mehrsprachig	1997-07-24	9	9999-01-01	9	Grundlegende Richtung des Onlineangebotes des ORF: Erfüllung des Auftrages gemäß § 3 Abs. 5 Z 2 iVm § 18 ORF-Gesetz.\nDas ORF.at-Netzwerk ist Österreichs meistgenutzte Nachrichten-Plattform. ORF.at bietet einen kompakten Nachrichtenüberblick in Form von Text-, Video- und Audio-Beiträgen. Die „blaue Seite“ informiert aktuell und unabhängig über die regionalen, nationalen und internationalen Ereignisse und Entwicklungen in allen gesellschaftlich relevanten Bereichen, bietet umfassende sendungsbegleitende Inhalte sowie Informationen zum ORF und seinen Programmen, und macht Livestreaming- und On-Demand-Angebote online verfügbar. Außerdem werden humanitäre Aktionen des ORF online unterstützt.	KA	KA
400030	profil.at	40	2	Wien	20	0	deutsch	1997-02-01	4	9999-01-01	9	PROFIL ist das unabhängige Nachrichtenmagazin Österreichs und der dazugehörende Webauftritt für Politik, Wirtschaft, Außenpolitik, Gesellschaft, Wissenschaft und Kultur.	KA	 Startdatum zwischen Februar und April 1997
400040	falter.at	40	2	Wien	20	0	deutsch	1995-01-01	4	9999-01-01	9	Gegen das Falsche in Politik und Kultur. Für mehr Lebenslust.	KA	KA
400110	vienna.at	40	2	Schwarzach	20	0	deutsch	1995-09-27	9	9999-01-01	9	Vienna.at (www.vienna.at) ist ein regionales Onlineportal mit Schwerpunkt News, Services und Unterhaltung für Wien und ein Teil der Austria.com-Gruppe.	KA	KA
400120	kosmo.at	40	2	Wien	20	0	deutsch	2009-01-01	4	9999-01-01	9	Der Unternehmensgegenstand umfasst die Veröffentlichung und Verbreitung von Nachrichten, Artikeln und multimedialen Inhalten in den Bereichen Politik, Sport, Lifestyle, Technik und Prominenz, sowie verwandte Informationsdienstleistungen. Grundlegende Richtung: Unabhängig	KA	KA
400160	finanzen.net [[Dach]]	40	2	Karlsruhe	20	0	deutsch	1999-01-01	4	9999-01-01	9	KA	KA	KA
400161	finanzen.net	40	2	Karlsruhe	20	0	deutsch	1999-01-01	4	9999-01-01	9	KA	KA	KA
400162	finanzen.at	40	2	Karlsruhe	20	0	deutsch	1999-01-01	4	9999-01-01	9	KA	KA	KA
400180	GMX [[Dach]]	40	2	Karlsruhe	20	0	deutsch	1997-01-01	4	9999-01-01	9	Wir erreichen mit unseren Inhalten unterschiedliche Menschen mit unterschiedlichsten Interessen. Es ist unser Ziel, unseren Nutzerinnen und Nutzern die Inhalte anzubieten, die für sie von Interesse sind. Deshalb finden Sie auf unseren Portalen nicht nur aktuelle Themen aus Politik, Sport und Zeitgeschehen, sondern auch Unterhaltungs- sowie Ratgeber- und Serviceinhalte.	KA	KA
609180	Presse, Die [WZ]	12	2	Wien	20	0	deutsch	1946-01-26	9	1996-10-19	9	KA	KA	KA
609791	Slovenski vestnik [WZ1]	12	2	Wien	11	0	slowenisch	1946-06-14	9	1947-02-14	9	KA	KA	KA
400181	gmx.at	40	2	Karlsruhe	20	0	deutsch	1997-01-01	4	9999-01-01	9	Wir erreichen mit unseren Inhalten unterschiedliche Menschen mit unterschiedlichsten Interessen. Es ist unser Ziel, unseren Nutzerinnen und Nutzern die Inhalte anzubieten, die für sie von Interesse sind. Deshalb finden Sie auf unseren Portalen nicht nur aktuelle Themen aus Politik, Sport und Zeitgeschehen, sondern auch Unterhaltungs- sowie Ratgeber- und Serviceinhalte.	KA	KA
400182	gmx.net 	40	2	Karlsruhe	20	0	deutsch	1997-01-01	4	9999-01-01	9	Wir erreichen mit unseren Inhalten unterschiedliche Menschen mit unterschiedlichsten Interessen. Es ist unser Ziel, unseren Nutzerinnen und Nutzern die Inhalte anzubieten, die für sie von Interesse sind. Deshalb finden Sie auf unseren Portalen nicht nur aktuelle Themen aus Politik, Sport und Zeitgeschehen, sondern auch Unterhaltungs- sowie Ratgeber- und Serviceinhalte.	KA	KA
400210	servustv.com	40	2	Wals-Siezenheim	20	0	deutsch	2022-01-01	9	9999-01-01	9	Unternehmensgegenstand: Telekommunikations- und Rundfunkunternehmung Grundlegende Programmausrichtung: Kultur, Kunst, Wirtschaft, Sport, Unterhaltung und Wissenschaft des Alpen-Donau-Adria Raumes	KA	KA
400250	puls4.com	40	2	Wien	20	0	deutsch	2008-01-28	9	9999-01-01	9	Erklärung über die grundlegende Richtung: PULS 4 ist ein unabhängiger privater österreichischer Fernsehsender.	KA	KA
400260	puls24.at	40	2	Wien	20	0	deutsch	2019-09-01	9	9999-01-01	9	Erklärung über die grundlegende Richtung: PULS 24 ist ein unabhängiger privater österreichischer Fernsehsender.	KA	KA
400270	prosieben.at	40	2	Unterföhring	20	0	deutsch	2000-09-01	4	9999-01-01	9	KA	KA	https://www.horizont.at/digital/news/mediagruppe-austria-steigt-in-online-vermarktung-ein-26914
400280	sat1.at	40	2	Unterföhring	20	0	deutsch	2000-07-01	7	9999-01-01	9	KA	KA	Startdatum von TV-Sender übernommen
400290	k.at	40	2	Wien	20	0	deutsch	2019-06-25	9	9999-01-01	9	Unser Angebot versteht sich als unabhängiges Internet Portal und basiert auf Artikel 10 EMRK. Die dort geschützte Meinungsfreiheit ist das subjektive Recht auf freie Rede, auf freie Meinungsäußerung und auf die öffentliche Verbreitung einer Meinung in Wort, Schrift und Bild sowie durch alle weiteren verfügbaren Übertragungsmittel.	KA	https://www.ots.at/presseaussendung/OTS_20190625_OTS0035/der-telekurier-praesentiert-kat-das-neue-portal-fuer-die-junge-zielgruppe
400350	rtl.de	40	2	Köln	20	0	deutsch	1997-04-01	1	9999-01-01	9	RTL ist Europas führende Unterhaltungsmarke und steht für Unterhaltung, unabhängigen Journalismus, Inspiration, Energie und Haltung. Mit unseren Fernsehsendern, Streamingdiensten, Radiostationen und Online-Plattformen in Deutschland, den Niederlanden, Frankreich, Ungarn und Luxemburg erreichen wir jeden Tag Millionen Menschen in ganz Europa. Die Marke RTL gehört der RTL Group.	KA	KA
400370	Mein Bezirk.at [[Dach]]	40	2	Wien	20	0	deutsch	2009-01-01	7	9999-01-01	9	Die Medien der RegionalMedien Austria handeln in den Bezirken, auf Landes- und auf Bundesebene völlig unabhängig von politischen Parteien, Institutionen und Interessengruppen. Die redaktionellen Mitarbeiterinnen und Mitarbeiter der RegionalMedien Austria treten für die Grundwerte der parlamentarischen Demokratie, für das Prinzip der Rechtsstaatlichkeit sowie für die Gleichberechtigung aller Staatsbürgerinnen und Staatsbürger ein. Jede Form von Extremismus und Totalitarismus wird strikt abgelehnt. Die redaktionellen Mitarbeiterinnen und Mitarbeiter der RegionalMedien Austria-Medien treten für die Stärkung der wirtschaftlichen Wettbewerbsfähigkeit Österreichs sowie seiner Regionen nach den Prinzipien der freien Marktwirtschaft ein. Die redaktionellen Mitarbeiterinnen und Mitarbeiter der RegionalMedien Austria in den Bezirken, auf Landes- und auf Bundesebene verpflichten sich in ihrer Arbeit zur Einhaltung des Ehrenkodex des Österreichischen Presserats. Die redaktionellen Mitarbeiterinnen und Mitarbeiter der RegionalMedien Austria-Medien wenden sich an alle Leserinnen und Leser, die hohe Ansprüche an eine gründliche und umfassende Berichterstattung auf lokaler, regionaler und nationaler Ebene stellen. Die Themenfelder der Berichterstattung umfassen unmittelbar das persönliche Umfeld und die persönlichen Interessen der Leserinnen und Leser sowie darüber hinaus Gesellschaft, Wirtschaft, Politik, Kultur, Sport und Freizeit. Die nationale Chefredaktion sowie die Chefredaktionen der RegionalMedien Austria-Medien sind für die Einhaltung der Blattlinie und ihre Implementierung verantwortlich.	KA	https://www.styria.com/de/brands/meinbezirk
400371	MeinBezirk.at/Wien	40	2	Wien	20	0	deutsch	2009-01-01	7	9999-01-01	9	Von allen politischen Parteien und Interessensvertretungen unabhängiges Regionalmedium mit Berichterstattung über das gesellschaftliche, politische, wirtschaftliche, sportliche und kulturelle Leben mit regionalem Fokus.	KA	https://www.styria.com/de/brands/meinbezirk
400372	MeinBezirk.at/Burgenland	40	2	Eisenstadt	20	0	deutsch	2009-01-01	7	9999-01-01	9	Von allen politischen Parteien und Interessensvertretungen unabhängiges Regionalmedium mit Berichterstattung über das gesellschaftliche, politische, wirtschaftliche, sportliche und kulturelle Leben mit regionalem Fokus.	KA	https://www.styria.com/de/brands/meinbezirk
400373	MeinBezirk.at/Niederösterreich	40	2	St. Pölten	20	0	deutsch	2007-03-31	1	9999-01-01	9	Von allen politischen Parteien und Interessensvertretungen unabhängiges Regionalmedium mit Berichterstattung über das gesellschaftliche, politische, wirtschaftliche, sportliche und kulturelle Leben mit regionalem Fokus.	KA	https://www.ots.at/presseaussendung/OTS_20070425_OTS0086/austriacomplus-vermarktet-regional-plattform-der-bezirksblaetter
400374	MeinBezirk.at/Oberösterreich	40	2	Innsbruck	20	0	deutsch	2009-01-01	7	9999-01-01	9	Von allen politischen Parteien und Interessensvertretungen unabhängiges Regionalmedium mit Berichterstattung über das gesellschaftliche, politische, wirtschaftliche, sportliche und kulturelle Leben mit regionalem Fokus.	KA	https://www.styria.com/de/brands/meinbezirk
400375	MeinBezirk.at/Steiermark	40	2	Graz	20	0	deutsch	2009-01-01	7	9999-01-01	9	Von allen politischen Parteien und Interessensvertretungen unabhängiges Regionalmedium mit Berichterstattung über das gesellschaftliche, politische, wirtschaftliche, sportliche und kulturelle Leben mit regionalem Fokus.	KA	https://www.styria.com/de/brands/meinbezirk
400376	MeinBezirk.at/Kärnten	40	2	Klagenfurt	20	0	deutsch	2009-01-01	7	9999-01-01	9	Von allen politischen Parteien und Interessensvertretungen unabhängiges Regionalmedium mit Berichterstattung über das gesellschaftliche, politische, wirtschaftliche, sportliche und kulturelle Leben mit regionalem Fokus.	KA	https://www.styria.com/de/brands/meinbezirk
400377	MeinBezirk.at/Salzburg	40	2	Salzburg	20	0	deutsch	2009-01-01	7	9999-01-01	9	Von allen politischen Parteien und Interessensvertretungen unabhängiges Regionalmedium mit Berichterstattung über das gesellschaftliche, politische, wirtschaftliche, sportliche und kulturelle Leben mit regionalem Fokus.	KA	https://www.styria.com/de/brands/meinbezirk
609792	Slovenski vestnik [WZ2]	12	5	Klagenfurt	13	0	slowenisch	1947-07-04	9	1948-02-20	9	KA	KA	KA
609793	Slovenski vestnik [WZ3]	12	5	Wien	13	0	slowenisch	1949-07-29	9	1949-08-24	9	KA	KA	KA
400378	MeinBezirk.at/Tirol	40	2	Innsbruck	20	0	deutsch	2009-01-01	7	9999-01-01	9	Von allen politischen Parteien und Interessensvertretungen unabhängiges Regionalmedium mit Berichterstattung über das gesellschaftliche, politische, wirtschaftliche, sportliche und kulturelle Leben mit regionalem Fokus.	KA	https://www.styria.com/de/brands/meinbezirk
400379	MeinBezirk.at/Vorarlberg	40	2	Feldkirch	20	0	deutsch	2009-01-01	7	9999-01-01	9	MeinBezirk.at ist ein unabhängiges Online-Medium für die Bundesländer Tirol (www.meinbezirk.at/tirol), Salzburg (www.meinbezirk.at/salzburg), Oberösterreich (www.meinbezirk.at/oberoesterreich), Niederösterreich (www.meinbezirk.at/niederoesterreich), Wien (www.meinbezirk.at/wien), dem Burgenland (www.meinbezirk.at/burgenland), der Steiermark (www.meinbezirk.at/steiermark), Vorarlberg (www.meinbezirk.at/vorarlberg) sowie Kärnten (www.meinbezirk.at/kaernten) im Interesse des Lesers bzw. Nutzers. Es werden branchenübergreifend Beiträge / Inhalte unabhängig von politischen Parteien, Institutionen sowie Interessengruppen mit regionalem Bezug angeboten. Die Redaktion verfolgt ausschließlich den Zweck der Bereitstellung und Pflege der angebotenen Dienste sowie der Aufbereitung der von Lesern bzw. Nutzern, Unternehmen, Vereinen, Gemeinden, Schulen etc. selbst gemeldeten Inhalten. Weiters wird Nutzern des Dienstes die Möglichkeit geboten und Speicherplatz zur Verfügung gestellt, als Regionauten selbst eigene Inhalte zu veröffentlichen.	KA	https://www.styria.com/de/brands/meinbezirk
400380	bvz.at	40	2	Eisenstadt	20	1	deutsch	2003-08-01	9	9999-01-01	9	Die Burgenländische Volkszeitung ist eine parteipolitisch unabhängige Wochenzeitung, die sich dem christlichen Weltbild verpflichtet sieht. Aufgabe der BVZ ist es, zur Information und Bildung der Bevölkerung beizutragen sowie einen Beitrag zur Förderung des Gemeinwohls zu leisten. Die BVZ nimmt eine positive Haltung zur Europäischen Union, zum demokratischen Staatswesen der Republik Österreich und zum Bundesland Burgenland ein. Sie bekennen sich zur Freiheit und zur Würde des Menschen. Dessen Intimsphäre ist zu respektieren, seine persönliche Meinung zu achten.	KA	KA
400420	sixx.at	40	2	Unterföhring	20	0	deutsch	2012-07-03	7	9999-01-01	9	KA	KA	Startdatum von TV-Sender übernommen
400490	exxpress.at	40	2	Wien	20	0	deutsch	2021-03-01	1	9999-01-01	9	eXXpress ist ein bürgerlich-liberales Digitalmedium für Politik und Wirtschaft, dessen objektive, wahrheitsgetreue und kritische Berichterstattung der Information der Öffentlichkeit dienen soll. eXXpress ist von politischen Parteien und Interessenvertretungen unabhängig. eXXpress tritt für eine der Würde des Menschen angemessene und seine freie Entfaltung auf allen Gebieten fördernde Gesellschaftsordnung ein, ebenso für eine Stärkung der persönlichen Freiheitsrechte, der Meinungsfreiheit sowie für eine Förderung von Toleranz im Sinne des Humanismus und der Aufklärung. eXXpress bekennt sich hierbei zur Demokratie, zur Rechtsstaatlichkeit auf allen Ebenen, zur sozialen Gerechtigkeit, zur Eigenverantwortlichkeit des Menschen und zur Stärkung des Individuums an sich, zum Erhalt des privaten Eigentums, zu den Grundsätzen der sozialen Marktwirtschaft, zum freien Unternehmertum und zum Leistungswettbewerb.	KA	KA
400510	salzburg24.at	40	2	Salzburg	20	1	deutsch	2007-11-23	7	9999-01-01	9	SALZBURG24 ist ein von politischen Parteien, Institutionen und Interessensgruppen unabhängiges Online-Nachrichtenportal und sieht sich verpflichtet, alle Leserinnen und Leser objektiv und so vollständig wie möglich über alle Ereignisse von allgemeinem Interesse zu informieren. Die Freiheit der Journalisten, nach bestem Wissen und Gewissen arbeiten zu können, ist garantiert. SALZBURG24 ist gegen jede totalitäre Herrschaftsform, respektiert die von der UNO deklarierten Menschenrechte und bekennt sich zu einem neutralen demokratischen Österreich, zur Rechtstaatlichkeit und zum System der sozialen Marktwirtschaft. SALZBURG24 erkennt den Ehrenkodex für die österreichische Presse an.	KA	https://www.salzburg24.at/themen/15-jahre-salzburg24/15-jahre-salzburg24-einblick-statt-rueckblick-130138303
400540	news.at	40	2	Wien	20	0	deutsch	1995-01-01	4	9999-01-01	9	Unabhängige Berichterstattung vor allem über Politik, Wirtschaft, Kultur, Lifestyle, Sport, Leute, Internet, Telekommunikation und Multimedia, Plattform für interaktive Services.	KA	KA
400550	trend.at	40	2	Wien	20	0	deutsch	1998-01-01	4	9999-01-01	9	Unabhängige Berichterstattung vor allem über Wirtschaft, Politik, Kultur, Lifestyle, Sport, Leute, Internet, Telekommunikation und Multimedia, Plattform für interaktive Services.	KA	KA
400580	tips.at	40	2	Linz	20	1	deutsch	2007-01-01	7	9999-01-01	9	Parteiunabhängige Regional- und Lokalinformation	KA	https://www.tips.at/nachrichten/linz/wirtschaft-politik/582654-tips-bleibt-mit-total-regional-die-ueberlegene-nummer-1-in-oberoesterreich
400640	laola1.at	40	2	Wien	20	0	deutsch	2011-01-01	4	9999-01-01	9	LAOLA1.at ist Österreichs größtes Sportportal und ein Unternehmen der Sportradar Media Services GmbH.	KA	KA
400780	kronehit.at	40	2	Wien	20	0	deutsch	2001-06-28	9	9999-01-01	9	Unterhaltungssender (und dessen Webauftritt) für erwachsene ÖstereicherInnen mit den Programmschwerpunkten Musik, unterhaltende Information aus Österreich und der Welt sowie zielgruppenrelevantem Content und diversen Serviceangeboten	KA	KA
400820	skysportaustria.at	40	2	Wien	20	0	deutsch	2013-01-01	9	9999-01-01	9	Die Website informiert über Aktivitäten und Angebote der Sky Österreich Fernsehen GmbH, insbesondere aus den Bereichen Film, Serien und Sport.	KA	KA
400970	noen.at	40	2	St. Pölten	20	1	deutsch	1998-01-01	4	9999-01-01	9	Die Niederösterreichischen Nachrichten sind eine parteipolitisch unabhängige Wochenzeitung, die sich dem christlichen Weltbild verpflichtet sieht. Aufgabe der NÖN ist es, zur Information und Bildung der Bevölkerung beizutragen sowie einen Beitrag zur Förderung des Gemeinwohls zu leisten. Die Niederösterreichischen Nachrichten nehmen eine positive Haltung zur Europäischen Union, zum demokratischen Staatswesen der Republik Österreich und zum Bundesland Niederösterreich ein. Sie bekennen sich zur Freiheit und zur Würde des Menschen. Dessen Intimsphäre ist zu respektieren, seine persönliche Meinung zu achten.	KA	KA
403680	heute.at	40	2	Wien	20	0	deutsch	2016-01-01	4	9999-01-01	9	Heute ist unabhängig von allen politischen Parteien, Institutionen und Interessensgruppen und steht daher für eine offene, unabhängige und ausgewogene Berichterstattung über alle Ereignisse von öffentlichem Interesse aus Politik, Wirtschaft, Kultur, Sport usw.	KA	KA
404830	krone.at	40	2	Wien	20	0	deutsch	1998-01-01	4	9999-01-01	9	krone.at versteht sich als das Internet-Portal für alle Österreicher und Internet-Nutzer des gesamten deutschsprachigen Raumes. krone.at ist unabhängig. krone.at bündelt mediengerecht das Beste aus allen Informations- und Unterhaltungsbereichen.	KA	KA
450551	oon.at	40	2	Linz	20	1	deutsch	1995-11-09	9	2000-03-01	1	„Die Oberösterreichischen Nachrichten sind eine überparteiliche und unabhängige Tageszeitung. Sie bekennen sich zur pluralistischen Gesellschaftsordnung der parlamentarischen Demokratie, zu den Prinzipien der sozialen Marktwirtschaft sowie zur Integration Europas und fühlen sich den Menschenrechten verpflichtet.“	KA	KA
404850	kurier.at	40	2	Wien	20	0	deutsch	1996-01-01	4	9999-01-01	9	KURIER.at versteht sich als Internet Portal für alle Österreicher und Internet-Nutzer des gesamten deutschsprachigen Raumes. KURIER.at ist ein von Parteien und Interessensgruppen unabhängiger Beitrag zur demokratischen Meinungsbildung im Sinne einer umfassenden Informationsfreiheit auf der Basis der parlamentarischen Demokratie, des Rechtsstaates, einer jeden Extremismus ausschließenden freien Gesellschaftsordnung sowie der Sozialen Marktwirtschaft. KURIER.at bündelt mediengerecht das Beste aus allen Informations- und Unterhaltungsbereichen.	KA	KA
408240	oe24.at	40	2	Wien	20	0	deutsch	2006-09-18	9	9999-01-01	9	oe24 ist unabhängig, kritisch, modern und ausschließlich ihren Lesern verpflichtet. In ihrer grundlegenden Richtung bekennt sich oe24 zur demokratischen Republik Österreich und ihren Prinzipien, zu den Menschenrechten und zu einer an Gerechtigkeit und Nachhaltigkeit orientierten Gesellschaft. Daher tritt oe24 insbesondere dafür ein, die parlamentarische Demokratie und den Rechtsstaat zu bewahren und zu fördern sowie die wirtschaftliche Wettbewerbsfähigkeit, beruhend auf den Grundsätzen der sozialen Marktwirtschaft, und die Eigenständigkeit Österreichs zu stärken. oe24 ist für Toleranz gegenüber allen ethnischen und religiösen Gruppen, lehnt politischen Extremismus und Totalitarismus ab. Die Redaktion ist dem Ehrenkodex der österreichischen Presse verpflichtet. Sie bemüht sich in allen Bereichen um Fairness und Objektivität.	KA	KA
409180	diepresse.com	40	2	Wien	20	0	deutsch	1996-09-21	9	9999-01-01	9	„Die Presse“ vertritt in Unabhängigkeit von den politischen Parteien bürgerlich-liberale Auffassungen auf einem gehobenen Niveau. Sie tritt für die parlamentarische Demokratie auf der Grundlage des Mehrparteiensystems und für ihre Rechtsstaatlichkeit ein. „Die Presse“ bekennt sich zu den Grundsätzen der sozialen Gerechtigkeit bei Aufrechterhaltung der Eigenverantwortlichkeit des Menschen, zur Wahrung des privaten Eigentums unter Beobachtung seiner Verpflichtungen gegenüber der Gesellschaft, zu den Grundsätzen der sozialen Marktwirtschaft, zur freien unternehmerischen Initiative und zum Leistungswettbewerb. Sie verteidigt die Grundfreiheiten und Menschenrechte und bekämpft alle Bestrebungen, die geeignet sind, diese Freiheiten und Rechte oder die demokratische rechtsstaatliche Gesellschaftsordnung zu gefährden. „Die Presse“ betrachtet es als journalistische Standespflicht, ihre Leserinnen und Leser objektiv und so vollständig wie nur möglich über alle Ereignisse von allgemeinem Interesse zu informieren. Stellung zu nehmen und Kritik zu üben wird von der „Presse“ als ihre Aufgabe und ihr unveräußerliches Recht angesehen.	KA	KA
409850	derstandard.at [[Dach]]	40	2	Wien	20	0	deutsch	1995-01-21	9	9999-01-01	9	DER STANDARD ist ein liberales Medium. Es ist unabhängig von politischen Parteien, Institutionen und Interessengruppen und wendet sich an alle Lesende, die hohe Ansprüche an eine gründliche und umfassende Berichterstattung sowie an eine fundierte, sachgerechte Kommentierung auf den Gebieten von Wirtschaft, Politik, Kultur und Gesellschaft stellen.DER STANDARD lebt die Blattphilosophie in einer ebenso klaren wie anspruchsvollen Weise. Er trennt zwischen Bericht und Kommentar, gewichtet die Ereignisse und lässt seinen Leser:innen den nötigen Spielraum für die eigene Meinung. So fördert er, was zugleich sein Ziel ist: eine mündige Leserschaft.	KA	KA
409851	derstandard.at	40	2	Wien	20	0	deutsch	1995-01-21	9	9999-01-01	9	DER STANDARD ist ein liberales Medium. Es ist unabhängig von politischen Parteien, Institutionen und Interessengruppen und wendet sich an alle Lesende, die hohe Ansprüche an eine gründliche und umfassende Berichterstattung sowie an eine fundierte, sachgerechte Kommentierung auf den Gebieten von Wirtschaft, Politik, Kultur und Gesellschaft stellen.DER STANDARD lebt die Blattphilosophie in einer ebenso klaren wie anspruchsvollen Weise. Er trennt zwischen Bericht und Kommentar, gewichtet die Ereignisse und lässt seinen Leser:innen den nötigen Spielraum für die eigene Meinung. So fördert er, was zugleich sein Ziel ist: eine mündige Leserschaft.	KA	KA
660661	Salzburger Volkszeitung UND Salzburger Volksbote [WZ]	12	4	Salzburg	16	0	deutsch	1968-04-05	9	1971-10-29	9	KA	KA	Der Salzburger Volksbote war die Wochenzeitung des ÖVP-Bauernbundes
666010	Salzburger Wacht	12	4	Salzburg	16	0	deutsch	1900-01-26	9	1906-12-28	9	KA	KA	Gegründet 14.04.1899 als 3 mal monatlich erscheinende Zeitung
670151	Kleine Zeitung [WZ]	12	2	Graz	17	0	deutsch	1948-05-02	9	1948-09-26	9	KA	KA	KA
409852	diestandard.at	40	2	Wien	20	0	deutsch	2000-01-01	4	9999-01-01	9	DER STANDARD ist ein liberales Medium. Es ist unabhängig von politischen Parteien, Institutionen und Interessengruppen und wendet sich an alle Lesende, die hohe Ansprüche an eine gründliche und umfassende Berichterstattung sowie an eine fundierte, sachgerechte Kommentierung auf den Gebieten von Wirtschaft, Politik, Kultur und Gesellschaft stellen.DER STANDARD lebt die Blattphilosophie in einer ebenso klaren wie anspruchsvollen Weise. Er trennt zwischen Bericht und Kommentar, gewichtet die Ereignisse und lässt seinen Leser:innen den nötigen Spielraum für die eigene Meinung. So fördert er, was zugleich sein Ziel ist: eine mündige Leserschaft.	KA	KA
409853	dastandard.at	40	2	Wien	20	0	deutsch	2010-01-01	4	9999-01-01	9	DER STANDARD ist ein liberales Medium. Es ist unabhängig von politischen Parteien, Institutionen und Interessengruppen und wendet sich an alle Lesende, die hohe Ansprüche an eine gründliche und umfassende Berichterstattung sowie an eine fundierte, sachgerechte Kommentierung auf den Gebieten von Wirtschaft, Politik, Kultur und Gesellschaft stellen.DER STANDARD lebt die Blattphilosophie in einer ebenso klaren wie anspruchsvollen Weise. Er trennt zwischen Bericht und Kommentar, gewichtet die Ereignisse und lässt seinen Leser:innen den nötigen Spielraum für die eigene Meinung. So fördert er, was zugleich sein Ziel ist: eine mündige Leserschaft.	KA	KA
409854	derstandard.de	40	2	Wien	20	0	deutsch	2017-07-24	9	9999-01-01	9	DER STANDARD ist ein liberales Medium. Es ist unabhängig von politischen Parteien, Institutionen und Interessengruppen und wendet sich an alle Lesende, die hohe Ansprüche an eine gründliche und umfassende Berichterstattung sowie an eine fundierte, sachgerechte Kommentierung auf den Gebieten von Wirtschaft, Politik, Kultur und Gesellschaft stellen.DER STANDARD lebt die Blattphilosophie in einer ebenso klaren wie anspruchsvollen Weise. Er trennt zwischen Bericht und Kommentar, gewichtet die Ereignisse und lässt seinen Leser:innen den nötigen Spielraum für die eigene Meinung. So fördert er, was zugleich sein Ziel ist: eine mündige Leserschaft.	KA	https://www.derstandard.at/story/2000061693674/der-standard-startet-mit-derstandardde-ein-portal-fuer-den-deutschen
414502	wienerzeitung.at	40	2	Wien	20	0	deutsch	1995-01-01	4	9999-01-01	9	Die WZ (Wiener Zeitung) ist ein öffentlich-rechtliches Medium auf Basis des WZEVI-Gesetzes und der dort verankerten Aufgaben, unabhängig und frei von äußeren Einflüssen. Als Kompassmedium fördert sie eine informierte Gesellschaft, in der alle Menschen ihr politisches Potenzial erkennen und das demokratische Zusammenleben bewusst mitgestalten. Die WZ inspiriert Österreichs Bürger:innen mit lösungsorientiertem Journalismus, um deren Verständnis für politische, wirtschaftliche, wissenschaftliche und kulturelle Sachverhalte zu stärken und Orientierung bei Entscheidungen zu geben. Die WZ bekennt sich zu den Grundsätzen der Österreichischen Bundesverfassung und zur Europäischen Integration. Sie verpflichtet sich der Europäischen Menschenrechtskonvention und dem Ehrenkodex des Österreichischen Presserats.	KA	KA
609001	Ostdeutsche Rundschau [WZ1]	12	4	Wien	11	0	deutsch	1890-04-06	9	1893-09-24	9	KA	KA	KA
609002	Ostdeutsche Rundschau [WZ2]	12	4	Wien	11	0	deutsch	1919-08-08	9	1920-06-25	9	KA	KA	KA
450552	nachrichten.at	40	2	Linz	20	1	deutsch	2000-03-01	1	9999-01-01	9	„Die Oberösterreichischen Nachrichten sind eine überparteiliche und unabhängige Tageszeitung. Sie bekennen sich zur pluralistischen Gesellschaftsordnung der parlamentarischen Demokratie, zu den Prinzipien der sozialen Marktwirtschaft sowie zur Integration Europas und fühlen sich den Menschenrechten verpflichtet.“	KA	KA
460621	salzburg.com	40	2	Salzburg	20	1	deutsch	1997-03-05	9	2017-10-01	1	Die Salzburger Nachrichten sind eine parteipolitisch unabhängige Tageszeitung, dem christlichen Weltbild verpflichtet, und treten unabdingbar für die Freiheit des einzelnen Menschen ein. Die Salzburger Nachrichten sind gegen jede totalitäre Herrschaftsform, respektieren die von der UNO deklarierten Menschenrechte und bekennen sich zu einem neutralen demokratischen Österreich, zur Rechtstaatlichkeit und zum System der sozialen Marktwirtschaft. Die Salzburger Nachrichten sehen in der Erfüllung ihrer Aufgabe, der Information und der Kontrolle, einen wesentlichen Beitrag zur demokratischen Gesellschaft. Die Freiheit der Journalisten, nach bestem Wissen und Gewissen arbeiten zu können, ist durch den Herausgeber garantiert.	KA	KA
460622	sn.at	40	2	Salzburg	20	1	deutsch	2017-11-01	1	9999-01-01	9	Die Salzburger Nachrichten sind eine parteipolitisch unabhängige Tageszeitung, dem christlichen Weltbild verpflichtet, und treten unabdingbar für die Freiheit des einzelnen Menschen ein. Die Salzburger Nachrichten sind gegen jede totalitäre Herrschaftsform, respektieren die von der UNO deklarierten Menschenrechte und bekennen sich zu einem neutralen demokratischen Österreich, zur Rechtstaatlichkeit und zum System der sozialen Marktwirtschaft. Die Salzburger Nachrichten sehen in der Erfüllung ihrer Aufgabe, der Information und der Kontrolle, einen wesentlichen Beitrag zur demokratischen Gesellschaft. Die Freiheit der Journalisten, nach bestem Wissen und Gewissen arbeiten zu können, ist durch den Herausgeber garantiert.	KA	KA
470150	kleinezeitung.at	40	2	Graz	20	1	deutsch	1995-11-28	9	9999-01-01	9	Die Kleine Zeitung, sowie die Kleine Zeitung Digital sind eine von allen politischen Parteien und Interessenvertretungen unabhängige Tageszeitung bzw. Plattform für digitale Medien. Sie steht auf dem Boden christlicher Weltanschauung, tritt für eine plurale, demokratische Gesellschaftsordnung, die Eigenständigkeit der Bundesländer und die völkerrechtliche Unabhängigkeit der Republik Österreich ein und begrüßt den europäischen Einigungsprozess. Die Kleine Zeitung orientiert sich in ihrer publizistischen Arbeit am Ehrenkodex der österreichischen Presse.	KA	KA
670300	Mürztaler Volksstimme [WZ]	12	4	Bruck an der Mur	17	1	deutsch	1945-07-28	9	1945-09-30	1	KA	KA	Dreiparteienblatt
670331	Mürztaler, Der [WZ]	12	99	Leoben17	17	1	deutsch	1934-01-07	9	1934-09-30	1	KA	KA	KA
670500	Neue Zeit	12	4	Graz	17	0	deutsch	1945-10-27	9	1945-12-23	9	KA	KA	KA
670560	Obersteirer Volksstimme [WZ]	12	2	Bruck an der Mur	17	1	deutsch	1951-07-01	1	1953-12-25	9	KA	KA	KA
670623	Obersteirische Volkszeitung [WZ]	12	99	Leoben	17	1	deutsch	1969-04-05	9	1980-12-20	9	KA	KA	KA
670631	Leobener Sonntagspost	12	99	Leoben	17	1	deutsch	1929-09-08	9	1932-11-27	9	KA	KA	KA
670632	Obersteirische Volkspresse [WZ]	12	99	Leoben	17	1	deutsch	1932-12-04	9	1934-09-30	1	KA	KA	KA
480871	tirol.com	40	2	Innsbruck	20	1	deutsch	1996-01-01	4	2008-12-31	1	Die Tiroler Tageszeitung berichtet als Landeszeitung objektiv und in völliger Unabhängigkeit von politischen und wirtschaftlichen Interessensgruppen. Sie setzt sich ein für die Interessen Tirols, berücksichtigt die Besonderheiten des ökologischen sensiblen Alpenraums, achtet in zeitgemäßer Art die Traditionen des Landes und betont die geistige Einheit Gesamttirols. Die Tiroler Tageszeitung tritt ein für die Freiheit, Würde und Eigenverantwortung des Einzelnen (Personalität), für die Selbstverantwortung kleiner Gemeinschaften (Subsidiarität) und für die Mitverantwortung des Einzelnen in der Gemeinschaft (Solidarität). Die Tiroler Tageszeitung bekennt sich zu den Menschenrechten, zur Parlamentarischen Demokratie, zur freien, sozialen Marktwirtschaft und zur Republik Österreich mit ihrem föderalistischen Aufbau. Die Tiroler Tageszeitung steht für die Meinungsfreiheit und Meinungsvielfalt. Sie lehnt politische Aktivitäten ab, die geeignet sind, die freie, pluralistische Gesellschaftsordnung zu gefährden. Die Tiroler Tageszeitung orientiert sich in ihrer publizistischen Arbeit am Ehrenkodex der österreichischen Presse.	KA	KA
480872	tt.com	40	2	Innsbruck	20	1	deutsch	2008-01-01	4	9999-01-01	9	Die Tiroler Tageszeitung berichtet als Landeszeitung objektiv und in völliger Unabhängigkeit von politischen und wirtschaftlichen Interessensgruppen. Sie setzt sich ein für die Interessen Tirols, berücksichtigt die Besonderheiten des ökologischen sensiblen Alpenraums, achtet in zeitgemäßer Art die Traditionen des Landes und betont die geistige Einheit Gesamttirols. Die Tiroler Tageszeitung tritt ein für die Freiheit, Würde und Eigenverantwortung des Einzelnen (Personalität), für die Selbstverantwortung kleiner Gemeinschaften (Subsidiarität) und für die Mitverantwortung des Einzelnen in der Gemeinschaft (Solidarität). Die Tiroler Tageszeitung bekennt sich zu den Menschenrechten, zur Parlamentarischen Demokratie, zur freien, sozialen Marktwirtschaft und zur Republik Österreich mit ihrem föderalistischen Aufbau. Die Tiroler Tageszeitung steht für die Meinungsfreiheit und Meinungsvielfalt. Sie lehnt politische Aktivitäten ab, die geeignet sind, die freie, pluralistische Gesellschaftsordnung zu gefährden. Die Tiroler Tageszeitung orientiert sich in ihrer publizistischen Arbeit am Ehrenkodex der österreichischen Presse.	KA	KA
490470	neue.at	40	2	Schwarzach	20	0	deutsch	2020-05-31	7	9999-01-01	9	Die NEUE Vorarlberger Tageszeitung ist eine von allen politischen Parteien und Interessensvertretungen unabhängige Tageszeitung. Sie steht auf dem Boden christlicher Weltanschauung, tritt vorbehaltlos für eine plurale, demokratische Gesellschaftsordnung, die Eigenständigkeit der Bundesländer und die Unabhängigkeit der Republik ein.	KA	https://www.horizont.at/medien/news/vorarlberger-medienhaus-neue-vorarlberger-tageszeitung-ging-mit-newsportal-online-81307, https://www.russmedia.com/product/neue-vorarlberger-tageszeitung/ 
490980	vol.at	40	2	Schwarzach	20	1	deutsch	1995-08-09	9	9999-01-01	9	Vorarlberg Online (www.vol.at) ist ein regionales Onlineportal mit Schwerpunkt News, Services und Unterhaltung für Vorarlberg und ein Teil der Austria.com-Gruppe.	KA	KA
490990	vn.at	40	2	Schwarzach	20	1	deutsch	2019-01-01	4	9999-01-01	9	demokratisch, föderalistisch, unabhängig	KA	https://www.russmedia.com/product/vorarlberger-nachrichten/
601201	Arbeiter-Zeitung [WZ]	12	4	Wien	11	0	deutsch	1889-10-18	9	1893-10-27	9	KA	KA	KA
601380	Bécsi Magyar Híradó [WZ]	12	4	Wien	11	0	ungarisch	1957-08-01	1	1980-01-01	9	KA	KA	KA
604100	Kampfruf, Der [WZ]	12	4	Wien	11	0	deutsch	1930-09-16	9	1933-04-30	1	KA	KA	KA
604101	Braune Woche	12	4	Wien	21	0	deutsch	1933-04-01	1	1933-06-17	9	KA	KA	KA
605700	Morgenpost [WZ]	12	2	Wien	11	0	deutsch	1932-12-24	9	1938-03-10	9	KA	KA	KA
607210	Welt am Montag	12	7	Wien	11	0	deutsch	1946-02-18	9	1967-09-30	1	KA	KA	KA
608550	Österreichische Zeitung [WZ]	12	7	Wien	11	0	deutsch	1945-04-15	9	1945-04-30	1	KA	KA	Zeitung der russischen Besatzungsmacht
609794	Slovenski vestnik [WZ4]	12	5	Klagenfurt	11	0	slowenisch	1953-04-10	9	2003-03-27	9	KA	KA	KA
609795	Novice [WZ]	12	5	Klagenfurt	13	0	slovenisch	2003-04-11	9	9999-01-01	9	KA	KA	KA
611481	Salto [WZ]	12	4	Wien	11	0	deutsch	1991-05-03	9	1993-02-26	9	KA	KA	KA
611482	Volksstimme [WZ]	12	4	Wien	11	0	deutsch	1993-11-25	9	2003-10-16	9	KA	KA	01.06.2004-05.2009 als Monatsmagazin unter dem Titel Volksstimmen erschienen, ab 01.09.2009 wieder als Volksstimme
616111	Arbeit, Die [WZ1]	12	99	Wien	11	0	deutsch	1894-10-14	9	1896-12-27	9	KA	KA	KA
616112	Arbeit, Die [WZ2]	12	99	Wien	11	0	deutsch	1901-05-12	9	1922-12-30	9	KA	KA	KA
616120	Reichswehr , Die [WZ]	12	2	Wien	11	0	deutsch	1889-01-07	9	1889-03-31	1	KA	KA	KA
630951	Volkswille [WZ]	12	4	Klagenfurt	13	0	deutsch	1945-10-30	9	1945-12-29	9	KA	KA	KA
630961	Volkszeitung [WZ]	12	4	Klagenfurt	13	0	deutsch	1945-01-28	9	1945-12-30	9	KA	KA	Erste Nummer u.d.T. Kärntner Volkszeitung
650630	Salzkammergut Beobachter  [WZ]	12	4	Gmunden	15	1	deutsch	1938-03-12	9	1938-04-23	9	KA	KA	KA
650701	Salzkammergut-Zeitung [WZ1]	12	99	Gmunden	15	1	deutsch	1895-01-06	9	1944-10-27	9	KA	KA	KA
650702	Salzkammergut-Zeitung [WZ2]	12	4	Gmunden	15	1	deutsch	1945-10-14	9	2000-11-02	9	KA	KA	KA
650741	Steyrer Zeitung [WZ]	12	99	Steyr	15	1	deutsch	1937-01-01	1	1937-06-30	1	KA	KA	KA
650911	Volksstimme [WZ1]	12	4	Linz	15	0	deutsch	1926-10-02	9	1931-03-31	1	KA	KA	KA
650912	Volksstimme [WZ2]	12	4	Linz	15	0	deutsch	1931-09-05	9	1933-06-11	9	KA	KA	05.09.1931-11.06.1933 erneut als Wochenzeitung erschienen (bis zum Verbot der NSDAP)
651283	Mühlviertler Bote [WZ]	12	4	Linz	15	1	deutsch	1956-07-07	9	1982-12-29	9	KA	KA	KA
653280	Linzer Volksstimme [WZ]	12	4	Linz	15	0	deutsch	1924-03-01	1	1926-09-25	9	KA	KA	KA
660020	Wahrheit! [WZ]	12	4	Linz	15	0	deutsch	1901-01-01	9	1905-12-31	1	KA	KA	Gegründet 05.02.1897 als 2-3 mal monatlich erscheinende Zeitung
660220	Steyrer Volksfreund [WZ]	12	4	Steyr	15	0	deutsch	1900-01-01	4	1906-12-28	9	KA	KA	KA
660231	Kurier Sonntagsausgabe für Salzburg	12	2	KA	16	0	deutsch	1977-09-11	9	1992-08-31	1	KA	KA	KA
660600	Salzburger Chronik [WZ]	12	4	Salzburg	16	0	deutsch	1865-04-01	9	1866-12-31	9	KA	KA	02.01.1867-29.12.1881 3 mal wöchentlich erschienen, ab 01.01.1882 täglich
660652	Salzburger Volksblatt [WZ]	12	4	Salzburg	16	0	deutsch	1985-03-07	9	1986-01-10	9	KA	KA	Nach vorübergehender Einstellung 07.03.1985-10.01.1986 als Wochenzeitung erschienen
670680	Steirerblatt, Das [WZ]	12	4	Graz	17	0	deutsch	1945-10-16	9	1945-12-28	9	KA	KA	KA
671041	Wahrheit, Die [WZ]	12	4	Graz	17	0	deutsch	1945-10-28	9	1945-12-31	1	KA	KA	KA
676030	Arbeiterwille [WZ]	12	4	Graz	17	0	deutsch	1896-01-01	4	1900-10-11	9	KA	KA	Gegründet 09.07.1890 als 2 mal monatlich erscheinende Zeitung, vermutlich ab 1896 Wochenzeitung
676040	Volkswille [WZ]	12	4	Klagenfurt	13	0	deutsch	1900-01-01	4	1905-06-30	9	KA	KA	KA
680061	Außferner Bote [WZ]	12	99	Reutte	18	1	deutsch	1922-05-15	9	1927-09-30	1	KA	KA	KA
680971	Volkszeitung [WZ]	12	4	Innsbruck	18	0	deutsch	1892-12-10	9	1906-12-31	9	KA	KA	KA
681831	Tiroler Bauern-Zeitung [WZ1]	12	4	Innsbruck	18	0	deutsch	1919-01-17	9	1938-03-31	1	KA	KA	Gegründet 03.01.1902 als 2 mal monatlich erscheinende Zeitung
681832	Tiroler Bauern-Zeitung [WZ2]	12	4	Innsbruck	18	0	deutsch	1938-04-13	9	1938-07-07	9	KA	KA	KA
681833	Tiroler Bauern-Zeitung [WZ3]	12	4	Innsbruck	18	0	deutsch	1945-11-19	9	2001-03-15	9	KA	KA	KA
683830	Tiroler Landbote [WZ]	12	4	Innsbruck	18	0	deutsch	1938-07-14	9	1940-07-31	1	KA	KA	KA
690121	Feldkircher Wochenblatt	12	99	Feldkirch	19	1	deutsch	1809-01-01	4	1857-12-22	9	KA	KA	KA
690122	Anzeiger für Feldkirch und Umgebung [WZ]	12	99	Feldkirch	19	1	deutsch	1858-01-09	9	1862-12-31	4	KA	KA	KA
690123	Feldkircher Anzeiger [WZ1]	12	99	Feldkirch	19	1	deutsch	1863-01-06	9	1911-12-31	9	KA	KA	KA
690124	Feldkircher Anzeiger [WZ2]	12	99	Feldkirch	19	1	deutsch	1917-05-23	9	1918-12-25	9	KA	KA	KA
690125	Feldkircher Anzeiger [WZ3]	12	99	Feldkirch	19	1	deutsch	1921-01-01	9	1923-12-29	9	KA	KA	KA
670561	Obersteirer, Der [WZ]	12	2	Bruck an der Mur	17	1	deutsch	1954-01-01	1	2007-02-08	9	KA	KA	erscheint unter den Titel Der Obersteirer und Der neue Obersteirer
670621	Leobner Rundschau [WZ]	12	99	Leoben	17	1	deutsch	1885-10-03	9	1888-05-12	9	KA	KA	 gergründet 01.1885 als Monatszeitung Der Leobner (ab 05.07.1885 vierzehntäglich erschienen)
691980	Vorarlberger Landbote [WZ]	12	4	Innsbruck	18	0	deutsch	1939-06-01	9	1970-12-31	4	KA	KA	KA
923400	Österreichischer Rundfunk - ORF	90	1	Wien	20	0	deutsch	1955-07-27	9	9999-01-01	9	KA	KA	19.01.1952 die öffentliche Verwaltung des Rundfunks bekommt den Namenszusatz „Österreichischer Rundfunk“, 27.07.1955  alle Radiosender offiziell zu einem österreichischen Rundfunk zusammengefasst,  11.12.1957 Gründung Österreichische Rundfunk Ges.m.b.H., die am 01.01.1958 den Hörfunk- und Fernsehbetrieb übernahm, 01.01.1967 Gründung des ORF im Wesentlichen in seiner heutigen Form (https://science.orf.at/stories/3200700/) 
150220	Kurier - Oberösterreich	11	2	Linz	15	0	deutsch	1992-08-29	9	1995-11-12	9	A) Die politische (grundlegende geistige) Richtung des KURIER bestimmt der Herausgeber. Diese Blattlinie bildet einen integrierenden Bestandteil dieses Statuts und der Dienstverträge der publizistischen Mitarbeiter. 1. Der KURIER ist eine unabhängige österreichische Tageszeitung. 2. Die Redaktion hält sich daher von allen direkten und indirekten Einflüssen politischer Parteien und Interessengruppen frei. 3. Der KURIER setzt sich vorbehaltlos für die Integrität, Eigenstaatlichkeit und den föderalistischen Aufbau der Republik Österreich und deren konstruktiven Beitrag zum europäischen Einigungsprozess ein. 4. Der KURIER bekennt sich zur parlamentarischen Demokratie und zum Rechtsstaat. Durch seine publizistische Tätigkeit fördert er deren Weiterentwicklung. Er bekämpft konstruktiv Missstände im demokratischen Leben. 5. Der KURIER betrachtet sich als Instrument der demokratischen Meinungsbildung im Sinne einer umfassenden Informationsfreiheit. 6. Der KURIER tritt für die größtmögliche Freiheit der Staatsbürger im Rahmen der Gesetze ein. Er bejaht daher eine freie Gesellschaftsordnung und ihre geordnete Weiterentwicklung, die jeden Extremismus ausschließt. 7. Der KURIER unterstützt Idee und System der Sozialen Marktwirtschaft unter Berücksichtigung der Ökologie. 8. Richtschnur seiner publizistischen Tätigkeit ist die Vertiefung der Toleranz in allen Lebensbereichen, die Verteidigung der Gewissensfreiheit und die Achtung vor allen Glaubens- und Religionsgemeinschaften. Blatt-Typus: Der KURIER ist eine überregionale Tageszeitung, die sich mit dem Ziel einer möglichst weiten Verbreitung an Leser aus allen Schichten der Bevölkerung wendet und diesen umfassende, objektive und rasche Information, kritische und profilierte Kommentierung und gehaltvolle Unterhaltung bietet.	KA	KA
100421	Abend-Express [1]	11	2	Wien	11	0	deutsch	1958-03-26	9	1960-10-28	9	KA	KA	Der Abend-Express führte nur teilweise eine eigene Ausgabenzählung, hatte aber eine teilweise vom > 102770 Express unabhängige Redaktion
100422	Abend-Express [2]	11	2	Wien	11	0	deutsch	1962-05-15	9	1970-11-26	9	KA	KA	Die Zeitung nahm nach Einstellung der aufgrund eines Eigentümerwechsels zur Konkurrenz gewordenen > 100820 Abend-Zeitung wieder den Titel Abend-Express an, vgl. Zeitungs-Verlag und Zeitschriften-Verlag 59(1962), S. 784.
101202	Arbeiter-Zeitung [Wien]	11	4	Wien	11	0	deutsch	1945-08-05	9	1985-10-15	9	KA	KA	KA
190123	Feldkircher Anzeiger [3]	11	99	Feldkirch	19	1	deutsch	1924-01-09	9	1938-07-30	9	KA	KA	2 mal wöchentlich
611201	Gleichheit [WZ]	12	4	Wien	11	0	deutsch	1887-01-01	1	1889-06-14	9	KA	KA	Nullnummern im Dezember 1886
680251	Kurier Sonntagsausgabe für Tirol	12	2	KA	18	0	deutsch	1977-09-11	9	1983-11-06	9	KA	KA	KA
690940	Volksstimme - Wochenausgabe für Vorarlberg	12	4	Wien	19	0	deutsch	1957-07-03	9	1967-05-05	9	KA	KA	bis 05.05.1967 erschien noch eine Wochenendausgabe für Vorarlberg
177001	Neues Wiener Tagblatt	11	2	Wien	11	0	deutsch	1867-03-10	9	1945-04-07	9	KA	KA	KA
174001	Neues Wiener Abendblatt	11	2	Wien	11	0	deutsch	1868-12-26	9	1938-09-30	9	KA	KA	KA
151001	Mittagsausgabe	11	2	Wien	11	0	deutsch	1936-11-03	9	1938-09-30	9	KA	KA	KA
176001	Neues Wiener Journal	11	2	Wien	11	0	deutsch	1893-10-22	9	1939-01-31	9	KA	KA	KA
152001	Mittagblatt	11	2	Wien	11	0	deutsch	1914-08-22	9	1921-12-31	9	KA	KA	KA
196001	6-Uhr-Abendblatt	11	2	Wien	11	0	deutsch	1938-10-01	9	1939-05-20	9	KA	KA	KA
113101	Wiener Mittagausgabe	11	2	Wien	11	0	deutsch	1939-10-01	9	1939-05-22	9	KA	KA	KA
113001	Wiener Mittag	11	2	Wien	11	0	deutsch	1939-05-23	9	1943-03-13	9	KA	KA	KA
110080	täglich Alles [[Dach/überregional]]	11	2	Wien	20	0	deutsch	1992-04-05	9	2000-08-12	9	KA	KA	KA
110081	täglich Alles für Wien	11	2	Wien	11	0	deutsch	1992-04-05	9	2000-08-12	9	KA	KA	Titelzusatz - für Wien - 1.2.1993 - 1.3.1999
670559	Obersteirer Zeitung	12	2	Bruck an der Mur	19	0	deutsch	1947-08-30	9	1949-06-25	9	KA	KA	KA
101200	Arbeiter-Zeitung [[Dach/überregional]]	11	4	Wien	20	0	deutsch	1945-08-05	9	1985-10-15	9	KA	KA	KA
101250	AZ [[Dach/überregional]]	11	4	Wien	20	0	deutsch	1989-12-12	9	1991-10-31	9	KA	KA	KA
103680	Heute [[Dach/überregional]] [[Gratis]]	11	2	Wien	20	0	deutsch	2004-09-06	9	9999-01-01	9	Heute ist unabhängig von allen politischen Parteien, Institutionen und Interessensgruppen und steht daher für eine offene, unabhängige und ausgewogene Berichterstattung über alle Ereignisse von öffentlichem Interesse aus Politik, Wirtschaft, Kultur, Sport usw.	KA	Gratiszeitung
103681	Heute [Wien] [[Gratis]]	11	2	Wien	11	0	deutsch	2004-09-06	9	9999-01-01	9	Heute ist unabhängig von allen politischen Parteien, Institutionen und Interessensgruppen und steht daher für eine offene, unabhängige und ausgewogene Berichterstattung über alle Ereignisse von öffentlichem Interesse aus Politik, Wirtschaft, Kultur, Sport usw.	KA	Gratiszeitung
103682	Heute [Graz] [[Gratis]]	11	2	Graz	17	0	deutsch	2006-06-12	9	2007-07-06	9	Heute ist unabhängig von allen politischen Parteien, Institutionen und Interessensgruppen und steht daher für eine offene, unabhängige und ausgewogene Berichterstattung über alle Ereignisse von öffentlichem Interesse aus Politik, Wirtschaft, Kultur, Sport usw.	KA	Gratiszeitung
103683	Heute [Linz] [[Gratis]]	11	2	Linz	15	0	deutsch	2006-08-28	9	9999-01-01	9	Heute ist unabhängig von allen politischen Parteien, Institutionen und Interessensgruppen und steht daher für eine offene, unabhängige und ausgewogene Berichterstattung über alle Ereignisse von öffentlichem Interesse aus Politik, Wirtschaft, Kultur, Sport usw.	KA	Gratiszeitung
103684	Heute [St. Pölten] [[Gratis]]	11	2	St. Pölten	14	0	deutsch	2006-05-15	9	9999-01-01	9	Heute ist unabhängig von allen politischen Parteien, Institutionen und Interessensgruppen und steht daher für eine offene, unabhängige und ausgewogene Berichterstattung über alle Ereignisse von öffentlichem Interesse aus Politik, Wirtschaft, Kultur, Sport usw.	KA	Gratiszeitung
104831	Kronen-Zeitung - Wien Krone	11	2	Wien	11	1	deutsch	2000-11-02	9	9999-01-01	9	Die Vielfalt der Meinungen ihres Herausgebers und der Redakteure.	KA	Erscheint ab 10.01.2003 in 4 Lokalausgaben
104850	Kurier [[Dach/überregional]]	11	2	Wien	20	0	deutsch	1959-06-15	9	9999-01-01	9	A) Die politische (grundlegende geistige) Richtung des KURIER bestimmt der Herausgeber. Diese Blattlinie bildet einen integrierenden Bestandteil dieses Statuts und der Dienstverträge der publizistischen Mitarbeiter. 1. Der KURIER ist eine unabhängige österreichische Tageszeitung. 2. Die Redaktion hält sich daher von allen direkten und indirekten Einflüssen politischer Parteien und Interessengruppen frei. 3. Der KURIER setzt sich vorbehaltlos für die Integrität, Eigenstaatlichkeit und den föderalistischen Aufbau der Republik Österreich und deren konstruktiven Beitrag zum europäischen Einigungsprozess ein. 4. Der KURIER bekennt sich zur parlamentarischen Demokratie und zum Rechtsstaat. Durch seine publizistische Tätigkeit fördert er deren Weiterentwicklung. Er bekämpft konstruktiv Missstände im demokratischen Leben. 5. Der KURIER betrachtet sich als Instrument der demokratischen Meinungsbildung im Sinne einer umfassenden Informationsfreiheit. 6. Der KURIER tritt für die größtmögliche Freiheit der Staatsbürger im Rahmen der Gesetze ein. Er bejaht daher eine freie Gesellschaftsordnung und ihre geordnete Weiterentwicklung, die jeden Extremismus ausschließt. 7. Der KURIER unterstützt Idee und System der Sozialen Marktwirtschaft unter Berücksichtigung der Ökologie. 8. Richtschnur seiner publizistischen Tätigkeit ist die Vertiefung der Toleranz in allen Lebensbereichen, die Verteidigung der Gewissensfreiheit und die Achtung vor allen Glaubens- und Religionsgemeinschaften. Blatt-Typus: Der KURIER ist eine überregionale Tageszeitung, die sich mit dem Ziel einer möglichst weiten Verbreitung an Leser aus allen Schichten der Bevölkerung wendet und diesen umfassende, objektive und rasche Information, kritische und profilierte Kommentierung und gehaltvolle Unterhaltung bietet.	KA	KA
109180	Presse, Die [[Dach/überregional]]	11	2	Wien	20	0	deutsch	1948-10-19	9	9999-01-01	9	„Die Presse“ vertritt in Unabhängigkeit von den politischen Parteien bürgerlich-liberale Auffassungen auf einem gehobenen Niveau. Sie tritt für die parlamentarische Demokratie auf der Grundlage des Mehrparteiensystems und für ihre Rechtsstaatlichkeit ein. „Die Presse“ bekennt sich zu den Grundsätzen der sozialen Gerechtigkeit bei Aufrechterhaltung der Eigenverantwortlichkeit des Menschen, zur Wahrung des privaten Eigentums unter Beobachtung seiner Verpflichtungen gegenüber der Gesellschaft, zu den Grundsätzen der sozialen Marktwirtschaft, zur freien unternehmerischen Initiative und zum Leistungswettbewerb. Sie verteidigt die Grundfreiheiten und Menschenrechte und bekämpft alle Bestrebungen, die geeignet sind, diese Freiheiten und Rechte oder die demokratische rechtsstaatliche Gesellschaftsordnung zu gefährden. „Die Presse“ betrachtet es als journalistische Standespflicht, ihre Leserinnen und Leser objektiv und so vollständig wie nur möglich über alle Ereignisse von allgemeinem Interesse zu informieren. Stellung zu nehmen und Kritik zu üben wird von der „Presse“ als ihre Aufgabe und ihr unveräußerliches Recht angesehen.	KA	KA
111480	Volksstimme [[Dach/überregional]]	11	4	Wien	20	0	deutsch	1957-02-21	9	1991-03-03	9	KA	KA	KA
114502	Wiener Zeitung [[Dach/überregional]]	11	6	Wien	20	0	deutsch	1945-09-21	9	2023-06-30	9	KA	KA	KA
104830	Kronen-Zeitung [[Dach/überregional]]	11	2	Wien	20	0	deutsch	2000-11-02	9	9999-01-01	9	Die Vielfalt der Meinungen ihres Herausgebers und der Redakteure.	KA	KA
104851	Kurier - Wien	11	2	Wien	11	1	deutsch	1959-06-15	9	9999-01-01	9	A) Die politische (grundlegende geistige) Richtung des KURIER bestimmt der Herausgeber. Diese Blattlinie bildet einen integrierenden Bestandteil dieses Statuts und der Dienstverträge der publizistischen Mitarbeiter. 1. Der KURIER ist eine unabhängige österreichische Tageszeitung. 2. Die Redaktion hält sich daher von allen direkten und indirekten Einflüssen politischer Parteien und Interessengruppen frei. 3. Der KURIER setzt sich vorbehaltlos für die Integrität, Eigenstaatlichkeit und den föderalistischen Aufbau der Republik Österreich und deren konstruktiven Beitrag zum europäischen Einigungsprozess ein. 4. Der KURIER bekennt sich zur parlamentarischen Demokratie und zum Rechtsstaat. Durch seine publizistische Tätigkeit fördert er deren Weiterentwicklung. Er bekämpft konstruktiv Missstände im demokratischen Leben. 5. Der KURIER betrachtet sich als Instrument der demokratischen Meinungsbildung im Sinne einer umfassenden Informationsfreiheit. 6. Der KURIER tritt für die größtmögliche Freiheit der Staatsbürger im Rahmen der Gesetze ein. Er bejaht daher eine freie Gesellschaftsordnung und ihre geordnete Weiterentwicklung, die jeden Extremismus ausschließt. 7. Der KURIER unterstützt Idee und System der Sozialen Marktwirtschaft unter Berücksichtigung der Ökologie. 8. Richtschnur seiner publizistischen Tätigkeit ist die Vertiefung der Toleranz in allen Lebensbereichen, die Verteidigung der Gewissensfreiheit und die Achtung vor allen Glaubens- und Religionsgemeinschaften. Blatt-Typus: Der KURIER ist eine überregionale Tageszeitung, die sich mit dem Ziel einer möglichst weiten Verbreitung an Leser aus allen Schichten der Bevölkerung wendet und diesen umfassende, objektive und rasche Information, kritische und profilierte Kommentierung und gehaltvolle Unterhaltung bietet.	KA	05.01.2002-23.12.2003 in 4 Lokalausgaben
108240	Österreich [[Dach/überregional]]	11	2	Wien	20	0	deutsch	2006-09-01	9	9999-01-01	9	Die Tageszeitung ÖSTERREICH ist unabhängig, kritisch, modern und ausschließlich ihren Lesern verpflichtet. In ihrer grundlegenden Richtung bekennt sich die Tageszeitung ÖSTERREICH zur demokratischen Republik Österreich und ihren Prinzipien, zu den Menschenrechten und zu einer an Gerechtigkeit und Nachhaltigkeit orientierten Gesellschaft. Daher tritt die Tageszeitung ÖSTERREICH insbesondere dafür ein, die parlamentarische Demokratie und den Rechtsstaat zu bewahren und zu fördern sowie die wirtschaftliche Wettbewerbsfähigkeit, beruhend auf den Grundsätzen der sozialen Marktwirtschaft, und die Eigenständigkeit Österreichs zu stärken. Zur grundlegenden Richtung des Mediums zählen auch Berichte über gesetzlich zulässige Werbeaktionen zur Förderung des Absatzes des Druckwerks ÖSTERREICH und allfälliger weiterer mit diesem Konzern verbundenen Print- und Onlinemedien. Die Tageszeitung ÖSTERREICH ist für Toleranz gegenüber allen ethnischen und religiösen Gruppen, lehnt politischen Extremismus und Totalitarismus ab. Die Redaktion der Tageszeitung ÖSTERREICH ist dem Ehrenkodex der österreichischen Presse verpflichtet. Sie bemüht sich in allen Bereichen um Fairness und Objektivität.	KA	Großteil der Auflage: Gratiszeitung. Da Österreich keinen Anspruch auf Presseförderung hatte, wurde mit 29.06.2018 die Gratiszeitung > 108250 oe24 von der Kaufzeitung getrennt.
108250	oe24 [[Dach/übergional]] [[Gratis]]	11	2	Wien	20	0	deutsch	2018-08-29	9	9999-01-01	9	oe24 ist unabhängig, kritisch, modern und ausschließlich ihren Lesern verpflichtet. In ihrer grundlegenden Richtung bekennt sich oe24 zur demokratischen Republik Österreich und ihren Prinzipien, zu den Menschenrechten und zu einer an Gerechtigkeit und Nachhaltigkeit orientierten Gesellschaft. Daher tritt oe24 insbesondere dafür ein, die parlamentarische Demokratie und den Rechtsstaat zu bewahren und zu fördern sowie die wirtschaftliche Wettbewerbsfähigkeit, beruhend auf den Grundsätzen der sozialen Marktwirtschaft, und die Eigenständigkeit Österreichs zu stärken. oe24 ist für Toleranz gegenüber allen ethnischen und religiösen Gruppen, lehnt politischen Extremismus und Totalitarismus ab. Die Redaktion ist dem Ehrenkodex der österreichischen Presse verpflichtet. Sie bemüht sich in allen Bereichen um Fairness und Objektivität.	KA	Gratiszeitung. Da > 108240 Österreich keinen Anspruch auf Presseförderung hatte, wurde mit 29.06.2018 die Gratiszeitung von der Kaufzeitung  getrennt.
108251	oe24 - Wien [[Gratis]]	11	2	Wien	11	0	deutsch	2018-08-29	9	9999-01-01	9	oe24 ist unabhängig, kritisch, modern und ausschließlich ihren Lesern verpflichtet. In ihrer grundlegenden Richtung bekennt sich oe24 zur demokratischen Republik Österreich und ihren Prinzipien, zu den Menschenrechten und zu einer an Gerechtigkeit und Nachhaltigkeit orientierten Gesellschaft. Daher tritt oe24 insbesondere dafür ein, die parlamentarische Demokratie und den Rechtsstaat zu bewahren und zu fördern sowie die wirtschaftliche Wettbewerbsfähigkeit, beruhend auf den Grundsätzen der sozialen Marktwirtschaft, und die Eigenständigkeit Österreichs zu stärken. oe24 ist für Toleranz gegenüber allen ethnischen und religiösen Gruppen, lehnt politischen Extremismus und Totalitarismus ab. Die Redaktion ist dem Ehrenkodex der österreichischen Presse verpflichtet. Sie bemüht sich in allen Bereichen um Fairness und Objektivität.	KA	KA
108258	oe24/Österreich - Wien  [[Kombination mit Gratis]]	11	2	Wien	11	0	deutsch	2018-08-29	9	9999-01-01	9	KA	KA	KA
108259	oe24/Österreich [[Kombination mit Gratis]]	11	2	Wien	20	0	deutsch	2018-08-29	9	9999-01-01	9	oe24 ist unabhängig, kritisch, modern und ausschließlich ihren Lesern verpflichtet. In ihrer grundlegenden Richtung bekennt sich oe24 zur demokratischen Republik Österreich und ihren Prinzipien, zu den Menschenrechten und zu einer an Gerechtigkeit und Nachhaltigkeit orientierten Gesellschaft. Daher tritt oe24 insbesondere dafür ein, die parlamentarische Demokratie und den Rechtsstaat zu bewahren und zu fördern sowie die wirtschaftliche Wettbewerbsfähigkeit, beruhend auf den Grundsätzen der sozialen Marktwirtschaft, und die Eigenständigkeit Österreichs zu stärken. oe24 ist für Toleranz gegenüber allen ethnischen und religiösen Gruppen, lehnt politischen Extremismus und Totalitarismus ab. Die Redaktion ist dem Ehrenkodex der österreichischen Presse verpflichtet. Sie bemüht sich in allen Bereichen um Fairness und Objektivität.	KA	KA
108480	Österreichische Volksstimme - [Wien]	11	4	Wien	11	0	deutsch	1945-08-05	9	1957-02-20	9	KA	KA	KA
108481	Österreichische Volksstime [[Dach/überregional]]	11	4	Wien	20	0	deutsch	1945-08-05	9	1957-02-20	9	KA	KA	KA
109850	Standard, Der [[Dach/überregional]]	11	2	Wien	20	0	deutsch	1988-10-19	9	9999-01-01	9	DER STANDARD ist ein liberales Medium. Es ist unabhängig von politischen Parteien, Institutionen und Interessengruppen und wendet sich an alle Lesende, die hohe Ansprüche an eine gründliche und umfassende Berichterstattung sowie an eine fundierte, sachgerechte Kommentierung auf den Gebieten von Wirtschaft, Politik, Kultur und Gesellschaft stellen.DER STANDARD lebt die Blattphilosophie in einer ebenso klaren wie anspruchsvollen Weise. Er trennt zwischen Bericht und Kommentar, gewichtet die Ereignisse und lässt seinen Leser:innen den nötigen Spielraum für die eigene Meinung. So fördert er, was zugleich sein Ziel ist: eine mündige Leserschaft.	KA	KA
114600	WirtschaftsBlatt [[Dach/überregional]]	11	2	Wien	20	0	deutsch	1995-06-10	9	2016-09-02	9	KA	KA	KA
120180	Kurier - Burgenland	11	2	KA	12	1	deutsch	1978-03-01	9	9999-01-01	9	A) Die politische (grundlegende geistige) Richtung des KURIER bestimmt der Herausgeber. Diese Blattlinie bildet einen integrierenden Bestandteil dieses Statuts und der Dienstverträge der publizistischen Mitarbeiter. 1. Der KURIER ist eine unabhängige österreichische Tageszeitung. 2. Die Redaktion hält sich daher von allen direkten und indirekten Einflüssen politischer Parteien und Interessengruppen frei. 3. Der KURIER setzt sich vorbehaltlos für die Integrität, Eigenstaatlichkeit und den föderalistischen Aufbau der Republik Österreich und deren konstruktiven Beitrag zum europäischen Einigungsprozess ein. 4. Der KURIER bekennt sich zur parlamentarischen Demokratie und zum Rechtsstaat. Durch seine publizistische Tätigkeit fördert er deren Weiterentwicklung. Er bekämpft konstruktiv Missstände im demokratischen Leben. 5. Der KURIER betrachtet sich als Instrument der demokratischen Meinungsbildung im Sinne einer umfassenden Informationsfreiheit. 6. Der KURIER tritt für die größtmögliche Freiheit der Staatsbürger im Rahmen der Gesetze ein. Er bejaht daher eine freie Gesellschaftsordnung und ihre geordnete Weiterentwicklung, die jeden Extremismus ausschließt. 7. Der KURIER unterstützt Idee und System der Sozialen Marktwirtschaft unter Berücksichtigung der Ökologie. 8. Richtschnur seiner publizistischen Tätigkeit ist die Vertiefung der Toleranz in allen Lebensbereichen, die Verteidigung der Gewissensfreiheit und die Achtung vor allen Glaubens- und Religionsgemeinschaften. Blatt-Typus: Der KURIER ist eine überregionale Tageszeitung, die sich mit dem Ziel einer möglichst weiten Verbreitung an Leser aus allen Schichten der Bevölkerung wendet und diesen umfassende, objektive und rasche Information, kritische und profilierte Kommentierung und gehaltvolle Unterhaltung bietet.	KA	Erscheint 26.09.2005-06.11.2006 in 2 Lokalausgaben
130310	Neue Kärntner Tageszeitung	11	4	Klagenfurt	13	1	deutsch	1993-05-06	9	2010-01-30	9	KA	KA	Erscheint in 2 Lokalausgaben (2001/2002? vorübergehend in 4 Lokalausgaben)
150531	Österreichisches Volksblatt	11	4	Linz	15	0	deutsch	2018-09-11	9	2023-12-30	9	KA	KA	KA
158250	oe24 - Oberösterreich [[Gratis]]	11	2	Wien	15	0	deutsch	2018-08-29	9	9999-01-01	9	oe24 ist unabhängig, kritisch, modern und ausschließlich ihren Lesern verpflichtet. In ihrer grundlegenden Richtung bekennt sich oe24 zur demokratischen Republik Österreich und ihren Prinzipien, zu den Menschenrechten und zu einer an Gerechtigkeit und Nachhaltigkeit orientierten Gesellschaft. Daher tritt oe24 insbesondere dafür ein, die parlamentarische Demokratie und den Rechtsstaat zu bewahren und zu fördern sowie die wirtschaftliche Wettbewerbsfähigkeit, beruhend auf den Grundsätzen der sozialen Marktwirtschaft, und die Eigenständigkeit Österreichs zu stärken. oe24 ist für Toleranz gegenüber allen ethnischen und religiösen Gruppen, lehnt politischen Extremismus und Totalitarismus ab. Die Redaktion ist dem Ehrenkodex der österreichischen Presse verpflichtet. Sie bemüht sich in allen Bereichen um Fairness und Objektivität.	KA	KA
158259	oe24/Österreich - Oberösterreich [[Kombination mit Gratis]]	11	2	Wien	15	0	deutsch	2018-08-29	9	9999-01-01	9	KA	KA	KA
160620	Salzburger Nachrichten	11	2	Salzburg	16	1	deutsch	1945-06-07	9	9999-01-01	9	Die Salzburger Nachrichten sind eine parteipolitisch unabhängige Tageszeitung, dem christlichen Weltbild verpflichtet, und treten unabdingbar für die Freiheit des einzelnen Menschen ein. Die Salzburger Nachrichten sind gegen jede totalitäre Herrschaftsform, respektieren die von der UNO deklarierten Menschenrechte und bekennen sich zu einem neutralen demokratischen Österreich, zur Rechtstaatlichkeit und zum System der sozialen Marktwirtschaft. Die Salzburger Nachrichten sehen in der Erfüllung ihrer Aufgabe, der Information und der Kontrolle, einen wesentlichen Beitrag zur demokratischen Gesellschaft. Die Freiheit der Journalisten, nach bestem Wissen und Gewissen arbeiten zu können, ist durch den Herausgeber garantiert.	KA	16.09.1995-26.02.2012 liegt den regional in Salzburg und angrenzenden Gebieten in Oberösterreich vertriebenen Salzburger Nachrichten ein eigener Lokalteil im Kleinformat bei (zunächst unter dem Titel SALZBURGER, später Salzburger Nachrichten aus Stadt und Land), ab 27.02.2012 wird dieser Lokalteil in ganz Österreich vertrieben. / Wird ab 1988 im Land Salzburg mit 3, ab 1989 mit 6 wöchentlich beiliegenden Lokalnachrichten vertrieben (https://www.sn.at/wiki/Salzburger_Nachrichten, https://www.svh.at/ ).
160621	Salzburger Nachrichten - [Österreich-Ausgabe]	11	2	Salzburg	20	0	deutsch	1989-03-01	9	9999-01-01	9	Die Salzburger Nachrichten sind eine parteipolitisch unabhängige Tageszeitung, dem christlichen Weltbild verpflichtet, und treten unabdingbar für die Freiheit des einzelnen Menschen ein. Die Salzburger Nachrichten sind gegen jede totalitäre Herrschaftsform, respektieren die von der UNO deklarierten Menschenrechte und bekennen sich zu einem neutralen demokratischen Österreich, zur Rechtstaatlichkeit und zum System der sozialen Marktwirtschaft. Die Salzburger Nachrichten sehen in der Erfüllung ihrer Aufgabe, der Information und der Kontrolle, einen wesentlichen Beitrag zur demokratischen Gesellschaft. Die Freiheit der Journalisten, nach bestem Wissen und Gewissen arbeiten zu können, ist durch den Herausgeber garantiert.	KA	Schon ab 31.12.1957 bringt der Untertitel den Anspruch der Salzburger Nachrichten, eine überregionale Zeitung zu bieten, zum Ausdruck. 01.03.1989-15.09.1995 erscheint eine eigene, so benannte Österreich-Ausgabe, später bezeichnet sie sich als Unabhängige Tageszeitung für Österreich. Die inhaltliche Differenzierung geht aber zurück: Ab 27.02.2012 wird der (kleinformatige) Lokalteil Salzburger Nachrichten aus Stadt und Land in ganz Österreich vertrieben (https://www.geschichtewiki.wien.gv.at/Salzburger_Nachrichten, https://www.sn.at/wiki/Salzburger_Nachrichten).
160629	Salzburger Nachrichten [[Dach/überregional]]	11	2	Salzburg	20	0	deutsch	1989-03-01	4	9999-01-01	9	Die Salzburger Nachrichten sind eine parteipolitisch unabhängige Tageszeitung, dem christlichen Weltbild verpflichtet, und treten unabdingbar für die Freiheit des einzelnen Menschen ein. Die Salzburger Nachrichten sind gegen jede totalitäre Herrschaftsform, respektieren die von der UNO deklarierten Menschenrechte und bekennen sich zu einem neutralen demokratischen Österreich, zur Rechtstaatlichkeit und zum System der sozialen Marktwirtschaft. Die Salzburger Nachrichten sehen in der Erfüllung ihrer Aufgabe, der Information und der Kontrolle, einen wesentlichen Beitrag zur demokratischen Gesellschaft. Die Freiheit der Journalisten, nach bestem Wissen und Gewissen arbeiten zu können, ist durch den Herausgeber garantiert.	KA	https://www.sn.at/wiki/Salzburger_Nachrichten, https://www.svh.at/ 
170150	Kleine Zeitung [[Dach/überregional]]	11	2	Graz	20	0	deutsch	1948-10-01	9	9999-01-01	9	Die KLEINE ZEITUNG ist eine von allen politischen Parteien und Interessenvertretungen unabhängige Tageszeitung. Sie steht auf dem Boden christlicher Weltanschauung, tritt für eine plurale, demokratische Gesellschaftsordnung, die Eigenständigkeit der Bundesländer und die völkerrechtliche Unabhängigkeit der Republik Österreich ein und begrüßt den europäischen Einigungsprozess.	KA	KA
170152	Kleine Zeitung [Steiermark]	11	2	Graz	17	1	deutsch	1948-10-01	9	9999-01-01	9	Die KLEINE ZEITUNG ist eine von allen politischen Parteien und Interessenvertretungen unabhängige Tageszeitung. Sie steht auf dem Boden christlicher Weltanschauung, tritt für eine plurale, demokratische Gesellschaftsordnung, die Eigenständigkeit der Bundesländer und die völkerrechtliche Unabhängigkeit der Republik Österreich ein und begrüßt den europäischen Einigungsprozess.	KA	Erscheint ab 4.10. 1970 in 2, ab 03.01.1971 in 4, ab 05.11.1989 in 5, ab 06.01.1990 in 6, ab 01.05.1990 in 7, ab 08.12.1990 in 8, ab 08.01.1991 in 10, ab 14.01.1996 in 11, ab 11.06.2002 in 12, ab 14.03.2006? in 10 Lokalausgaben
170621	Obersteirer Zeitung	11	99	Leoben	17	1	deutsch	1888-08-20	9	1894-12-30	9	KA	KA	2 mal wöchentlich
170720	Südost-Tagespost	11	4	Graz	17	1	deutsch	1951-10-02	9	1987-01-31	9	KA	KA	seit 1985? in 4 Lokalausgaben erschienen
180870	Tiroler Tageszeitung	11	2	Innsbruck	18	1	deutsch	1945-06-21	9	9999-01-01	9	Die Tiroler Tageszeitung berichtet als Landeszeitung objektiv und in völliger Unabhängigkeit von politischen und wirtschaftlichen Interessensgruppen. Sie setzt sich ein für die Interessen Tirols, berücksichtigt die Besonderheiten des ökologischen sensiblen Alpenraums, achtet in zeitgemäßer Art die Traditionen des Landes und betont die geistige Einheit Gesamttirols. Die Tiroler Tageszeitung tritt ein für die Freiheit, Würde und Eigenverantwortung des Einzelnen (Personalität), für die Selbstverantwortung kleiner Gemeinschaften (Subsidiarität) und für die Mitverantwortung des Einzelnen in der Gemeinschaft (Solidarität). Die Tiroler Tageszeitung bekennt sich zu den Menschenrechten, zur Parlamentarischen Demokratie, zur freien, sozialen Marktwirtschaft und zur Republik Österreich mit ihrem föderalistischen Aufbau. Die Tiroler Tageszeitung steht für die Meinungsfreiheit und Meinungsvielfalt. Sie lehnt politische Aktivitäten ab, die geeignet sind, die freie, pluralistische Gesellschaftsordnung zu gefährden. Die Tiroler Tageszeitung orientiert sich in ihrer publizistischen Arbeit am Ehrenkodex der österreichischen Presse.	KA	Zunächst Zeitung der US-amerikanischen Besatzungsmacht, ab 10.07.1945 der französischen Besatzungsmacht, die sich bis 24.04.1947 schrittweise aus ihrer Kontrollfunktion zurückzog - ab 01.07.1992 in 4, ab  14.01.2002 in 6, ab 02.01.2006? in 4?, ab 12.01.2010 in 8 Lokalausgaben
181870	Tiroler Tageszeitung Kompakt [[Gratis]]	11	2	Innsbruck	18	0	deutsch	2008-05-15	9	9999-01-01	9	Die Tiroler Tageszeitung berichtet als Landeszeitung objektiv und in völliger Unabhängigkeit von politischen und wirtschaftlichen Interessensgruppen. Sie setzt sich ein für die Interessen Tirols, berücksichtigt die Besonderheiten des ökologischen sensiblen Alpenraums, achtet in zeitgemäßer Art die Traditionen des Landes und betont die geistige Einheit Gesamttirols. Die Tiroler Tageszeitung tritt ein für die Freiheit, Würde und Eigenverantwortung des Einzelnen (Personalität), für die Selbstverantwortung kleiner Gemeinschaften (Subsidiarität) und für die Mitverantwortung des Einzelnen in der Gemeinschaft (Solidarität). Die Tiroler Tageszeitung bekennt sich zu den Menschenrechten, zur Parlamentarischen Demokratie, zur freien, sozialen Marktwirtschaft und zur Republik Österreich mit ihrem föderalistischen Aufbau. Die Tiroler Tageszeitung steht für die Meinungsfreiheit und Meinungsvielfalt. Sie lehnt politische Aktivitäten ab, die geeignet sind, die freie, pluralistische Gesellschaftsordnung zu gefährden. Die Tiroler Tageszeitung orientiert sich in ihrer publizistischen Arbeit am Ehrenkodex der österreichischen Presse.	KA	Gratiszeitung
181910	Neue Express [[Gratis]]	11	2	Innsbruck	18	0	deutsch	2006-06-26	9	2007-10-16	9	KA	KA	Gratiszeitung
182870	Kombi Top Tirol [[Kombination]]	11	2	Innsbruck	18	0	deutsch	2008-05-15	9	9999-01-01	9	Die Tiroler Tageszeitung berichtet als Landeszeitung objektiv und in völliger Unabhängigkeit von politischen und wirtschaftlichen Interessensgruppen. Sie setzt sich ein für die Interessen Tirols, berücksichtigt die Besonderheiten des ökologischen sensiblen Alpenraums, achtet in zeitgemäßer Art die Traditionen des Landes und betont die geistige Einheit Gesamttirols. Die Tiroler Tageszeitung tritt ein für die Freiheit, Würde und Eigenverantwortung des Einzelnen (Personalität), für die Selbstverantwortung kleiner Gemeinschaften (Subsidiarität) und für die Mitverantwortung des Einzelnen in der Gemeinschaft (Solidarität). Die Tiroler Tageszeitung bekennt sich zu den Menschenrechten, zur Parlamentarischen Demokratie, zur freien, sozialen Marktwirtschaft und zur Republik Österreich mit ihrem föderalistischen Aufbau. Die Tiroler Tageszeitung steht für die Meinungsfreiheit und Meinungsvielfalt. Sie lehnt politische Aktivitäten ab, die geeignet sind, die freie, pluralistische Gesellschaftsordnung zu gefährden. Die Tiroler Tageszeitung orientiert sich in ihrer publizistischen Arbeit am Ehrenkodex der österreichischen Presse.	KA	KA
192990	TOP Vorarlberg	11	2	Bregenz	19	1	deutsch	2004-01-01	4	9999-01-01	9	KA	KA	KA
300210	ServusTV	30	2	Wals-Siezenheim	20	0	deutsch	2009-10-01	9	9999-01-01	9	Telekommunikations- und Rundfunkunternehmung Grundlegende Programmausrichtung: Kultur, Kunst, Wirtschaft, Sport, Unterhaltung und Wissenschaft des Alpen-Donau-Adria Raumes	KA	KA
452280	volksblatt.at	40	2	Linz	20	1	deutsch	1998-12-01	7	9999-01-01	9	Das „Oberösterreichische Volksblatt“ versteht sich als regionales oberösterreichisches Medienhaus, das dem christlich-sozialen Gedankengut verpflichtet ist. Das „Oberösterreichische Volksblatt“ ist redaktionell unabhängig und widmet sich insbesondere den Interessen der Bewohner der Region im politischen, wirtschaftlichen, sportlichen, kulturellen und sozialen Bereich. Das „Oberösterreichische Volksblatt“ ist dem Ehrenkodex der österreichischen Presse verpflichtet.	KA	lt. E-Mail von Geschäftführer Mag. Wolfgang Eder, 26.03.2024, \nhttps://volksblatt.at/impressum/ 
410020	selektiv	40	2	Wien	20	0	deutsch	2024-01-05	9	9999-01-01	9	Das neue Medium für Wirtschaft in Österreich. - Selektiv ist ein tagesaktuelles Medium mit liberaler Haltung. Es ist unabhängig von politischen Parteien, Institutionen und Kammern sowie finanziellen Unterstützern des Projekts.	KA	KA
410010	newsflix	40	2	Wien	20	0	deutsch	2024-02-13	9	9999-01-01	9	Inspiriert vom Erfolg des satirischen Polit-Blogs 'Kopfnüsse' von Christian Nusser, erweitert Newsflix das Angebot um eine facettenreiche Nachrichten-Webseite. Mit dem Ziel, mediale Lebensqualität zu steigern, zeichnet sich Newsflix durch hochwertigen Inhalt und Optik, erklärende und aufklärende Berichterstattung, Meinungsoffenheit, Konstruktivität und eine positive, humorvolle Note aus. Es bietet einen einzigartigen Mix aus Tagesnews und Magazin-Inhalten, unterstützt von einem Expertenpool, multimedial zugänglich gemacht für alle Endgeräte. Newsflix richtet sich an eine urbane, gebildete und neugierige Zielgruppe, die Wert auf Qualität und Tiefgang legt.	KA	KA
630480	Neue Zeit [WZ]	12	4	Klagenfurt	13	0	deutsch	1945-10-18	9	1945-12-31	1	KA	KA	Die Zeitung beruft sich auf die Wochenzeitung Kärntner Volksblatt (20.03.1927-16.07.1933) und die steirische Zeitung > 176030 Arbeiterwille
104603	Volksblatt	11	4	Wien	11	0	deutsch	1962-10-02	9	1979-11-15	9	KA	KA	KA
140141	Kleine Volksblatt, Das - Ausgabe für Niederösterreich und das Burgenland	11	4	Wien	14	0	deutsch	1962-10-02	9	1966-10-21	9	KA	KA	KA
607211	Neue Zeitung, Die [WZ]	14	4	Wien	11	0	deutsch	1970-12-05	9	1971-07-10	9	KA	KA	KA
631480	Kärntner Volksblatt	12	4	Klagenfurt	13	0	deutsch	1927-03-20	9	1933-07-16	9	KA	KA	Die Zeitung beruft sich auf die Wochenzeitung Kärntner Volksblatt (20.03.1927-16.07.1933) und die steirische Zeitung > 176030 Arbeiterwille
612750	Wiener Kurier [WZ]	12	4	Wien	11	0	deutsch	1954-10-23	9	1955-07-02	9	KA	KA	KA
118001	Neuigkeits-Welt-Blatt	11	2	Wien	11	0	deutsch	1874-01-06	9	1943-12-31	9	KA	KA	KA
118002	Neuigkeits-Welt-Blatt - Provinzausgabe	11	2	Wien	14	0	deutsch	1920-07-01	9	1943-12-31	9	KA	KA	KA
119300	Reichspost	11	4	Wien	11	0	deutsch	1894-01-01	9	1938-09-30	9	KA	KA	KA
101155	Volks-Zeitung	11	2	Wien	11	0	deutsch	1918-11-14	9	1944-08-31	9	KA	KA	KA
101154	Oesterreichische Volks-Zeitung	11	2	Wien	11	0	deutsch	1888-08-19	9	1918-11-13	9	KA	KA	KA
101153	Konstitutionelle Vorstadt-Zeitung	11	2	Wien	11	0	deutsch	1863-05-17	9	1888-08-18	9	KA	KA	KA
101152	Vorstadt-Zeitung	11	2	Wien	11	0	deutsch	1859-01-30	9	1863-05-16	9	KA	KA	KA
101151	Wiener Vorstadt-Zeitung	11	2	Wien	11	0	deutsch	1856-01-01	9	1859-01-29	9	KA	KA	KA
101150	Wiener Stadt- und Vorstadtzeitung	11	2	Wien	11	0	deutsch	1855-04-01	9	1855-12-30	9	KA	KA	KA
104600	Kleine Oesterreichische Volks-Zeitung	11	2	Wien	11	0	deutsch	1905-04-01	9	1918-11-13	9	KA	KA	KA
104500	Oesterreichische Volkszeitung - 2 Kreuzer-Ausgabe	11	2	Wien	11	0	deutsch	1893-12-31	9	1905-03-31	9	KA	KA	KA
\.


--
-- Data for Name: mo_year; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3.mo_year (id_mo, year, mo_year, calc, circulation, circulation_source, unique_users, unique_users_source, reach_nat, reach_nat_source, reach_reg, reach_reg_source, market_share, market_share_source, comments) FROM stdin;
103680	2021-12-01	1036802021	1	480589	1502021	99	99	9.3	2002021	99.0	99	17.8	1502021	Mo-Fr
103684	2021-12-01	1036842021	2	126252	1502021	99	99	99.0	99	13.1	2002021	4.7	1502021	Mo-Fr
103683	2021-12-01	1036832021	2	80323	1502021	99	99	99.0	99	8.6	2002021	3.0	1502021	Mo-Fr
103681	2021-12-01	1036812021	2	274014	1502021	99	99	99.0	99	21.8	2002021	10.1	1502021	Mo-Fr
170150	2021-12-01	1701502021	1	302147	1502021	99	99	9.3	2002021	99.0	99	11.2	1502021	Mo-Fr
130152	2021-12-01	1301522021	2	97789	1502021	99	99	2.9	2002021	43.4	2002021	3.6	1502021	Mo-So
170152	2021-12-01	1701522021	2	204361	1502021	99	99	6.4	2002021	38.9	2002021	7.6	1502021	Mo-So
104830	2021-12-01	1048302021	1	736867	1502021	99	99	23.3	2002021	99.0	99	27.2	1502021	Mo-So
120160	2021-12-01	1201602021	2	39393	1502021	99	99	99.0	99	36.0	2002021	1.5	1502021	Mo-So
130180	2021-12-01	1301802021	2	72840	1502021	99	99	99.0	99	30.2	2002021	2.7	1502021	Mo-So
140180	2021-12-01	1401802021	2	151422	1502021	99	99	99.0	99	26.5	2002021	5.6	1502021	Mo-So
150180	2021-12-01	1501802021	2	129032	1502021	99	99	99.0	99	24.0	2002021	4.8	1502021	Mo-So
160200	2021-12-01	1602002021	2	61093	1502021	99	99	99.0	99	25.1	2002021	2.3	1502021	Mo-So
170220	2021-12-01	1702202021	2	125550	1502021	99	99	99.0	99	25.8	2002021	4.6	1502021	Mo-So
180200	2021-12-01	1802002021	2	48238	1502021	99	99	99.0	99	19.3	2002021	1.8	1502021	Mo-So
190200	2021-12-01	1902002021	2	3944	1502021	99	99	99.0	99	4.8	2002021	0.2	1502021	Mo-So
104831	2021-12-01	1048312021	2	105355	1502021	99	99	99.0	99	18.9	2002021	3.9	1502021	Mo-So
104850	2021-12-01	1048502021	1	143592	1502021	99	99	6.3	2002021	99.0	99	5.3	1502021	Mo-So
120180	2021-12-01	1201802021	2	10102	1502021	99	99	99.0	99	12.6	2002021	0.4	1502021	Mo-So
140210	2021-12-01	1402102021	2	54256	1502021	99	99	99.0	99	13.1	2002021	2.0	1502021	Mo-So
104851	2021-12-01	1048512021	2	57739	1502021	99	99	99.0	99	10.0	2002021	2.1	1502021	Mo-So
190470	2021-12-01	1904702021	1	13975	1502021	99	99	0.4	2002021	9.2	2002021	0.5	1502021	Di-So
150550	2021-12-01	1505502021	1	126797	1502021	99	99	5.4	2002021	28.7	2002021	4.7	1502021	Mo-Sa
108250	2021-12-01	1082502021	1	407022	1502021	99	99	99.0	9802021	99.0	99	15.0	1502021	Mo-Fr
158250	2021-12-01	1582502021	2	47138	1502021	99	99	99.0	99	99.0	9802021	1.7	1502021	Mo-Fr
108251	2021-12-01	1082512021	2	269277	1502021	99	99	99.0	99	99.0	9802021	10.0	1502021	Mo-Fr
108259	2021-12-01	1082592021	0	436260	1502021	99	99	6.8	2002021	99.0	99	16.1	1502021	oe24: Mo-Fr, Österreich: Mo-So, Auflage bezieht sich auf Mo-Fr 
158259	2021-12-01	1582592021	0	49719	1502021	99	99	99.0	99	5.2	2002021	1.8	1502021	oe24: Mo-Fr, Österreich: Mo-So, Auflage bezieht sich auf Mo-Fr 
108258	2021-12-01	1082582021	0	283086	1502021	99	99	99.0	99	14.6	2002021	10.5	1502021	oe24: Mo-Fr, Österreich: Mo-So, Auflage bezieht sich auf Mo-Fr 
108240	2021-12-01	1082402021	1	80871	1502021	99	99	99.0	9802021	99.0	99	3.0	1502021	Mo-So
158240	2021-12-01	1582402021	2	7557	1502021	99	99	99.0	99	99.0	9802021	0.3	1502021	Mo-So
108241	2021-12-01	1082412021	2	34960	1502021	99	99	99.0	99	99.0	9802021	1.3	1502021	Mo-So
150531	2021-12-01	1505312021	1	16628	9702021	99	99	99.0	99	99.0	99	0.6	9702021	Mo-Sa, Mailverkehr mit Administration des Oberösterreichischen Volksblattes, angefragt am 25.02.2021
109180	2021-12-01	1091802021	1	75404	1502021	99	99	3.8	2002021	99.0	99	2.8	1502021	Mo-So
109181	2021-12-01	1091812021	2	99	9802021	99	99	99.0	99	6.1	2002021	99.0	9802021	Mo-So
160629	2021-12-01	1606292021	1	82818	1502021	99	99	3.1	2002021	99.0	99	3.1	1502021	Mo-Sa
160620	2021-12-01	1606202021	2	55098	1502021	99	99	99.0	99	30.8	2002021	2.0	1502021	Mo-Sa, Verkaufte Auflage
109850	2021-12-01	1098502021	1	66998	1502021	99	99	7.2	2002021	12.5	2002021	2.5	1502021	Mo-Sa
119850	2021-12-01	1198502021	2	99	9802021	99	99	99.0	99	99.0	99	99.0	9802021	Mo-Sa
119860	2021-12-01	1198602021	0	99	9802021	99	99	99.0	9802021	99.0	99	99.0	9802021	Mo-Fr
180870	2021-12-01	1808702021	1	85304	1502021	99	99	3.1	2002021	34.8	2002021	3.2	1502021	Mo-So
181870	2021-12-01	1818702021	1	9270	1502021	99	99	99.0	9802021	99.0	9802021	0.3	1502021	Mo-Fr
182870	2021-12-01	1828702021	0	99	99	99	99	3.3	2002021	36.4	2002021	99.0	99	TT: Mo-So, TT Kompakt: Mo-Fr
190990	2021-12-01	1909902021	1	57505	1502021	99	99	2.1	2002021	46.5	2002021	2.1	1502021	Mo-Sa
192990	2021-12-01	1929902021	0	99	99	99	99	2.3	2002021	49.0	2002021	99.0	99	VN: Mo-Sa, NEUE: Di-So
114502	2021-12-01	1145022021	1	20800	9702021	99	99	99.0	99	99.0	99	0.8	9702021	Mo-Sa, https://www.wienerzeitung.at/_em_daten/_wzo/2021/03/01/210301_1245_wz_tarif_folder_2021.pdf 
114503	2021-12-01	1145032021	2	99	9802021	99	99	99.0	99	99.0	99	99.0	9802021	Mo-Sa
103680	2022-12-01	1036802022	1	483101	1502022	99	99	8.2	2002022	99.0	99	19.0	1502022	Mo-Fr
103684	2022-12-01	1036842022	2	128422	1502022	99	99	99.0	99	10.8	2002022	5.0	1502022	Mo-Fr
103683	2022-12-01	1036832022	2	86172	1502022	99	99	99.0	99	8.7	2002022	3.4	1502022	Mo-Fr
103681	2022-12-01	1036812022	2	268536	1502022	99	99	99.0	99	18.1	2002022	10.6	1502022	Mo-Fr
170150	2022-12-01	1701502022	1	287422	1502022	99	99	8.6	2002022	99.0	99	11.3	1502022	Mo-Fr
130152	2022-12-01	1301522022	2	92982	1502022	99	99	2.6	2002022	39.1	2002022	3.7	1502022	Mo-So
170152	2022-12-01	1701522022	2	194442	1502022	99	99	6.0	2002022	38.2	2002022	7.6	1502022	Mo-So
104830	2022-12-01	1048302022	1	687590	1502022	99	99	22.2	2002022	99.0	99	27.0	1502022	Mo-So
120160	2022-12-01	1201602022	2	37605	1502022	99	99	99.0	99	35.6	2002022	1.5	1502022	Mo-So
130180	2022-12-01	1301802022	2	69245	1502022	99	99	99.0	99	29.1	2002022	2.7	1502022	Mo-So
140180	2022-12-01	1401802022	2	143032	1502022	99	99	99.0	99	23.1	2002022	5.6	1502022	Mo-So
150180	2022-12-01	1501802022	2	120635	1502022	99	99	99.0	99	20.1	2002022	4.7	1502022	Mo-So
160200	2022-12-01	1602002022	2	58061	1502022	99	99	99.0	99	24.3	2002022	2.3	1502022	Mo-So
170220	2022-12-01	1702202022	2	118949	1502022	99	99	99.0	99	25.9	2002022	4.7	1502022	Mo-So
180200	2022-12-01	1802002022	2	45249	1502022	99	99	99.0	99	22.3	2002022	1.8	1502022	Mo-So
190200	2022-12-01	1902002022	2	3340	1502022	99	99	99.0	99	3.7	2002022	0.1	1502022	Mo-So
104831	2022-12-01	1048312022	2	91474	1502022	99	99	99.0	99	19.3	2002022	3.6	1502022	Mo-So
104850	2022-12-01	1048502022	1	138569	1502022	99	99	5.6	2002022	99.0	99	5.4	1502022	Mo-So
120180	2022-12-01	1201802022	2	9881	1502022	99	99	99.0	99	13.1	2002022	0.4	1502022	Mo-So
140210	2022-12-01	1402102022	2	52396	1502022	99	99	99.0	99	8.9	2002022	2.1	1502022	Mo-So
104851	2022-12-01	1048512022	2	55322	1502022	99	99	99.0	99	10.4	2002022	2.2	1502022	Mo-So
190470	2022-12-01	1904702022	1	13104	1502022	99	99	0.4	2002022	8.9	2002022	0.5	1502022	Di-So
150550	2022-12-01	1505502022	1	122634	1502022	99	99	4.3	2002022	23.1	2002022	4.8	1502022	Mo-Sa
108250	2022-12-01	1082502022	1	379649	1502022	99	99	3.3	2002022	99.0	99	14.9	1502022	Mo-Fr
158250	2022-12-01	1582502022	2	26499	1502022	99	99	99.0	99	3.2	2002022	1.0	1502022	Mo-Fr
108251	2022-12-01	1082512022	2	259713	1502022	99	99	99.0	99	7.2	2002022	10.2	1502022	Mo-Fr
108259	2022-12-01	1082592022	0	406621	1502022	99	99	6.1	2002022	99.0	99	16.0	1502022	oe24: Mo-Fr, Österreich: Mo-Sa, Auflage bezieht sich auf Mo-Fr 
158259	2022-12-01	1582592022	0	28754	1502022	99	99	99.0	99	4.9	2002022	1.1	1502022	oe24: Mo-Fr, Österreich: Mo-Sa, Auflage bezieht sich auf Mo-Fr 
108258	2022-12-01	1082582022	0	273310	1502022	99	99	99.0	99	13.4	2002022	10.7	1502022	oe24: Mo-Fr, Österreich: Mo-Sa, Auflage bezieht sich auf Mo-Fr 
108240	2022-12-01	1082402022	1	29644	1502022	99	99	3.7	2002022	99.0	99	1.2	1502022	Mo-Sa 
158240	2022-12-01	1582402022	2	2379	1502022	99	99	99.0	99	2.1	2002022	0.1	1502022	Mo-Sa
108241	2022-12-01	1082412022	2	15477	1502022	99	99	99.0	99	9.0	2002022	0.6	1502022	Mo-Sa
150531	2022-12-01	1505312022	1	21000	9702022	99	99	99.0	99	99.0	99	0.8	9702022	Mo-Sa, https://www.wdf.at/wp-content/uploads/2022/02/0221-OOeVB.pdf
109180	2022-12-01	1091802022	1	75056	1502022	99	99	3.3	2002022	99.0	99	3.0	1502022	Mo-So
109181	2022-12-01	1091812022	2	99	9802022	99	99	99.0	99	5.1	2002022	99.0	9802022	Mo-So
160629	2022-12-01	1606292022	1	79677	1502022	99	99	3.1	2002022	99.0	99	3.1	1502022	Mo-Sa
160620	2022-12-01	1606202022	2	52165	1502022	99	99	99.0	99	30.7	2002022	2.1	1502022	Mo-Sa, Verkaufte Auflage
109850	2022-12-01	1098502022	1	64509	1502022	99	99	6.8	2002022	99.0	99	2.5	1502022	Mo-Sa
119850	2022-12-01	1198502022	2	99	9802022	99	99	99.0	99	11.2	2002022	99.0	9802022	Mo-Sa
119860	2022-12-01	1198602022	0	99	9802022	99	99	99.0	9802022	99.0	99	99.0	9802023	Mo-Fr
180870	2022-12-01	1808702022	1	82992	1502022	99	99	3.1	2002022	34.3	2002022	3.3	1502022	Mo-So
181870	2022-12-01	1818702022	1	7479	1502022	99	99	99.0	9802022	99.0	9802022	0.3	1502022	Mo-Fr
182870	2022-12-01	1828702022	0	99	99	99	99	3.3	2002022	36.0	2002022	99.0	99	TT: Mo-So, TT Kompakt: Mo-Fr
190990	2022-12-01	1909902022	1	55376	1502022	99	99	2.0	2002022	43.1	2002022	2.2	1502022	Mo-Sa
192990	2022-12-01	1929902022	0	0	99	99	99	2.2	2002022	46.1	2002022	99.0	99	VN: Mo-Sa, NEUE: Di-So
114502	2022-12-01	1145022022	1	18355	9702022	99	99	99.0	99	99.0	99	0.7	9702022	Mo-Sa, https://www.wienerzeitung.at/h/die-wiener-zeitung-und-die-fakten 
114503	2022-12-01	1145032022	2	99	9802022	99	99	99.0	99	99.0	99	99.0	9802022	Mo-Sa
103680	2023-12-01	1036802023	1	455857	1502023	99	99	8.8	2002023	99.0	99	19.1	1502023	Mo-Fr
103684	2023-12-01	1036842023	2	122804	1502023	99	99	99.0	99	12.5	2002023	5.1	1502023	Mo-Fr
103683	2023-12-01	1036832023	2	80980	1502023	99	99	99.0	99	9.3	2002023	3.4	1502023	Mo-Fr
103681	2023-12-01	1036812023	2	252073	1502023	99	99	99.0	99	17.1	2002023	10.6	1502023	Mo-Fr
170150	2023-12-01	1701502023	1	274911	1502023	99	99	7.6	2002023	99.0	99	11.5	1502023	Mo-Fr
130152	2023-12-01	1301522023	2	89215	1502023	99	99	2.3	2002023	34.9	2002023	3.7	1502023	Mo-So
170152	2023-12-01	1701522023	2	185700	1502023	99	99	5.3	2002023	33.1	2002023	7.8	1502023	Mo-So
104830	2023-12-01	1048302023	1	642404	1502023	99	99	22.3	2002023	99.0	99	26.9	1502023	Mo-So
120160	2023-12-01	1201602023	2	35341	1502023	99	99	99.0	99	35.5	2002023	1.5	1502023	Mo-So
130180	2023-12-01	1301802023	2	64718	1502023	99	99	99.0	99	31.4	2002023	2.7	1502023	Mo-So
140180	2023-12-01	1401802023	2	133436	1502023	99	99	99.0	99	23.8	2002023	5.6	1502023	Mo-So
150180	2023-12-01	1501802023	2	111090	1502023	99	99	99.0	99	21.8	2002023	4.7	1502023	Mo-So
160200	2023-12-01	1602002023	2	54344	1502023	99	99	99.0	99	26.3	2002023	2.3	1502023	Mo-So
170220	2023-12-01	1702202023	2	111845	1502023	99	99	99.0	99	26.6	2002023	4.7	1502023	Mo-So
180200	2023-12-01	1802002023	2	41753	1502023	99	99	99.0	99	19.9	2002023	1.8	1502023	Mo-So
190200	2023-12-01	1902002023	2	3025	1502023	99	99	99.0	99	5.6	2002023	0.1	1502023	Mo-So
104831	2023-12-01	1048312023	2	86854	1502023	99	99	99.0	99	17.0	2002023	3.6	1502023	Mo-So
104850	2023-12-01	1048502023	1	132981	1502023	99	99	5.5	2002023	99.0	99	5.6	1502023	Mo-So
120180	2023-12-01	1201802023	2	9582	1502023	99	99	99.0	99	10.6	2002023	0.4	1502023	Mo-So
140210	2023-12-01	1402102023	2	50341	1502023	99	99	99.0	99	9.4	2002023	2.1	1502023	Mo-So
104851	2023-12-01	1048512023	2	53019	1502023	99	99	99.0	99	9.3	2002023	2.2	1502023	Mo-So
190470	2023-12-01	1904702023	1	11536	1502023	99	99	0.7	2002023	11.6	2002023	0.5	1502023	Di-So
150550	2023-12-01	1505502023	1	116527	1502023	99	99	4.7	2002023	24.5	2002023	4.9	1502023	Mo-Sa
108250	2023-12-01	1082502023	1	343421	1502023	99	99	4.7	2002023	99.0	99	14.4	1502023	Mo-Fr
158250	2023-12-01	1582502023	2	25204	1502023	99	99	99.0	99	4.1	2002023	1.1	1502023	Mo-Fr
108251	2023-12-01	1082512023	2	223470	1502023	99	99	99.0	99	9.1	2002023	9.4	1502023	Mo-Fr
108259	2023-12-01	1082592023	0	369539	1502023	99	99	7.4	2002023	99.0	99	15.5	1502023	oe24: Mo-Fr, Österreich: Mo-Sa, Auflagenberechnung (basierend auf ÖAW-Detailangaben) bezieht sich auf Mo-Fr 
300013	2004-12-01	3000132004	0	99	99	99	99	43.7	1102004	99.0	99	22.0	1102011	KA
158259	2023-12-01	1582592023	0	27233	1502023	99	99	99.0	99	6.2	2002023	1.1	1502023	oe24: Mo-Fr, Österreich: Mo-Sa, Auflagenberechnung (basierend auf ÖAW-Detailangaben) bezieht sich auf Mo-Fr 
108258	2023-12-01	1082582023	0	237344	1502023	99	99	99.0	99	14.4	2002023	9.9	1502023	oe24: Mo-Fr, Österreich: Mo-Sa, Auflagenberechnung (basierend auf ÖAW-Detailangaben) bezieht sich auf Mo-Fr 
108240	2023-12-01	1082402023	1	29664	1502023	99	99	3.7	2002023	99.0	99	1.2	1502023	Mo-Sa 
158240	2023-12-01	1582402023	2	2131	1502023	99	99	99.0	99	2.6	2002023	0.1	1502023	Mo-Sa
108241	2023-12-01	1082412023	2	16837	1502023	99	99	99.0	99	7.8	2002023	0.7	1502023	Mo-Sa
150531	2023-12-01	1505312023	1	18000	9702023	99	99	99.0	99	99.0	99	0.8	9702023	Mo-Sa, https://www.wienerzeitung.at/a/wie-das-land-ooe-eine-oevp-zeitung-mit-steuergeld-erhaelt 
109180	2023-12-01	1091802023	1	73957	1502023	99	99	3.5	2002023	99.0	99	3.1	1502023	Mo-So
109181	2023-12-01	1091812023	2	99	9802023	99	99	99.0	99	5.5	2002023	99.0	9802023	Mo-So
160629	2023-12-01	1606292023	1	77985	1502023	99	99	3.1	2002023	99.0	99	3.3	1502023	Mo-Sa
160620	2023-12-01	1606202023	2	51048	1502023	99	99	99.0	99	29.4	2002023	2.1	1502023	Mo-Sa, Verkaufte Auflage
109850	2023-12-01	1098502023	1	74756	1502023	99	99	6.6	2002023	99.0	99	3.1	1502023	Mo-Sa
119850	2023-12-01	1198502023	2	99	9802023	99	99	99.0	99	10.4	2002023	99.0	9802023	Mo-Sa
119860	2023-12-01	1198602023	0	99	9802023	99	99	99.0	99	99.0	99	99.0	9802023	Mo-Fr
180870	2023-12-01	1808702023	1	78455	1502023	99	99	3.3	2002023	34.8	2002023	3.3	1502023	Mo-So
181870	2023-12-01	1818702023	1	6855	1502023	99	99	99.0	9802023	99.0	9802023	0.3	1502023	Mo-Fr
182870	2023-12-01	1828702023	0	99	99	99	99	3.5	2002023	37.0	2002023	99.0	99	TT: Mo-So, TT Kompakt: Mo-Fr
190990	2023-12-01	1909902023	1	51580	1502023	99	99	2.0	2002023	40.7	2002023	2.2	1502023	Mo-Sa
192990	2023-12-01	1929902023	0	99	99	99	99	2.3	2002023	44.6	2002023	99.0	99	VN: Mo-Sa, NEUE: Di-So
300011	1991-12-01	3000111991	1	99	99	99	99	69.0	1702023	99.0	99	99.0	99	KA
300011	1992-12-01	3000111992	1	99	99	99	99	65.1	1702023	99.0	99	99.0	99	KA
300011	1993-12-01	3000111993	1	99	99	99	99	63.8	1702023	99.0	99	66.0	1102008	KA
300011	1994-12-01	3000111994	1	99	99	99	99	62.3	1702023	99.0	99	62.0	1102008	KA
300011	1995-12-01	3000111995	1	99	99	99	99	61.9	1702023	99.0	99	63.0	1102008	KA
300011	1996-12-01	3000111996	1	99	99	99	99	60.9	1702023	99.0	99	62.0	1102008	KA
300011	1997-12-01	3000111997	1	99	99	99	99	60.3	1702023	99.0	99	62.0	1102008	KA
300011	1998-12-01	3000111998	1	99	99	99	99	60.8	1702023	99.0	99	61.0	1102008	KA
300011	1999-12-01	3000111999	1	99	99	99	99	59.9	1702023	99.0	99	58.0	1102008	KA
300011	2000-12-01	3000112000	1	99	99	99	99	59.8	1702023	99.0	99	56.0	1102003	KA
300011	2001-12-01	3000112001	1	99	99	99	99	60.0	1102004	99.0	99	55.0	1102011	KA
300011	2002-12-01	3000112002	1	99	99	99	99	61.9	1102004	99.0	99	54.0	1102011	KA
300011	2003-12-01	3000112003	1	99	99	99	99	60.3	1102004	99.0	99	51.7	1102011	KA
300011	2004-12-01	3000112004	1	99	99	99	99	60.6	1102004	99.0	99	51.3	1102011	KA
300011	2005-12-01	3000112005	1	99	99	99	99	59.1	1202005	99.0	99	48.2	1102021	KA
300011	2006-12-01	3000112006	1	99	99	99	99	57.3	1102016	99.0	99	47.6	1102016	KA
300011	2007-12-01	3000112007	1	99	99	99	99	52.9	1202007	99.0	99	43.1	1102018	KA
300011	2008-12-01	3000112008	1	99	99	99	99	51.8	1202008	99.0	99	41.9	1102019	KA
300011	2009-12-01	3000112009	1	99	99	99	99	49.8	1102019	99.0	99	39.1	1102019	KA
300011	2010-12-01	3000112010	1	99	99	99	99	50.7	1102021	99.0	99	37.8	1102021	KA
300011	2011-12-01	3000112011	1	99	99	99	99	50.9	1102021	99.0	99	36.4	1102021	KA
300011	2012-12-01	3000112012	1	99	99	99	99	51.0	1102021	99.0	99	36.0	1102021	KA
300011	2013-12-01	3000112013	1	99	99	99	99	48.5	1102021	99.0	99	35.4	1102021	KA
300011	2014-12-01	3000112014	1	99	99	99	99	49.0	1102021	99.0	99	35.1	1102021	KA
300011	2015-12-01	3000112015	1	99	99	99	99	48.2	1102021	99.0	99	35.3	1102021	KA
300011	2016-12-01	3000112016	1	99	99	99	99	48.1	1102021	99.0	99	35.1	1102021	KA
300011	2017-12-01	3000112017	1	99	99	99	99	48.6	1102021	99.0	99	33.9	1102021	KA
300011	2018-12-01	3000112018	1	99	99	99	99	48.1	1102021	99.0	99	32.9	1102021	KA
300011	2019-12-01	3000112019	1	99	99	99	99	48.1	1102021	99.0	99	31.8	1102021	KA
300011	2020-12-01	3000112020	1	99	99	99	99	52.4	1102021	99.0	99	33.2	1102021	KA
300011	2021-12-01	3000112021	1	99	99	99	99	51.9	1102021	99.0	99	35.5	1102021	KA
300011	2022-12-01	3000112022	1	99	99	99	99	48.8	1702022	99.0	99	34.6	1702022	KA
300011	2023-12-01	3000112023	1	99	99	99	99	46.0	1702023	99.0	99	33.8	1702023	KA
300012	1991-12-01	3000121991	0	99	99	99	99	61.7	1702023	99.0	99	99.0	99	KA
300013	1992-12-01	3000131992	0	99	99	99	99	56.4	1702023	99.0	99	99.0	99	KA
300013	1993-12-01	3000131993	0	99	99	99	99	55.0	1702023	99.0	99	36.0	1102008	KA
300013	1994-12-01	3000131994	0	99	99	99	99	52.7	1702023	99.0	99	32.0	1102008	KA
300013	1995-12-01	3000131995	0	99	99	99	99	48.0	1702023	99.0	99	27.0	1102008	KA
300013	1996-12-01	3000131996	0	99	99	99	99	45.5	1702023	99.0	99	25.0	1102008	KA
300013	1997-12-01	3000131997	0	99	99	99	99	43.8	1702023	99.0	99	24.0	1102008	KA
300013	1998-12-01	3000131998	0	99	99	99	99	42.9	1702023	99.0	99	26.0	1102008	KA
300013	1999-12-01	3000131999	0	99	99	99	99	44.1	1702023	99.0	99	24.0	1102008	KA
300013	2000-12-01	3000132000	0	99	99	99	99	43.3	1702023	99.0	99	24.0	1102003	KA
300013	2001-12-01	3000132001	0	99	99	99	99	42.9	1102004	99.0	99	23.0	1102011	KA
300013	2002-12-01	3000132002	0	99	99	99	99	44.1	1102004	99.0	99	22.0	1102011	KA
300013	2003-12-01	3000132003	0	99	99	99	99	43.3	1102004	99.0	99	22.0	1102011	KA
300013	2005-12-01	3000132005	0	99	99	99	99	41.6	1202005	99.0	99	20.0	1102021	KA
300013	2006-12-01	3000132006	0	99	99	99	99	39.7	1102016	99.0	99	20.0	1102016	KA
300013	2007-12-01	3000132007	0	99	99	99	99	34.7	1202007	99.0	99	18.0	1102018	KA
300013	2008-12-01	3000132008	0	99	99	99	99	32.6	1202008	99.0	99	17.0	1102019	KA
300013	2009-12-01	3000132009	0	99	99	99	99	30.4	1102019	99.0	99	15.0	1102019	KA
300013	2010-12-01	3000132010	0	99	99	99	99	31.3	1102021	99.0	99	15.0	1102021	KA
300013	2011-12-01	3000132011	0	99	99	99	99	31.0	1102021	99.0	99	14.0	1102021	KA
300013	2012-12-01	3000132012	0	99	99	99	99	30.9	1102021	99.0	99	14.0	1102021	KA
300013	2013-12-01	3000132013	0	99	99	99	99	28.0	1102021	99.0	99	12.0	1102021	KA
300013	2014-12-01	3000132014	0	99	99	99	99	29.1	1102021	99.0	99	13.0	1102021	KA
300013	2015-12-01	3000132015	0	99	99	99	99	27.6	1102021	99.0	99	12.0	1102021	KA
300013	2016-12-01	3000132016	0	99	99	99	99	27.4	1102021	99.0	99	12.0	1102021	KA
300013	2017-12-01	3000132017	0	99	99	99	99	27.2	1102021	99.0	99	10.8	1102021	KA
300013	2018-12-01	3000132018	0	99	99	99	99	27.4	1102021	99.0	99	10.9	1102021	KA
300013	2019-12-01	3000132019	0	99	99	99	99	25.4	1102021	99.0	99	9.1	1102021	KA
300013	2020-12-01	3000132020	0	99	99	99	99	26.1	1102021	99.0	99	8.2	1102021	KA
300013	2021-12-01	3000132021	0	99	99	99	99	27.2	1102021	99.0	99	10.2	1102021	KA
300013	2022-12-01	3000132022	0	99	99	99	99	24.8	1702022	99.0	99	9.8	1702022	KA
300013	2023-12-01	3000132023	0	99	99	99	99	23.3	1702023	99.0	99	9.5	1702023	KA
300021	1991-12-01	3000211991	0	99	99	99	99	54.8	1702023	99.0	99	99.0	99	KA
300022	1992-12-01	3000221992	0	99	99	99	99	50.8	1702023	99.0	99	99.0	99	KA
300022	1993-12-01	3000221993	0	99	99	99	99	50.6	1702023	99.0	99	30.0	1102008	KA
300022	1994-12-01	3000221994	0	99	99	99	99	50.3	1702023	99.0	99	31.0	1102008	KA
300022	1995-12-01	3000221995	0	99	99	99	99	51.3	1702023	99.0	99	36.0	1102008	KA
300022	1996-12-01	3000221996	0	99	99	99	99	49.2	1702023	99.0	99	36.0	1102008	KA
300022	1997-12-01	3000221997	0	99	99	99	99	48.7	1702023	99.0	99	37.0	1102008	KA
300022	1998-12-01	3000221998	0	99	99	99	99	48.4	1702023	99.0	99	36.0	1102008	KA
300022	1999-12-01	3000221999	0	99	99	99	99	47.5	1702023	99.0	99	34.0	1102008	KA
300022	2000-12-01	3000222000	0	99	99	99	99	47.0	1702023	99.0	99	33.0	1102003	KA
300022	2001-12-01	3000222001	0	99	99	99	99	46.7	1702023	99.0	99	32.0	1102011	KA
300022	2002-12-01	3000222002	0	99	99	99	99	48.4	1702023	99.0	99	32.0	1102011	KA
300022	2003-12-01	3000222003	0	99	99	99	99	46.7	1702023	99.0	99	30.0	1102011	KA
300022	2004-12-01	3000222004	0	99	99	99	99	46.5	1702023	99.0	99	30.0	1102011	KA
300022	2005-12-01	3000222005	0	99	99	99	99	45.1	1702023	99.0	99	28.0	1102021	KA
300022	2006-12-01	3000222006	0	99	99	99	99	43.3	1702023	99.0	99	27.0	1102016	KA
300022	2007-12-01	3000222007	0	99	99	99	99	40.1	1702023	99.0	99	26.0	1102018	KA
300022	2008-12-01	3000222008	0	99	99	99	99	39.7	1702023	99.0	99	25.0	1102019	KA
300022	2009-12-01	3000222009	0	99	99	99	99	38.4	1702023	99.0	99	24.0	1102019	KA
300022	2010-12-01	3000222010	0	99	99	99	99	38.8	1102021	99.0	99	23.0	1102021	KA
300022	2011-12-01	3000222011	0	99	99	99	99	39.1	1102021	99.0	99	23.0	1102021	KA
300022	2012-12-01	3000222012	0	99	99	99	99	39.0	1102021	99.0	99	22.0	1102021	KA
300022	2013-12-01	3000222013	0	99	99	99	99	38.0	1102021	99.0	99	22.0	1102021	KA
300022	2014-12-01	3000222014	0	99	99	99	99	37.5	1102021	99.0	99	20.0	1102021	KA
300022	2015-12-01	3000222015	0	99	99	99	99	37.6	1102021	99.0	99	21.0	1102021	KA
300022	2016-12-01	3000222016	0	99	99	99	99	37.9	1102021	99.0	99	21.0	1102021	KA
300022	2017-12-01	3000222017	0	99	99	99	99	38.7	1102021	99.0	99	20.6	1102021	KA
300022	2018-12-01	3000222018	0	99	99	99	99	37.8	1102021	99.0	99	19.3	1102021	KA
300022	2019-12-01	3000222019	0	99	99	99	99	39.1	1102021	99.0	99	19.8	1102021	KA
300022	2020-12-01	3000222020	0	99	99	99	99	43.7	1102021	99.0	99	22.0	1102021	KA
300022	2021-12-01	3000222021	0	99	99	99	99	43.1	1102021	99.0	99	22.1	1102021	KA
300022	2022-12-01	3000222022	0	99	99	99	99	40.2	1702022	99.0	99	21.4	1702022	KA
300022	2023-12-01	3000222023	0	99	99	99	99	37.6	1702023	99.0	99	21.0	1702023	KA
300030	1997-12-01	3000301997	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	1998-12-01	3000301998	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	1999-12-01	3000301999	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2000-12-01	3000302000	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2001-12-01	3000302001	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2002-12-01	3000302002	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2003-12-01	3000302003	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2004-12-01	3000302004	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2005-12-01	3000302005	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2006-12-01	3000302006	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2007-12-01	3000302007	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2008-12-01	3000302008	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2009-12-01	3000302009	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300030	2010-12-01	3000302010	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300040	2006-12-01	3000402006	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300040	2011-12-01	3000402011	0	99	99	99	99	99.0	99	99.0	99	0.0	1102021	KA
300040	2012-12-01	3000402012	0	99	99	99	99	4.9	1702012	99.0	99	99.0	99	KA
300040	2013-12-01	3000402013	0	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300040	2014-12-01	3000402014	0	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300040	2015-12-01	3000402015	0	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300040	2016-12-01	3000402016	0	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300040	2017-12-01	3000402017	0	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300040	2018-12-01	3000402018	0	99	99	99	99	99.0	99	99.0	99	2.2	1102021	KA
300040	2019-12-01	3000402019	0	99	99	99	99	99.0	99	99.0	99	2.3	1102021	KA
300040	2020-12-01	3000402020	0	99	99	99	99	99.0	99	99.0	99	2.3	1702020	KA
300040	2021-12-01	3000402021	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300040	2022-12-01	3000402022	0	99	99	99	99	99.0	99	99.0	99	2.9	1702022	KA
300049	2006-12-01	3000492006	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300050	2007-12-01	3000502007	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300050	2008-12-01	3000502008	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300050	2009-12-01	3000502009	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300050	2010-12-01	3000502010	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300050	2011-12-01	3000502011	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300050	2012-12-01	3000502012	0	99	99	99	99	1.7	1702012	99.0	99	0.3	1702012	KA
300050	2013-12-01	3000502013	0	99	99	99	99	99.0	99	99.0	99	0.4	1702013	KA
300050	2014-12-01	3000502014	0	99	99	99	99	99.0	99	99.0	99	0.4	1702014	KA
300050	2015-12-01	3000502015	0	99	99	99	99	99.0	99	99.0	99	0.5	1702015	KA
300050	2016-12-01	3000502016	0	99	99	99	99	99.0	99	99.0	99	0.6	1702016	KA
300050	2017-12-01	3000502017	0	99	99	99	99	99.0	99	99.0	99	0.4	1702017	KA
300050	2018-12-01	3000502018	0	99	99	99	99	99.0	99	99.0	99	0.5	1702018	KA
300050	2019-12-01	3000502019	0	99	99	99	99	99.0	99	99.0	99	0.6	1702019	KA
300050	2020-12-01	3000502020	0	99	99	99	99	99.0	99	99.0	99	0.7	1702020	KA
300050	2021-12-01	3000502021	0	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300050	2022-12-01	3000502022	0	99	99	99	99	99.0	99	99.0	99	0.5	1702022	KA
300060	1991-12-01	3000601991	0	99	99	99	99	0.9	1601993	99.0	99	99.0	99	KA
300060	1992-12-01	3000601992	0	99	99	99	99	1.0	1601993	99.0	99	99.0	99	KA
300060	1993-12-01	3000601993	0	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300060	1994-12-01	3000601994	0	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300060	1995-12-01	3000601995	0	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300060	1996-12-01	3000601996	0	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300060	1997-12-01	3000601997	0	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300060	1998-12-01	3000601998	0	99	99	99	99	0.8	1201998	99.0	99	1.0	1102008	KA
300060	1999-12-01	3000601999	0	99	99	99	99	1.0	1201999	99.0	99	1.0	1102008	KA
300060	2000-12-01	3000602000	0	99	99	99	99	1.1	1202000	99.0	99	1.0	1102021	KA
300060	2001-12-01	3000602001	0	99	99	99	99	99.0	99	99.0	99	1.0	1102011	KA
300060	2002-12-01	3000602002	0	99	99	99	99	99.0	99	99.0	99	1.0	1102011	KA
300060	2003-12-01	3000602003	0	99	99	99	99	99.0	99	99.0	99	1.0	1102011	KA
300060	2004-12-01	3000602004	0	99	99	99	99	99.0	99	99.0	99	1.0	1102011	KA
300060	2005-12-01	3000602005	0	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300060	2006-12-01	3000602006	0	99	99	99	99	99.0	99	99.0	99	1.0	1102016	KA
300060	2007-12-01	3000602007	0	99	99	99	99	99.0	99	99.0	99	2.0	1102018	KA
300060	2008-12-01	3000602008	0	99	99	99	99	99.0	99	99.0	99	2.0	1102019	KA
300060	2009-12-01	3000602009	0	99	99	99	99	99.0	99	99.0	99	2.0	1102019	KA
300060	2010-12-01	3000602010	0	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300060	2011-12-01	3000602011	0	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300060	2012-12-01	3000602012	0	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300060	2013-12-01	3000602013	0	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300060	2014-12-01	3000602014	0	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300060	2015-12-01	3000602015	0	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300060	2016-12-01	3000602016	0	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300060	2017-12-01	3000602017	0	99	99	99	99	99.0	99	99.0	99	1.7	1102021	KA
300060	2018-12-01	3000602018	0	99	99	99	99	99.0	99	99.0	99	1.6	1102021	KA
300060	2019-12-01	3000602019	0	99	99	99	99	99.0	99	99.0	99	1.5	1102021	KA
300060	2020-12-01	3000602020	0	99	99	99	99	99.0	99	99.0	99	1.5	1102021	KA
300060	2021-12-01	3000602021	0	99	99	99	99	99.0	99	99.0	99	1.4	1102021	KA
300060	2022-12-01	3000602022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300060	2023-12-01	3000602023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300070	1997-12-01	3000701997	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300070	1998-12-01	3000701998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300070	1999-12-01	3000701999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300070	2000-12-01	3000702000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2004-12-01	3000802004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2005-12-01	3000802005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2006-12-01	3000802006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2007-12-01	3000802007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2008-12-01	3000802008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2009-12-01	3000802009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2010-12-01	3000802010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2011-12-01	3000802011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2012-12-01	3000802012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2013-12-01	3000802013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2014-12-01	3000802014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2015-12-01	3000802015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2016-12-01	3000802016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2017-12-01	3000802017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2018-12-01	3000802018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2019-12-01	3000802019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2020-12-01	3000802020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2021-12-01	3000802021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2022-12-01	3000802022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300080	2023-12-01	3000802023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2005-12-01	3001002005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2006-12-01	3001002006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2007-12-01	3001002007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2008-12-01	3001002008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2009-12-01	3001002009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2010-12-01	3001002010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2011-12-01	3001002011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2012-12-01	3001002012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2013-12-01	3001002013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2014-12-01	3001002014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2015-12-01	3001002015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2016-12-01	3001002016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2017-12-01	3001002017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2018-12-01	3001002018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2019-12-01	3001002019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2020-12-01	3001002020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2021-12-01	3001002021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2022-12-01	3001002022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300100	2023-12-01	3001002023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2010-12-01	3001102010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2011-12-01	3001102011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2012-12-01	3001102012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2013-12-01	3001102013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2014-12-01	3001102014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2015-12-01	3001102015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2016-12-01	3001102016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2017-12-01	3001102017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2018-12-01	3001102018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2019-12-01	3001102019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2020-12-01	3001102020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2021-12-01	3001102021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2022-12-01	3001102022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300110	2023-12-01	3001102023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2012-12-01	3001202012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2013-12-01	3001202013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2014-12-01	3001202014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2015-12-01	3001202015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2016-12-01	3001202016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2017-12-01	3001202017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2018-12-01	3001202018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2019-12-01	3001202019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2020-12-01	3001202020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2021-12-01	3001202021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2022-12-01	3001202022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300120	2023-12-01	3001202023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	1995-12-01	3002001995	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	1996-12-01	3002001996	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	1997-12-01	3002001997	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	1998-12-01	3002001998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	1999-12-01	3002001999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	2000-12-01	3002002000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	2001-12-01	3002002001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	2002-12-01	3002002002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	2003-12-01	3002002003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	2004-12-01	3002002004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	2006-12-01	3002002006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	2007-12-01	3002002007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300200	2008-12-01	3002002008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300210	2009-12-01	3002102009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300210	2010-12-01	3002102010	1	99	99	99	99	99.0	99	99.0	99	0.0	1102021	KA
300210	2011-12-01	3002102011	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300210	2012-12-01	3002102012	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300210	2013-12-01	3002102013	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300210	2014-12-01	3002102014	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300210	2015-12-01	3002102015	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300210	2016-12-01	3002102016	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300210	2017-12-01	3002102017	1	99	99	99	99	99.0	99	99.0	99	2.1	1102021	KA
300210	2018-12-01	3002102018	1	99	99	99	99	99.0	99	99.0	99	2.4	1102021	KA
300210	2019-12-01	3002102019	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300210	2020-12-01	3002102020	1	99	99	99	99	99.0	99	99.0	99	3.4	1102021	KA
300210	2021-12-01	3002102021	1	99	99	99	99	99.0	99	99.0	99	3.7	1102021	KA
300210	2022-12-01	3002102022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300210	2023-12-01	3002102023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300220	1997-12-01	3002201997	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300220	1998-12-01	3002201998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300220	1999-12-01	3002201999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300231	2000-12-01	3002312000	1	99	99	99	99	99.0	99	99.0	99	0.0	1102011	KA
300231	2001-12-01	3002312001	1	99	99	99	99	99.0	99	99.0	99	1.0	1102011	KA
300231	2002-12-01	3002312002	1	99	99	99	99	99.0	99	99.0	99	0.0	1102011	KA
300232	2003-12-01	3002322003	1	99	99	99	99	99.0	99	99.0	99	1.0	1102011	KA
300232	2004-12-01	3002322004	1	99	99	99	99	9.3	1102004	99.0	99	2.0	1102011	KA
300232	2005-12-01	3002322005	1	99	99	99	99	10.5	1102006	99.0	99	2.0	1102021	KA
300233	2006-12-01	3002332006	1	99	99	99	99	11.6	1202006	99.0	99	3.0	1102016	KA
300233	2007-12-01	3002332007	1	99	99	99	99	12.3	1102008	99.0	99	3.0	1102018	KA
300233	2008-12-01	3002332008	1	99	99	99	99	13.5	1102008	99.0	99	3.0	1102019	KA
300233	2009-12-01	3002332009	1	99	99	99	99	14.7	1102010	99.0	99	4.0	1102019	KA
300233	2010-12-01	3002332010	1	99	99	99	99	15.0	1102010	99.0	99	4.0	1102021	KA
300233	2011-12-01	3002332011	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300233	2012-12-01	3002332012	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300233	2013-12-01	3002332013	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300233	2014-12-01	3002332014	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300233	2015-12-01	3002332015	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300233	2016-12-01	3002332016	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300233	2017-12-01	3002332017	1	99	99	99	99	99.0	99	99.0	99	3.3	1102021	KA
300233	2018-12-01	3002332018	1	99	99	99	99	99.0	99	99.0	99	3.3	1102021	KA
300233	2019-12-01	3002332019	1	99	99	99	99	99.0	99	99.0	99	3.5	1102021	KA
300233	2020-12-01	3002332020	1	99	99	99	99	99.0	99	99.0	99	3.2	1102021	KA
300233	2022-12-01	3002332022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300233	2023-12-01	3002332023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2022-12-01	3002402022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2023-12-01	3002402023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300233	2021-12-01	3002332021	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300240	2011-12-01	3002402011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2012-12-01	3002402012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2013-12-01	3002402013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2014-12-01	3002402014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2015-12-01	3002402015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2016-12-01	3002402016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2017-12-01	3002402017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2018-12-01	3002402018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2019-12-01	3002402019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2020-12-01	3002402020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300240	2021-12-01	3002402021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300251	2004-12-01	3002512004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300251	2005-12-01	3002512005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300251	2006-12-01	3002512006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300251	2007-12-01	3002512007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300252	2008-12-01	3002522008	1	99	99	99	99	99.0	99	99.0	99	1.0	1102019	KA
300252	2009-12-01	3002522009	1	99	99	99	99	99.0	99	99.0	99	2.0	1102019	KA
300252	2010-12-01	3002522010	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300252	2011-12-01	3002522011	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300252	2012-12-01	3002522012	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300252	2013-12-01	3002522013	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300252	2014-12-01	3002522014	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300252	2015-12-01	3002522015	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300252	2016-12-01	3002522016	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300252	2017-12-01	3002522017	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300252	2018-12-01	3002522018	1	99	99	99	99	99.0	99	99.0	99	3.3	1102021	KA
300252	2019-12-01	3002522019	1	99	99	99	99	99.0	99	99.0	99	3.4	1102021	KA
300252	2020-12-01	3002522020	1	99	99	99	99	99.0	99	99.0	99	3.3	1102021	KA
300252	2021-12-01	3002522021	1	99	99	99	99	99.0	99	99.0	99	3.1	1102021	KA
300252	2022-12-01	3002522022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300252	2023-12-01	3002522023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300260	2019-12-01	3002602019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300260	2020-12-01	3002602020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300260	2021-12-01	3002602021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300260	2022-12-01	3002602022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300260	2023-12-01	3002602023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300270	1993-12-01	3002701993	1	99	99	99	99	7.3	1201993	99.0	99	5.0	1102008	KA
300270	1994-12-01	3002701994	1	99	99	99	99	8.5	1201994	99.0	99	6.0	1102008	KA
300270	1995-12-01	3002701995	1	99	99	99	99	8.5	1201995	99.0	99	5.0	1102008	KA
300270	1996-12-01	3002701996	1	99	99	99	99	8.7	1201996	99.0	99	5.0	1102008	KA
300270	1997-12-01	3002701997	1	99	99	99	99	9.0	1201997	99.0	99	6.0	1102008	KA
300271	1998-12-01	3002711998	1	99	99	99	99	8.5	1201998	99.0	99	6.0	1102008	KA
300271	1999-12-01	3002711999	1	99	99	99	99	8.7	1201999	99.0	99	5.0	1102008	KA
300271	2000-12-01	3002712000	1	99	99	99	99	8.3	1202000	99.0	99	5.0	1102021	KA
300271	2001-12-01	3002712001	1	99	99	99	99	3.6	1202001	99.0	99	5.0	1102011	KA
300271	2002-12-01	3002712002	1	99	99	99	99	8.1	1202002	99.0	99	5.0	1102011	KA
300271	2003-12-01	3002712003	1	99	99	99	99	8.4	1202003	99.0	99	5.0	1102011	KA
300271	2004-12-01	3002712004	1	99	99	99	99	8.8	1202004	99.0	99	5.0	1102011	KA
300271	2005-12-01	3002712005	1	99	99	99	99	8.4	1202005	99.0	99	4.0	1102021	KA
300271	2006-12-01	3002712006	1	99	99	99	99	8.7	1202006	99.0	99	4.0	1102016	KA
300271	2007-12-01	3002712007	1	99	99	99	99	10.2	1202007	99.0	99	5.0	1102018	KA
300271	2008-12-01	3002712008	1	99	99	99	99	11.7	1202008	99.0	99	5.0	1102019	KA
300271	2009-12-01	3002712009	1	99	99	99	99	14.7	1102010	99.0	99	5.0	1102019	KA
300271	2010-12-01	3002712010	1	99	99	99	99	15.0	1102010	99.0	99	5.0	1102021	KA
300271	2011-12-01	3002712011	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300271	2012-12-01	3002712012	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300271	2013-12-01	3002712013	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300271	2014-12-01	3002712014	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300271	2015-12-01	3002712015	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300271	2016-12-01	3002712016	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300271	2017-12-01	3002712017	1	99	99	99	99	99.0	99	99.0	99	4.1	1102021	KA
300271	2018-12-01	3002712018	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300271	2019-12-01	3002712019	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300271	2020-12-01	3002712020	1	99	99	99	99	99.0	99	99.0	99	3.2	1102021	KA
300271	2021-12-01	3002712021	1	99	99	99	99	99.0	99	99.0	99	2.7	1102021	KA
300280	1993-12-01	3002801993	1	99	99	99	99	7.7	1201993	99.0	99	6.0	1102008	KA
300280	1994-12-01	3002801994	1	99	99	99	99	8.6	1201994	99.0	99	6.0	1102008	KA
300280	1995-12-01	3002801995	1	99	99	99	99	8.4	1201995	99.0	99	6.0	1102008	KA
300280	1996-12-01	3002801996	1	99	99	99	99	7.3	1201996	99.0	99	5.0	1102008	KA
300280	1997-12-01	3002801997	1	99	99	99	99	6.8	1201997	99.0	99	5.0	1102008	KA
300280	1998-12-01	3002801998	1	99	99	99	99	6.4	1201998	99.0	99	5.0	1102008	KA
300280	1999-12-01	3002801999	1	99	99	99	99	6.1	1201999	99.0	99	5.0	1102008	KA
300281	2000-12-01	3002812000	1	99	99	99	99	6.4	1202000	99.0	99	5.0	1102021	KA
300281	2001-12-01	3002812001	1	99	99	99	99	4.3	1202001	99.0	99	5.0	1102011	KA
300281	2002-12-01	3002812002	1	99	99	99	99	8.7	1202002	99.0	99	5.0	1102011	KA
300281	2003-12-01	3002812003	1	99	99	99	99	9.1	1202003	99.0	99	5.0	1102011	KA
300281	2004-12-01	3002812004	1	99	99	99	99	9.3	1202004	99.0	99	6.0	1102011	KA
300281	2005-12-01	3002812005	1	99	99	99	99	9.2	1202005	99.0	99	6.0	1102021	KA
300281	2006-12-01	3002812006	1	99	99	99	99	9.4	1202006	99.0	99	6.0	1102016	KA
300281	2007-12-01	3002812007	1	99	99	99	99	10.9	1202007	99.0	99	7.0	1102018	KA
300281	2008-12-01	3002812008	1	99	99	99	99	12.7	1102008	99.0	99	7.0	1102019	KA
300281	2009-12-01	3002812009	1	99	99	99	99	16.0	1102010	99.0	99	7.0	1102019	KA
300281	2010-12-01	3002812010	1	99	99	99	99	15.7	1102010	99.0	99	7.0	1102021	KA
300281	2011-12-01	3002812011	1	99	99	99	99	99.0	99	99.0	99	7.0	1102021	KA
300281	2012-12-01	3002812012	1	99	99	99	99	99.0	99	99.0	99	6.0	1102021	KA
300281	2013-12-01	3002812013	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300281	2014-12-01	3002812014	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300281	2015-12-01	3002812015	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300281	2016-12-01	3002812016	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300281	2017-12-01	3002812017	1	99	99	99	99	99.0	99	99.0	99	3.9	1102021	KA
300281	2018-12-01	3002812018	1	99	99	99	99	99.0	99	99.0	99	3.6	1102021	KA
300281	2019-12-01	3002812019	1	99	99	99	99	99.0	99	99.0	99	3.3	1102021	KA
300281	2020-12-01	3002812020	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300281	2021-12-01	3002812021	1	99	99	99	99	99.0	99	99.0	99	2.7	1102021	KA
300290	1993-12-01	3002901993	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300290	1994-12-01	3002901994	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300290	1995-12-01	3002901995	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300290	1996-12-01	3002901996	1	99	99	99	99	99.0	99	99.0	99	2.0	1102008	KA
300290	1997-12-01	3002901997	1	99	99	99	99	99.0	99	99.0	99	2.0	1102008	KA
300290	1998-12-01	3002901998	1	99	99	99	99	2.0	1201998	99.0	99	2.0	1102008	KA
300291	1999-12-01	3002911999	1	99	99	99	99	2.5	1201999	99.0	99	3.0	1102008	KA
300291	2000-12-01	3002912000	1	99	99	99	99	2.6	1202000	99.0	99	4.0	1102021	KA
300291	2001-12-01	3002912001	1	99	99	99	99	2.6	1202001	99.0	99	4.0	1102011	KA
300291	2002-12-01	3002912002	1	99	99	99	99	99.0	99	99.0	99	3.0	1102011	KA
300291	2003-12-01	3002912003	1	99	99	99	99	99.0	99	99.0	99	3.0	1102011	KA
300291	2004-12-01	3002912004	1	99	99	99	99	99.0	99	99.0	99	3.0	1102011	KA
300291	2005-12-01	3002912005	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300291	2006-12-01	3002912006	1	99	99	99	99	99.0	99	99.0	99	2.0	1102016	KA
300291	2007-12-01	3002912007	1	99	99	99	99	6.9	1202007	99.0	99	3.0	1102018	KA
300291	2008-12-01	3002912008	1	99	99	99	99	7.8	1202008	99.0	99	3.0	1102019	KA
300291	2009-12-01	3002912009	1	99	99	99	99	10.2	1102010	99.0	99	3.0	1102019	KA
300291	2010-12-01	3002912010	1	99	99	99	99	10.5	1102010	99.0	99	3.0	1102021	KA
300291	2011-12-01	3002912011	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300291	2012-12-01	3002912012	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300291	2013-12-01	3002912013	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300291	2014-12-01	3002912014	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300291	2015-12-01	3002912015	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300291	2016-12-01	3002912016	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300291	2017-12-01	3002912017	1	99	99	99	99	99.0	99	99.0	99	2.5	1102021	KA
300291	2018-12-01	3002912018	1	99	99	99	99	99.0	99	99.0	99	2.3	1102021	KA
300291	2019-12-01	3002912019	1	99	99	99	99	99.0	99	99.0	99	2.3	1102021	KA
300291	2020-12-01	3002912020	1	99	99	99	99	99.0	99	99.0	99	2.2	1102021	KA
300291	2021-12-01	3002912021	1	99	99	99	99	99.0	99	99.0	99	1.8	1102021	KA
300271	2022-12-01	3002712022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300271	2023-12-01	3002712023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300281	2022-12-01	3002812022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300281	2023-12-01	3002812023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300291	2022-12-01	3002912022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300291	2023-12-01	3002912023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300300	2016-12-01	3003002016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300300	2017-12-01	3003002017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300300	2018-12-01	3003002018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300300	2019-12-01	3003002019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300300	2020-12-01	3003002020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300300	2021-12-01	3003002021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300300	2022-12-01	3003002022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300300	2023-12-01	3003002023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300310	2007-12-01	3003102007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300310	2008-12-01	3003102008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300310	2009-12-01	3003102009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300310	2010-12-01	3003102010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300310	2011-12-01	3003102011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300320	2012-12-01	3003202012	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300320	2013-12-01	3003202013	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300320	2014-12-01	3003202014	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300320	2015-12-01	3003202015	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300320	2016-12-01	3003202016	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300320	2017-12-01	3003202017	1	99	99	99	99	99.0	99	99.0	99	1.1	1102021	KA
300320	2018-12-01	3003202018	1	99	99	99	99	99.0	99	99.0	99	1.1	1102021	KA
300320	2019-12-01	3003202019	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300320	2020-12-01	3003202020	1	99	99	99	99	99.0	99	99.0	99	0.9	1102021	KA
300320	2021-12-01	3003202021	1	99	99	99	99	99.0	99	99.0	99	0.8	1102021	KA
300320	2022-12-01	3003202022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300320	2023-12-01	3003202023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300330	2016-12-01	3003302016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300330	2017-12-01	3003302017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300330	2018-12-01	3003302018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300330	2019-12-01	3003302019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300330	2020-12-01	3003302020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300330	2021-12-01	3003302021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300330	2022-12-01	3003302022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300330	2023-12-01	3003302023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300340	2016-12-01	3003402016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300340	2017-12-01	3003402017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300340	2018-12-01	3003402018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300340	2019-12-01	3003402019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300340	2020-12-01	3003402020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300340	2021-12-01	3003402021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300340	2022-12-01	3003402022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300340	2023-12-01	3003402023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300350	1993-12-01	3003501993	1	99	99	99	99	11.2	1201993	99.0	99	8.0	1102008	KA
300350	1994-12-01	3003501994	1	99	99	99	99	12.2	1201994	99.0	99	8.0	1102008	KA
300350	1995-12-01	3003501995	1	99	99	99	99	11.3	1201995	99.0	99	7.0	1102008	KA
300350	1996-12-01	3003501996	1	99	99	99	99	10.9	1201996	99.0	99	6.0	1102008	KA
300350	1997-12-01	3003501997	1	99	99	99	99	10.2	1201997	99.0	99	6.0	1102008	KA
300350	1998-12-01	3003501998	1	99	99	99	99	10.0	1201998	99.0	99	6.0	1102008	KA
300350	1999-12-01	3003501999	1	99	99	99	99	10.3	1201999	99.0	99	6.0	1102008	KA
300350	2000-12-01	3003502000	1	99	99	99	99	9.9	1202000	99.0	99	6.0	1102021	KA
300350	2001-12-01	3003502001	1	99	99	99	99	4.3	1202001	99.0	99	6.0	1102011	KA
300350	2002-12-01	3003502002	1	99	99	99	99	8.8	1202002	99.0	99	6.0	1102011	KA
300350	2003-12-01	3003502003	1	99	99	99	99	9.0	1202003	99.0	99	6.0	1102011	KA
300350	2004-12-01	3003502004	1	99	99	99	99	9.0	1202004	99.0	99	6.0	1102011	KA
300350	2005-12-01	3003502005	1	99	99	99	99	9.0	1202005	99.0	99	6.0	1102021	KA
300350	2006-12-01	3003502006	1	99	99	99	99	9.2	1202006	99.0	99	6.0	1102016	KA
300350	2007-12-01	3003502007	1	99	99	99	99	10.4	1202007	99.0	99	6.0	1102018	KA
300350	2008-12-01	3003502008	1	99	99	99	99	10.8	1202008	99.0	99	6.0	1102019	KA
300350	2009-12-01	3003502009	1	99	99	99	99	16.8	1102010	99.0	99	6.0	1102019	KA
300350	2010-12-01	3003502010	1	99	99	99	99	17.3	1102010	99.0	99	6.0	1102021	KA
300350	2011-12-01	3003502011	1	99	99	99	99	99.0	99	99.0	99	7.0	1102021	KA
300350	2012-12-01	3003502012	1	99	99	99	99	99.0	99	99.0	99	6.0	1102021	KA
300350	2013-12-01	3003502013	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300350	2014-12-01	3003502014	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300350	2015-12-01	3003502015	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300350	2016-12-01	3003502016	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300350	2017-12-01	3003502017	1	99	99	99	99	99.0	99	99.0	99	4.7	1102021	KA
300350	2018-12-01	3003502018	1	99	99	99	99	99.0	99	99.0	99	4.1	1102021	KA
300350	2019-12-01	3003502019	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300350	2020-12-01	3003502020	1	99	99	99	99	99.0	99	99.0	99	3.7	1102021	KA
300350	2021-12-01	3003502021	1	99	99	99	99	99.0	99	99.0	99	3.1	1102021	KA
300360	1993-12-01	3003601993	1	99	99	99	99	99.0	99	99.0	99	2.0	1102008	KA
300360	1994-12-01	3003601994	1	99	99	99	99	99.0	99	99.0	99	2.0	1102008	KA
300360	1995-12-01	3003601995	1	99	99	99	99	99.0	99	99.0	99	2.0	1102008	KA
300360	1996-12-01	3003601996	1	99	99	99	99	99.0	99	99.0	99	3.0	1102008	KA
300360	1997-12-01	3003601997	1	99	99	99	99	99.0	99	99.0	99	3.0	1102008	KA
300360	1998-12-01	3003601998	1	99	99	99	99	3.1	1201998	99.0	99	3.0	1102008	KA
300360	1999-12-01	3003601999	1	99	99	99	99	3.8	1201999	99.0	99	3.0	1102008	KA
300360	2000-12-01	3003602000	1	99	99	99	99	4.2	1202000	99.0	99	3.0	1102021	KA
300360	2001-12-01	3003602001	1	99	99	99	99	1.8	1202001	99.0	99	3.0	1102011	KA
300360	2002-12-01	3003602002	1	99	99	99	99	5.3	1202002	99.0	99	3.0	1102011	KA
300360	2003-12-01	3003602003	1	99	99	99	99	5.7	1202003	99.0	99	3.0	1102011	KA
300360	2004-12-01	3003602004	1	99	99	99	99	5.6	1202004	99.0	99	3.0	1102011	KA
300360	2005-12-01	3003602005	1	99	99	99	99	5.3	1202005	99.0	99	3.0	1102021	KA
300360	2006-12-01	3003602006	1	99	99	99	99	5.5	1202006	99.0	99	2.0	1102016	KA
300360	2007-12-01	3003602007	1	99	99	99	99	6.2	1202007	99.0	99	3.0	1102018	KA
300360	2008-12-01	3003602008	1	99	99	99	99	6.4	1202008	99.0	99	3.0	1102019	KA
300360	2009-12-01	3003602009	1	99	99	99	99	9.6	1102010	99.0	99	2.0	1102019	KA
300360	2010-12-01	3003602010	1	99	99	99	99	9.6	1102010	99.0	99	2.0	1102021	KA
300360	2011-12-01	3003602011	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300360	2012-12-01	3003602012	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300360	2013-12-01	3003602013	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300360	2014-12-01	3003602014	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300360	2015-12-01	3003602015	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300360	2016-12-01	3003602016	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300360	2017-12-01	3003602017	1	99	99	99	99	99.0	99	99.0	99	1.8	1102021	KA
300360	2018-12-01	3003602018	1	99	99	99	99	99.0	99	99.0	99	1.8	1102021	KA
300360	2019-12-01	3003602019	1	99	99	99	99	99.0	99	99.0	99	1.9	1102021	KA
300360	2020-12-01	3003602020	1	99	99	99	99	99.0	99	99.0	99	1.8	1102021	KA
300360	2021-12-01	3003602021	1	99	99	99	99	99.0	99	99.0	99	1.8	1102021	KA
300360	2022-12-01	3003602022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300360	2023-12-01	3003602023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300350	2022-12-01	3003502022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300370	2022-12-01	3003702022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300370	2023-12-01	3003702023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300350	2023-12-01	3003502023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300370	1995-12-01	3003701995	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300370	1996-12-01	3003701996	1	99	99	99	99	99.0	99	99.0	99	2.0	1102008	KA
300370	1997-12-01	3003701997	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300370	1998-12-01	3003701998	1	99	99	99	99	1.5	1201998	99.0	99	2.0	1102008	KA
300370	1999-12-01	3003701999	1	99	99	99	99	1.3	1201999	99.0	99	2.0	1102008	KA
300370	2000-12-01	3003702000	1	99	99	99	99	1.2	1202000	99.0	99	2.0	1102021	KA
300370	2001-12-01	3003702001	1	99	99	99	99	99.0	99	99.0	99	2.0	1102011	KA
300370	2002-12-01	3003702002	1	99	99	99	99	99.0	99	99.0	99	1.0	1102011	KA
300370	2003-12-01	3003702003	1	99	99	99	99	99.0	99	99.0	99	2.0	1102011	KA
300370	2004-12-01	3003702004	1	99	99	99	99	99.0	99	99.0	99	1.0	1102011	KA
300370	2005-12-01	3003702005	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300370	2006-12-01	3003702006	1	99	99	99	99	99.0	99	99.0	99	2.0	1102016	KA
300370	2007-12-01	3003702007	1	99	99	99	99	99.0	99	99.0	99	2.0	1102018	KA
300370	2008-12-01	3003702008	1	99	99	99	99	99.0	99	99.0	99	2.0	1102019	KA
300370	2009-12-01	3003702009	1	99	99	99	99	99.0	99	99.0	99	2.0	1102019	KA
300370	2010-12-01	3003702010	1	99	99	99	99	99.0	99	99.0	99	2.0	1102021	KA
300370	2011-12-01	3003702011	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300370	2012-12-01	3003702012	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300370	2013-12-01	3003702013	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300370	2014-12-01	3003702014	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300370	2015-12-01	3003702015	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300370	2016-12-01	3003702016	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300370	2017-12-01	3003702017	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300370	2018-12-01	3003702018	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300370	2019-12-01	3003702019	1	99	99	99	99	99.0	99	99.0	99	1.1	1102021	KA
300370	2020-12-01	3003702020	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300370	2021-12-01	3003702021	1	99	99	99	99	99.0	99	99.0	99	1.0	1102021	KA
300380	2014-12-01	3003802014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300380	2015-12-01	3003802015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300380	2016-12-01	3003802016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300380	2017-12-01	3003802017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300380	2018-12-01	3003802018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300380	2019-12-01	3003802019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300380	2020-12-01	3003802020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300380	2021-12-01	3003802021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300380	2022-12-01	3003802022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300380	2023-12-01	3003802023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300391	2016-12-01	3003912016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300391	2017-12-01	3003912017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300391	2018-12-01	3003912018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300391	2019-12-01	3003912019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300391	2020-12-01	3003912020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300392	2021-12-01	3003922021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300392	2022-12-01	3003922022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300392	2023-12-01	3003922023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300400	1996-12-01	3004001996	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	1997-12-01	3004001997	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	1998-12-01	3004001998	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	1999-12-01	3004001999	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	2000-12-01	3004002000	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	2001-12-01	3004002001	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	2002-12-01	3004002002	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	2003-12-01	3004002003	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	2004-12-01	3004002004	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	2005-12-01	3004002005	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	2006-12-01	3004002006	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300400	2007-12-01	3004002007	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300400	2008-12-01	3004002008	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300400	2009-12-01	3004002009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300400	2010-12-01	3004002010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300400	2011-12-01	3004002011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300400	2012-12-01	3004002012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300400	2013-12-01	3004002013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300400	2014-12-01	3004002014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300400	2015-12-01	3004002015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300400	2016-12-01	3004002016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300400	2018-12-01	3004002018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300400	2017-12-01	3004002017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300401	2019-12-01	3004012019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300401	2020-12-01	3004012020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300401	2021-12-01	3004012021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300401	2022-12-01	3004012022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300401	2023-12-01	3004012023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300410	1993-12-01	3004101993	1	99	99	99	99	99.0	99	99.0	99	99.0	1102008	KA
300410	1994-12-01	3004101994	1	99	99	99	99	99.0	99	99.0	99	99.0	1102008	KA
300410	1995-12-01	3004101995	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300410	1996-12-01	3004101996	1	99	99	99	99	99.0	99	99.0	99	2.0	1102008	KA
300410	1997-12-01	3004101997	1	99	99	99	99	99.0	99	99.0	99	2.0	1102008	KA
300410	1998-12-01	3004101998	1	99	99	99	99	2.1	1201998	99.0	99	2.0	1102008	KA
300410	1999-12-01	3004101999	1	99	99	99	99	2.0	1201999	99.0	99	2.0	1102008	KA
300410	2000-12-01	3004102000	1	99	99	99	99	2.1	1202000	99.0	99	2.0	1102021	KA
300410	2001-12-01	3004102001	1	99	99	99	99	99.0	99	99.0	99	2.0	1102011	KA
300410	2002-12-01	3004102002	1	99	99	99	99	99.0	99	99.0	99	2.0	1102011	KA
300410	2003-12-01	3004102003	1	99	99	99	99	99.0	99	99.0	99	3.0	1102011	KA
300410	2004-12-01	3004102004	1	99	99	99	99	99.0	99	99.0	99	3.0	1102011	KA
300410	2005-12-01	3004102005	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300410	2006-12-01	3004102006	1	99	99	99	99	99.0	99	99.0	99	3.0	1102016	KA
300410	2007-12-01	3004102007	1	99	99	99	99	99.0	99	99.0	99	4.0	1102018	KA
300410	2008-12-01	3004102008	1	99	99	99	99	99.0	99	99.0	99	4.0	1102019	KA
300410	2009-12-01	3004102009	1	99	99	99	99	99.0	99	99.0	99	5.0	1102019	KA
300410	2010-12-01	3004102010	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300410	2011-12-01	3004102011	1	99	99	99	99	99.0	99	99.0	99	5.0	1102021	KA
300410	2012-12-01	3004102012	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300410	2013-12-01	3004102013	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300410	2014-12-01	3004102014	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300410	2015-12-01	3004102015	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300410	2016-12-01	3004102016	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300410	2017-12-01	3004102017	1	99	99	99	99	99.0	99	99.0	99	3.8	1102021	KA
300410	2018-12-01	3004102018	1	99	99	99	99	99.0	99	99.0	99	3.7	1102021	KA
300410	2019-12-01	3004102019	1	99	99	99	99	99.0	99	99.0	99	3.6	1102021	KA
300410	2020-12-01	3004102020	1	99	99	99	99	99.0	99	99.0	99	3.4	1102021	KA
300410	2021-12-01	3004102021	1	99	99	99	99	99.0	99	99.0	99	3.2	1102021	KA
300410	2022-12-01	3004102022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300410	2023-12-01	3004102023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2001-12-01	3004202001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2002-12-01	3004202002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2003-12-01	3004202003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2004-12-01	3004202004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2005-12-01	3004202005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2006-12-01	3004202006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2007-12-01	3004202007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2008-12-01	3004202008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2009-12-01	3004202009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2010-12-01	3004202010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2011-12-01	3004202011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2012-12-01	3004202012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2013-12-01	3004202013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2014-12-01	3004202014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2015-12-01	3004202015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2016-12-01	3004202016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2017-12-01	3004202017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300420	2018-12-01	3004202018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2006-12-01	3004302006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2007-12-01	3004302007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2008-12-01	3004302008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2009-12-01	3004302009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2010-12-01	3004302010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2011-12-01	3004302011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2012-12-01	3004302012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2013-12-01	3004302013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2014-12-01	3004302014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2015-12-01	3004302015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2016-12-01	3004302016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2017-12-01	3004302017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2018-12-01	3004302018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2019-12-01	3004302019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2020-12-01	3004302020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2021-12-01	3004302021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2022-12-01	3004302022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300430	2023-12-01	3004302023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2011-12-01	3004402011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2012-12-01	3004402012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2013-12-01	3004402013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2014-12-01	3004402014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2015-12-01	3004402015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2016-12-01	3004402016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2017-12-01	3004402017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2018-12-01	3004402018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2019-12-01	3004402019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2020-12-01	3004402020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2021-12-01	3004402021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2022-12-01	3004402022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300440	2023-12-01	3004402023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	1997-12-01	3004501997	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300450	1998-12-01	3004501998	1	99	99	99	99	0.5	1201998	99.0	99	0.0	1102008	KA
300450	1999-12-01	3004501999	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300450	2000-12-01	3004502000	1	99	99	99	99	0.7	99	99.0	99	0.0	1102008	KA
300450	2001-12-01	3004502001	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300450	2002-12-01	3004502002	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300450	2003-12-01	3004502003	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300450	2004-12-01	3004502004	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300450	2005-12-01	3004502005	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300450	2006-12-01	3004502006	1	99	99	99	99	99.0	99	99.0	99	0.0	1102008	KA
300450	2007-12-01	3004502007	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300450	2008-12-01	3004502008	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300450	2009-12-01	3004502009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2010-12-01	3004502010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2011-12-01	3004502011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2012-12-01	3004502012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2013-12-01	3004502013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2014-12-01	3004502014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2015-12-01	3004502015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2016-12-01	3004502016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2017-12-01	3004502017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2018-12-01	3004502018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2019-12-01	3004502019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2020-12-01	3004502020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2021-12-01	3004502021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2022-12-01	3004502022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300450	2023-12-01	3004502023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2008-12-01	3004602008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2009-12-01	3004602009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2010-12-01	3004602010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2011-12-01	3004602011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2012-12-01	3004602012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2013-12-01	3004602013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2014-12-01	3004602014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2015-12-01	3004602015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2016-12-01	3004602016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2017-12-01	3004602017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2018-12-01	3004602018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2019-12-01	3004602019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300460	2020-12-01	3004602020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300470	2021-12-01	3004702021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300470	2022-12-01	3004702022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300470	2023-12-01	3004702023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	1997-12-01	3004801997	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	1998-12-01	3004801998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	1999-12-01	3004801999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2000-12-01	3004802000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2001-12-01	3004802001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2002-12-01	3004802002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2003-12-01	3004802003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2004-12-01	3004802004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2005-12-01	3004802005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2006-12-01	3004802006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2007-12-01	3004802007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2008-12-01	3004802008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2009-12-01	3004802009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2010-12-01	3004802010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2011-12-01	3004802011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2012-12-01	3004802012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2013-12-01	3004802013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2014-12-01	3004802014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2015-12-01	3004802015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2016-12-01	3004802016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2017-12-01	3004802017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2018-12-01	3004802018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2019-12-01	3004802019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2020-12-01	3004802020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2021-12-01	3004802021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2022-12-01	3004802022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300480	2023-12-01	3004802023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	1998-12-01	3004901998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	1999-12-01	3004901999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2000-12-01	3004902000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2001-12-01	3004902001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2002-12-01	3004902002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2003-12-01	3004902003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2004-12-01	3004902004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2005-12-01	3004902005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2006-12-01	3004902006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2007-12-01	3004902007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2008-12-01	3004902008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2009-12-01	3004902009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2010-12-01	3004902010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2011-12-01	3004902011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2012-12-01	3004902012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2013-12-01	3004902013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2014-12-01	3004902014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2015-12-01	3004902015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2016-12-01	3004902016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2017-12-01	3004902017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2018-12-01	3004902018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2019-12-01	3004902019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2020-12-01	3004902020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2021-12-01	3004902021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2022-12-01	3004902022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300490	2023-12-01	3004902023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300491	2021-12-01	3004912021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300491	2022-12-01	3004912022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300491	2023-12-01	3004912023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300500	1993-12-01	3005001993	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300500	1994-12-01	3005001994	1	99	99	99	99	3.5	1201994	99.0	99	3.0	1102008	KA
300500	1995-12-01	3005001995	1	99	99	99	99	3.8	1201995	99.0	99	3.0	1102008	KA
300500	1996-12-01	3005001996	1	99	99	99	99	4.0	1201996	99.0	99	3.0	1102008	KA
300500	1997-12-01	3005001997	1	99	99	99	99	3.6	1201997	99.0	99	3.0	1102008	KA
300500	1998-12-01	3005001998	1	99	99	99	99	4.1	1201998	99.0	99	3.0	1102008	KA
300500	1999-12-01	3005001999	1	99	99	99	99	4.2	1201999	99.0	99	3.0	1102008	KA
300500	2000-12-01	3005002000	1	99	99	99	99	4.1	1202000	99.0	99	3.0	1102021	KA
300500	2001-12-01	3005002001	1	99	99	99	99	15.2	1102004	99.0	99	3.0	1102011	KA
300500	2002-12-01	3005002002	1	99	99	99	99	16.3	1102004	99.0	99	3.0	1102011	KA
300500	2003-12-01	3005002003	1	99	99	99	99	16.0	1102004	99.0	99	3.0	1102011	KA
300500	2004-12-01	3005002004	1	99	99	99	99	15.8	1102004	99.0	99	3.0	1102011	KA
300500	2005-12-01	3005002005	1	99	99	99	99	16.2	1102006	99.0	99	4.0	1102021	KA
300500	2006-12-01	3005002006	1	99	99	99	99	15.7	1102006	99.0	99	4.0	1102016	KA
300500	2007-12-01	3005002007	1	99	99	99	99	14.6	1102008	99.0	99	4.0	1102018	KA
300500	2008-12-01	3005002008	1	99	99	99	99	14.0	1102008	99.0	99	4.0	1102019	KA
300500	2009-12-01	3005002009	1	99	99	99	99	12.7	1102010	99.0	99	3.0	1102019	KA
300500	2010-12-01	3005002010	1	99	99	99	99	12.9	1102010	99.0	99	4.0	1102021	KA
300500	2011-12-01	3005002011	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300500	2012-12-01	3005002012	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300500	2013-12-01	3005002013	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300500	2014-12-01	3005002014	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300500	2015-12-01	3005002015	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300500	2016-12-01	3005002016	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300500	2017-12-01	3005002017	1	99	99	99	99	99.0	99	99.0	99	3.1	1102021	KA
300500	2018-12-01	3005002018	1	99	99	99	99	99.0	99	99.0	99	3.1	1102021	KA
300500	2019-12-01	3005002019	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300500	2020-12-01	3005002020	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300500	2021-12-01	3005002021	1	99	99	99	99	99.0	99	99.0	99	3.0	1102021	KA
300500	2022-12-01	3005002022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300500	2023-12-01	3005002023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300510	2022-12-01	3005102022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300510	2023-12-01	3005102023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300501	2014-12-01	3005012014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300501	2015-12-01	3005012015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300501	2016-12-01	3005012016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300501	2017-12-01	3005012017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300501	2018-12-01	3005012018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300501	2019-12-01	3005012019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300501	2020-12-01	3005012020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300501	2021-12-01	3005012021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300501	2022-12-01	3005012022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300501	2023-12-01	3005012023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2012-12-01	3005202012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2013-12-01	3005202013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2014-12-01	3005202014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2015-12-01	3005202015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2016-12-01	3005202016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2017-12-01	3005202017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2018-12-01	3005202018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2019-12-01	3005202019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2020-12-01	3005202020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2021-12-01	3005202021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2022-12-01	3005202022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300520	2023-12-01	3005202023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2012-12-01	3005302012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2013-12-01	3005302013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2014-12-01	3005302014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2015-12-01	3005302015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2016-12-01	3005302016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2017-12-01	3005302017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2018-12-01	3005302018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2019-12-01	3005302019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2020-12-01	3005302020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2021-12-01	3005302021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2022-12-01	3005302022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300530	2023-12-01	3005302023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300540	2019-12-01	3005402019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300540	2020-12-01	3005402020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300540	2021-12-01	3005402021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300540	2022-12-01	3005402022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300540	2023-12-01	3005402023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300550	2019-12-01	3005502019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300550	2020-12-01	3005502020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300550	2021-12-01	3005502021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300550	2022-12-01	3005502022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300550	2023-12-01	3005502023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300560	2022-12-01	3005602022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300560	2023-12-01	3005602023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300570	2016-12-01	3005702016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300570	2017-12-01	3005702017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300571	2018-12-01	3005712018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300571	2019-12-01	3005712019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300571	2020-12-01	3005712020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300571	2021-12-01	3005712021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300571	2022-12-01	3005712022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300571	2023-12-01	3005712023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300510	1993-12-01	3005101993	1	99	99	99	99	2.8	1201993	99.0	99	3.0	1102008	KA
300510	1994-12-01	3005101994	1	99	99	99	99	3.1	1201994	99.0	99	3.0	1102008	KA
300510	1995-12-01	3005101995	1	99	99	99	99	3.3	1201995	99.0	99	3.0	1102008	KA
300510	1996-12-01	3005101996	1	99	99	99	99	3.3	1201996	99.0	99	2.0	1102008	KA
300510	1997-12-01	3005101997	1	99	99	99	99	2.8	1201997	99.0	99	2.0	1102008	KA
300510	1998-12-01	3005101998	1	99	99	99	99	2.8	1201998	99.0	99	3.0	1102008	KA
300510	1999-12-01	3005101999	1	99	99	99	99	3.0	1201999	99.0	99	3.0	1102008	KA
300510	2000-12-01	3005102000	1	99	99	99	99	3.6	1202000	99.0	99	3.0	1102021	KA
300510	2001-12-01	3005102001	1	99	99	99	99	13.9	1102004	99.0	99	3.0	1102011	KA
300510	2002-12-01	3005102002	1	99	99	99	99	14.8	1102004	99.0	99	3.0	1102011	KA
300510	2003-12-01	3005102003	1	99	99	99	99	14.9	1102004	99.0	99	3.0	1102011	KA
300510	2004-12-01	3005102004	1	99	99	99	99	15.1	1102004	99.0	99	4.0	1102011	KA
300510	2005-12-01	3005102005	1	99	99	99	99	15.8	1102006	99.0	99	4.0	1102021	KA
300510	2006-12-01	3005102006	1	99	99	99	99	14.9	1102006	99.0	99	4.0	1102016	KA
300510	2007-12-01	3005102007	1	99	99	99	99	14.2	1102008	99.0	99	4.0	1102018	KA
300510	2008-12-01	3005102008	1	99	99	99	99	14.1	1102008	99.0	99	4.0	1102019	KA
300510	2009-12-01	3005102009	1	99	99	99	99	13.0	1102010	99.0	99	4.0	1102019	KA
300510	2010-12-01	3005102010	1	99	99	99	99	13.3	1102010	99.0	99	4.0	1102021	KA
300510	2011-12-01	3005102011	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300510	2012-12-01	3005102012	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300510	2013-12-01	3005102013	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300510	2014-12-01	3005102014	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300510	2015-12-01	3005102015	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300510	2016-12-01	3005102016	1	99	99	99	99	99.0	99	99.0	99	4.0	1102021	KA
300510	2017-12-01	3005102017	1	99	99	99	99	99.0	99	99.0	99	4.1	1102021	KA
300510	2018-12-01	3005102018	1	99	99	99	99	99.0	99	99.0	99	4.3	1102021	KA
300510	2019-12-01	3005102019	1	99	99	99	99	99.0	99	99.0	99	4.2	1102021	KA
300510	2020-12-01	3005102020	1	99	99	99	99	99.0	99	99.0	99	3.9	1102021	KA
300510	2021-12-01	3005102021	1	99	99	99	99	99.0	99	99.0	99	3.9	1102021	KA
300581	1993-12-01	3005811993	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	1994-12-01	3005811994	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	1995-12-01	3005811995	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	1996-12-01	3005811996	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	1997-12-01	3005811997	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	1998-12-01	3005811998	1	99	99	99	99	0.7	1201998	99.0	99	1.0	1102008	KA
300581	1999-12-01	3005811999	1	99	99	99	99	0.7	1201999	99.0	99	1.0	1102008	KA
300581	2000-12-01	3005812000	1	99	99	99	99	0.5	1202000	99.0	99	1.0	1102008	KA
300581	2001-12-01	3005812001	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	2002-12-01	3005812002	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	2003-12-01	3005812003	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	2004-12-01	3005812004	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	2005-12-01	3005812005	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	2006-12-01	3005812006	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	2007-12-01	3005812007	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	2008-12-01	3005812008	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300581	2009-12-01	3005812009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2010-12-01	3005822010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2011-12-01	3005822011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2012-12-01	3005822012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2013-12-01	3005822013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2014-12-01	3005822014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2015-12-01	3005822015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2016-12-01	3005822016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2017-12-01	3005822017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2018-12-01	3005822018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2019-12-01	3005822019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2020-12-01	3005822020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2021-12-01	3005822021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2022-12-01	3005822022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300582	2023-12-01	3005822023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	1993-12-01	3005901993	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	1994-12-01	3005901994	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	1995-12-01	3005901995	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	1996-12-01	3005901996	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	1997-12-01	3005901997	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	1998-12-01	3005901998	1	99	99	99	99	1.4	1201998	99.0	99	1.0	1102008	KA
300590	1999-12-01	3005901999	1	99	99	99	99	1.4	1201999	99.0	99	1.0	1102008	KA
300590	2000-12-01	3005902000	1	99	99	99	99	1.1	1202000	99.0	99	1.0	1102008	KA
300590	2001-12-01	3005902001	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	2002-12-01	3005902002	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	2003-12-01	3005902003	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	2004-12-01	3005902004	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	2005-12-01	3005902005	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	2006-12-01	3005902006	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	2007-12-01	3005902007	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	2008-12-01	3005902008	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300590	2009-12-01	3005902009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2010-12-01	3005902010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2011-12-01	3005902011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2012-12-01	3005902012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2013-12-01	3005902013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2014-12-01	3005902014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2015-12-01	3005902015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2016-12-01	3005902016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2017-12-01	3005902017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2018-12-01	3005902018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2019-12-01	3005902019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2020-12-01	3005902020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2021-12-01	3005902021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2022-12-01	3005902022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300590	2023-12-01	3005902023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	1993-12-01	3006001993	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300600	1994-12-01	3006001994	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300600	1995-12-01	3006001995	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300600	1996-12-01	3006001996	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300600	1997-12-01	3006001997	1	99	99	99	99	99.0	99	99.0	99	1.0	1102008	KA
300600	1998-12-01	3006001998	1	99	99	99	99	1.2	1201998	99.0	99	1.0	1102008	KA
300600	1999-12-01	3006001999	1	99	99	99	99	1.6	1201999	99.0	99	2.0	1102008	KA
300600	2000-12-01	3006002000	1	99	99	99	99	1.8	1202000	99.0	99	2.0	1102011	KA
300600	2001-12-01	3006002001	1	99	99	99	99	99.0	99	99.0	99	2.0	1102011	KA
300600	2002-12-01	3006002002	1	99	99	99	99	99.0	99	99.0	99	2.0	1102011	KA
300600	2003-12-01	3006002003	1	99	99	99	99	99.0	99	99.0	99	2.0	1102011	KA
300600	2004-12-01	3006002004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2005-12-01	3006002005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2006-12-01	3006002006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2007-12-01	3006002007	1	99	99	99	99	99.0	99	99.0	99	2.0	1102018	KA
300600	2008-12-01	3006002008	1	99	99	99	99	99.0	99	99.0	99	2.0	1102018	KA
300600	2009-12-01	3006002009	1	99	99	99	99	99.0	99	99.0	99	2.0	1102018	KA
300600	2010-12-01	3006002010	1	99	99	99	99	99.0	99	99.0	99	2.0	1102018	KA
300600	2011-12-01	3006002011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2012-12-01	3006002012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2013-12-01	3006002013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2014-12-01	3006002014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2015-12-01	3006002015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2016-12-01	3006002016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2017-12-01	3006002017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2018-12-01	3006002018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2019-12-01	3006002019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2020-12-01	3006002020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2021-12-01	3006002021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2022-12-01	3006002022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300600	2023-12-01	3006002023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2000-12-01	3006012000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2001-12-01	3006012001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2002-12-01	3006012002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2003-12-01	3006012003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2004-12-01	3006012004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2005-12-01	3006012005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2006-12-01	3006012006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2007-12-01	3006012007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2008-12-01	3006012008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2009-12-01	3006012009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2010-12-01	3006012010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2011-12-01	3006012011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2012-12-01	3006012012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2013-12-01	3006012013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300601	2014-12-01	3006012014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2007-12-01	3006402007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2008-12-01	3006402008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2009-12-01	3006402009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2010-12-01	3006402010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2011-12-01	3006402011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2012-12-01	3006402012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2013-12-01	3006402013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2014-12-01	3006402014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2015-12-01	3006402015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2016-12-01	3006402016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2017-12-01	3006402017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2018-12-01	3006402018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2019-12-01	3006402019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2020-12-01	3006402020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2021-12-01	3006402021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2022-12-01	3006402022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300640	2023-12-01	3006402023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300700	1999-12-01	3007001999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300700	2000-12-01	3007002000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2001-12-01	3007102001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2002-12-01	3007102002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2003-12-01	3007102003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2004-12-01	3007102004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2005-12-01	3007102005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2006-12-01	3007102006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2007-12-01	3007102007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2008-12-01	3007102008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2009-12-01	3007102009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2010-12-01	3007102010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2011-12-01	3007102011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2012-12-01	3007102012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2013-12-01	3007102013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2014-12-01	3007102014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2015-12-01	3007102015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2016-12-01	3007102016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2017-12-01	3007102017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2018-12-01	3007102018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2019-12-01	3007102019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2020-12-01	3007102020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2021-12-01	3007102021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300710	2022-12-01	3007102022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300720	2011-12-01	3007202011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300720	2012-12-01	3007202012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300730	2010-12-01	3007302010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300730	2011-12-01	3007302011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300730	2012-12-01	3007302012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2013-12-01	3007402013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2014-12-01	3007402014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2015-12-01	3007402015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2016-12-01	3007402016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2017-12-01	3007402017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2018-12-01	3007402018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2019-12-01	3007402019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2020-12-01	3007402020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2021-12-01	3007402021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2022-12-01	3007402022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300740	2023-12-01	3007402023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2005-12-01	3007412005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2006-12-01	3007412006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2007-12-01	3007412007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2008-12-01	3007412008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2009-12-01	3007412009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2010-12-01	3007412010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2011-12-01	3007412011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2012-12-01	3007412012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2013-12-01	3007412013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2014-12-01	3007412014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2015-12-01	3007412015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2016-12-01	3007412016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2017-12-01	3007412017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2018-12-01	3007412018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2019-12-01	3007412019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2020-12-01	3007412020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2021-12-01	3007412021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2022-12-01	3007412022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300741	2023-12-01	3007412023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	1999-12-01	3007421999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2000-12-01	3007422000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2001-12-01	3007422001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2002-12-01	3007422002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2003-12-01	3007422003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2004-12-01	3007422004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2005-12-01	3007422005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2006-12-01	3007422006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2007-12-01	3007422007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2008-12-01	3007422008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2009-12-01	3007422009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2010-12-01	3007422010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2011-12-01	3007422011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2012-12-01	3007422012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2013-12-01	3007422013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2014-12-01	3007422014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2015-12-01	3007422015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2016-12-01	3007422016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2017-12-01	3007422017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2018-12-01	3007422018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2019-12-01	3007422019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2020-12-01	3007422020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2021-12-01	3007422021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2022-12-01	3007422022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300742	2023-12-01	3007422023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2001-12-01	3007432001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2002-12-01	3007432002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2003-12-01	3007432003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2004-12-01	3007432004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2005-12-01	3007432005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2006-12-01	3007432006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2007-12-01	3007432007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2008-12-01	3007432008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2009-12-01	3007432009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2010-12-01	3007432010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2011-12-01	3007432011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2012-12-01	3007432012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2013-12-01	3007432013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2014-12-01	3007432014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2015-12-01	3007432015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2016-12-01	3007432016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2017-12-01	3007432017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2018-12-01	3007432018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2019-12-01	3007432019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2020-12-01	3007432020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300743	2021-12-01	3007432021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2001-12-01	3007442001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2002-12-01	3007442002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2003-12-01	3007442003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2004-12-01	3007442004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2005-12-01	3007442005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2006-12-01	3007442006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2007-12-01	3007442007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2008-12-01	3007442008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2009-12-01	3007442009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2010-12-01	3007442010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2011-12-01	3007442011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2012-12-01	3007442012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2013-12-01	3007442013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2014-12-01	3007442014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2015-12-01	3007442015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2016-12-01	3007442016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2017-12-01	3007442017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2018-12-01	3007442018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2019-12-01	3007442019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2020-12-01	3007442020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2021-12-01	3007442021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2022-12-01	3007442022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300744	2023-12-01	3007442023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2009-12-01	3007452009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2010-12-01	3007452010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2011-12-01	3007452011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2012-12-01	3007452012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2013-12-01	3007452013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2014-12-01	3007452014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2015-12-01	3007452015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2016-12-01	3007452016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2017-12-01	3007452017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2018-12-01	3007452018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2019-12-01	3007452019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2020-12-01	3007452020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2021-12-01	3007452021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2022-12-01	3007452022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300745	2023-12-01	3007452023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2011-12-01	3007462011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2012-12-01	3007462012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2013-12-01	3007462013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2014-12-01	3007462014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2015-12-01	3007462015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2016-12-01	3007462016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2017-12-01	3007462017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2018-12-01	3007462018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2019-12-01	3007462019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2020-12-01	3007462020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2021-12-01	3007462021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2022-12-01	3007462022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300746	2023-12-01	3007462023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	1997-12-01	3007471997	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	1998-12-01	3007471998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	1999-12-01	3007471999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2000-12-01	3007472000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2001-12-01	3007472001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2002-12-01	3007472002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2003-12-01	3007472003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2004-12-01	3007472004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2005-12-01	3007472005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2006-12-01	3007472006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2007-12-01	3007472007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2008-12-01	3007472008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2009-12-01	3007472009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2010-12-01	3007472010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2011-12-01	3007472011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2012-12-01	3007472012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300747	2013-12-01	3007472013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	1997-12-01	3007501997	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	1998-12-01	3007501998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	1999-12-01	3007501999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2000-12-01	3007502000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2001-12-01	3007502001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2002-12-01	3007502002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2003-12-01	3007502003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2004-12-01	3007502004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2005-12-01	3007502005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2006-12-01	3007502006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2007-12-01	3007502007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2008-12-01	3007502008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2009-12-01	3007502009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2010-12-01	3007502010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300750	2011-12-01	3007502011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2012-12-01	3007602012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2013-12-01	3007602013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2014-12-01	3007602014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2015-12-01	3007602015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2016-12-01	3007602016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2017-12-01	3007602017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2018-12-01	3007602018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2019-12-01	3007602019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2020-12-01	3007602020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2021-12-01	3007602021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2022-12-01	3007602022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300760	2023-12-01	3007602023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300780	2020-12-01	3007802020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300780	2021-12-01	3007802021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300780	2022-12-01	3007802022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300780	2023-12-01	3007802023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300781	2015-12-01	3007812015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300781	2016-12-01	3007812016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300781	2017-12-01	3007812017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300781	2018-12-01	3007812018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300781	2019-12-01	3007812019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300781	2020-12-01	3007812020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300781	2021-12-01	3007812021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300781	2022-12-01	3007812022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300781	2023-12-01	3007812023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300790	2016-12-01	3007902016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300790	2017-12-01	3007902017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300790	2018-12-01	3007902018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300790	2019-12-01	3007902019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300790	2020-12-01	3007902020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300790	2021-12-01	3007902021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300790	2022-12-01	3007902022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300790	2023-12-01	3007902023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2009-12-01	3008202009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2010-12-01	3008202010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2011-12-01	3008202011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2012-12-01	3008202012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2013-12-01	3008202013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2014-12-01	3008202014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2015-12-01	3008202015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2016-12-01	3008202016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2017-12-01	3008202017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2018-12-01	3008202018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2019-12-01	3008202019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2020-12-01	3008202020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2021-12-01	3008202021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2022-12-01	3008202022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300820	2023-12-01	3008202023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2009-12-01	3008212009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2010-12-01	3008212010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2011-12-01	3008212011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2012-12-01	3008212012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2013-12-01	3008212013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2014-12-01	3008212014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2015-12-01	3008212015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2016-12-01	3008212016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2017-12-01	3008212017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2018-12-01	3008212018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2019-12-01	3008212019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2020-12-01	3008212020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2021-12-01	3008212021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2022-12-01	3008212022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300821	2023-12-01	3008212023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300822	2002-12-01	3008222002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300822	2003-12-01	3008222003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300822	2004-12-01	3008222004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300822	2005-12-01	3008222005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300822	2006-12-01	3008222006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300822	2007-12-01	3008222007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300822	2008-12-01	3008222008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300822	2009-12-01	3008222009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
300970	2023-12-01	3009702023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2000-12-01	3017432000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2001-12-01	3017432001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2002-12-01	3017432002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2003-12-01	3017432003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2004-12-01	3017432004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2005-12-01	3017432005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2006-12-01	3017432006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2007-12-01	3017432007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2008-12-01	3017432008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2009-12-01	3017432009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2010-12-01	3017432010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2011-12-01	3017432011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2012-12-01	3017432012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2013-12-01	3017432013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2014-12-01	3017432014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2015-12-01	3017432015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2016-12-01	3017432016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2017-12-01	3017432017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2018-12-01	3017432018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2019-12-01	3017432019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2020-12-01	3017432020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2021-12-01	3017432021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2022-12-01	3017432022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301743	2023-12-01	3017432023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	1996-12-01	3017441996	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	1997-12-01	3017441997	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	1998-12-01	3017441998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	1999-12-01	3017441999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2000-12-01	3017442000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2001-12-01	3017442001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2002-12-01	3017442002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2003-12-01	3017442003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2004-12-01	3017442004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2005-12-01	3017442005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2006-12-01	3017442006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2007-12-01	3017442007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2008-12-01	3017442008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2009-12-01	3017442009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2010-12-01	3017442010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2011-12-01	3017442011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2012-12-01	3017442012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2013-12-01	3017442013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2014-12-01	3017442014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2015-12-01	3017442015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2016-12-01	3017442016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2017-12-01	3017442017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2018-12-01	3017442018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2019-12-01	3017442019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2020-12-01	3017442020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2021-12-01	3017442021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2022-12-01	3017442022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301744	2023-12-01	3017442023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	1995-12-01	3017461995	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	1996-12-01	3017461996	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	1997-12-01	3017461997	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	1998-12-01	3017461998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	1999-12-01	3017461999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	2000-12-01	3017462000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	2001-12-01	3017462001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	2002-12-01	3017462002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	2003-12-01	3017462003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	2004-12-01	3017462004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	2005-12-01	3017462005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	2006-12-01	3017462006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	2007-12-01	3017462007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	2008-12-01	3017462008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301746	2009-12-01	3017462009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301747	2014-12-01	3017472014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301747	2015-12-01	3017472015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301747	2016-12-01	3017472016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301747	2017-12-01	3017472017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301747	2018-12-01	3017472018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301747	2019-12-01	3017472019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301747	2020-12-01	3017472020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301747	2021-12-01	3017472021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301747	2022-12-01	3017472022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
301747	2023-12-01	3017472023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2010-12-01	3027432010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2011-12-01	3027432011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2012-12-01	3027432012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2013-12-01	3027432013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2014-12-01	3027432014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2015-12-01	3027432015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2016-12-01	3027432016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2017-12-01	3027432017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2018-12-01	3027432018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2019-12-01	3027432019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2020-12-01	3027432020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2021-12-01	3027432021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2022-12-01	3027432022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302743	2023-12-01	3027432023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302744	1997-12-01	3027441997	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302744	1998-12-01	3027441998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302744	1999-12-01	3027441999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302744	2000-12-01	3027442000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302747	2019-12-01	3027472019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302747	2020-12-01	3027472020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302747	2021-12-01	3027472021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302747	2022-12-01	3027472022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
302747	2023-12-01	3027472023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
303743	2022-12-01	3037432022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
303743	2023-12-01	3037432023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
320010	2013-12-01	3200102013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
320010	2014-12-01	3200102014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
320010	2015-12-01	3200102015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
320010	2016-12-01	3200102016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
320010	2017-12-01	3200102017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
320010	2018-12-01	3200102018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
320010	2019-12-01	3200102019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
320010	2020-12-01	3200102020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
320010	2021-12-01	3200102021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	1998-12-01	3500101998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	1999-12-01	3500101999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2000-12-01	3500102000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2001-12-01	3500102001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2002-12-01	3500102002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2003-12-01	3500102003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2004-12-01	3500102004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2005-12-01	3500102005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2006-12-01	3500102006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2007-12-01	3500102007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2008-12-01	3500102008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2009-12-01	3500102009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2010-12-01	3500102010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2011-12-01	3500102011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2012-12-01	3500102012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2013-12-01	3500102013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2014-12-01	3500102014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2015-12-01	3500102015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2016-12-01	3500102016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2017-12-01	3500102017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350010	2018-12-01	3500102018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350011	2019-12-01	3500112019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350011	2020-12-01	3500112020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350011	2021-12-01	3500112021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350011	2022-12-01	3500112022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350011	2023-12-01	3500112023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	1998-12-01	3500201998	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	1999-12-01	3500201999	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	2000-12-01	3500202000	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	2001-12-01	3500202001	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	2002-12-01	3500202002	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	2003-12-01	3500202003	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	2004-12-01	3500202004	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	2005-12-01	3500202005	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	2006-12-01	3500202006	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	2007-12-01	3500202007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350020	2008-12-01	3500202008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2009-12-01	3500212009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2010-12-01	3500212010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2011-12-01	3500212011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2012-12-01	3500212012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2013-12-01	3500212013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2014-12-01	3500212014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2015-12-01	3500212015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2016-12-01	3500212016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2017-12-01	3500212017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2018-12-01	3500212018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2019-12-01	3500212019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2020-12-01	3500212020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2021-12-01	3500212021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2022-12-01	3500212022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
350021	2023-12-01	3500212023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390980	2019-12-01	3909802019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390980	2020-12-01	3909802020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390980	2021-12-01	3909802021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390980	2022-12-01	3909802022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390980	2023-12-01	3909802023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2007-12-01	3909822007	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2008-12-01	3909822008	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2009-12-01	3909822009	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2010-12-01	3909822010	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2011-12-01	3909822011	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2012-12-01	3909822012	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2013-12-01	3909822013	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2014-12-01	3909822014	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2015-12-01	3909822015	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2016-12-01	3909822016	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2017-12-01	3909822017	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2018-12-01	3909822018	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2019-12-01	3909822019	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2020-12-01	3909822020	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2021-12-01	3909822021	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2022-12-01	3909822022	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
390982	2023-12-01	3909822023	1	99	99	99	99	99.0	99	99.0	99	99.0	99	KA
\.


--
-- Data for Name: nd_company; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3.nd_company (nd_id, name, legal_form, registry_id, jurisdiction, northdata_url, status, is_media_company, sector, region, scraped_at, created_at) FROM stdin;
\.


--
-- Data for Name: nd_crawl_log; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3.nd_crawl_log (id, url, company_name, slice_id, nodes_found, edges_found, svg_bytes, success, error_msg, duration_ms, crawled_at) FROM stdin;
1	https://www.northdata.de/Abendzeitung+M%C3%BCnchen+Verlags-GmbH%2C+M%C3%BCnchen/HRB+202573	\N	print-southern-de	0	0	0	f	No SVG returned	57521	2026-03-11 00:44:27.883082
2	https://www.northdata.de/S%C3%BCddeutsche+Zeitung+GmbH%2C+M%C3%BCnchen/HRB+73185	\N	print-southern-de	0	0	0	f	No SVG returned	56946	2026-03-11 00:45:27.868304
3	https://www.northdata.de/IPPEN%C2%B7MEDIA+GmbH+%26+Co%C2%B7+KG%2C+M%C3%BCnchen/HRB+204807	\N	print-southern-de	0	0	0	f	No SVG returned	57388	2026-03-11 00:46:28.287343
4	https://www.northdata.de/Mediengruppe+Pressedruck+GmbH+%26+Co%C2%B7+KG%2C+Augsburg/HRB+8002	\N	print-southern-de	0	0	0	f	No SVG returned	56982	2026-03-11 00:47:28.299509
5	https://www.northdata.de/Passauer+Neue+Presse+GmbH%2C+Passau/HRB+271	\N	print-southern-de	0	0	0	f	No SVG returned	56911	2026-03-11 00:48:28.242739
6	https://www.northdata.de/N%C3%BCrnberger+Nachrichten+GmbH%2C+N%C3%BCrnberg/HRB+5165	\N	print-southern-de	0	0	0	f	No SVG returned	56997	2026-03-11 00:49:28.274848
7	https://www.northdata.de/Cl%C2%B7+Attenkofer%27sche+Buch-+und+Kunstdruckerei+GmbH+%26+Co%C2%B7+KG%2C+Straubing/HRA+2022	\N	print-southern-de	0	0	0	f	No SVG returned	57052	2026-03-11 00:50:28.359989
8	https://www.northdata.de/Schw%C3%A4bisch+Media+GmbH+%26+Co%C2%B7+KG%2C+Ravensburg/HRA+1551	\N	print-southern-de	0	0	0	f	No SVG returned	57344	2026-03-11 00:51:28.710242
\.


--
-- Data for Name: nd_ownership; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3.nd_ownership (id, owner_company_id, owner_person_id, owned_company_id, share_pct, role, is_current, source_url, scraped_at) FROM stdin;
\.


--
-- Data for Name: nd_person; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3.nd_person (nd_id, full_name, scraped_at, created_at) FROM stdin;
\.


--
-- Data for Name: sources_names; Type: TABLE DATA; Schema: graphv3; Owner: postgres
--

COPY graphv3.sources_names (id_source, source_name) FROM stdin;
1702022	ORF-Bericht 2022
1702023	ORF-Bericht 2023
1702012	ORF-Bericht 2012
3042008	ÖWA 4. Quartal 2008
3042009	ÖWA 4. Quartal 2009
3042010	ÖWA 4. Quartal 2010
3042011	ÖWA 4. Quartal 2011
3042012	ÖWA 4. Quartal 2012
3042013	ÖWA 4. Quartal 2013
3042014	ÖWA 4. Quartal 2014
3042015	ÖWA 4. Quartal 2015
3042016	ÖWA 4. Quartal 2016
3042017	ÖWA 4. Quartal 2017
3042018	ÖWA 4. Quartal 2018
3042019	ÖWA 4. Quartal 2019
3002020	ÖWA Jahresbericht 2020
3002021	ÖWA Jahresbericht 2021
3002022	ÖWA Jahresbericht 2022
1102003	Statistik Austria: Kulturstatistik. BJ 2003
1102004	Statistik Austria: Kulturstatistik. BJ 2004
1102006	Statistik Austria: Kulturstatistik. BJ 2006
1102008	Statistik Austria: Kulturstatistik. BJ 2008_2009
1102010	Statistik Austria: Kulturstatistik. BJ 2010
1102011	Statistik Austria: Kulturstatistik. BJ 2011
1102016	Statistik Austria: Kulturstatistik. BJ 2016
1102018	Statistik Austria: Kulturstatistik. BJ 2018
1102019	Statistik Austria: Kulturstatistik. BJ 2019
1102021	Statistik Austria: Kulturstatistik. BJ 2021
1601993	Massenmedien in Österreich - Medienbericht Bd. 4 (1993)
1201993	Media-Analyse 1993
1201994	Media-Analyse 1994
1201995	Media-Analyse 1995
1201996	Media-Analyse 1996
1201997	Media-Analyse 1997
1201998	Media-Analyse 1998
1201999	Media-Analyse 1999
1202000	Media-Analyse 2000
1202001	Media-Analyse 2001
1202002	Media-Analyse 2002
1202003	Media-Analyse 2003
1202004	Media-Analyse 2004, zitiert nach derstandart.at, 23.03.2005
1202005	Media-Analyse 2005, zitiert nach derstandart.at, 29.03.2006
1202006	Media-Analyse 2006, zitiert nach derstandart.at, 27.03.2007
1202007	Media-Analyse 2007, zitiert nach derstandart.at, 28.03.2008
1202008	Media-Analyse 2008, zitiert nach derstandart.at, 01.04.2009
1502021	Österreichische Auflagenkontrolle Jahresbericht 2021
1502022	Österreichische Auflagenkontrolle Jahresbericht 2022
1502023	Österreichische Auflagenkontrolle Jahresbericht 2023
9802021	In Angabe zu "Dach", "Kombi" oder "Hauptausgabe inkludiert im Jahr 2021
9802022	In Angabe zu "Dach", "Kombi" oder "Hauptausgabe inkludiert im Jahr 2022
9802023	In Angabe zu "Dach", "Kombi" oder "Hauptausgabe inkludiert im Jahr 2023
2002021	TBA 2021
2002022	TBA 2022
2002023	TBA 2023
\.


--
-- Name: nd_crawl_log_id_seq; Type: SEQUENCE SET; Schema: graphv3; Owner: postgres
--

SELECT pg_catalog.setval('graphv3.nd_crawl_log_id_seq', 8, true);


--
-- Name: nd_ownership_id_seq; Type: SEQUENCE SET; Schema: graphv3; Owner: postgres
--

SELECT pg_catalog.setval('graphv3.nd_ownership_id_seq', 1, false);


--
-- Name: 11_succession 11_succession_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."11_succession"
    ADD CONSTRAINT "11_succession_pkey" PRIMARY KEY (id_mo, succession);


--
-- Name: 12_amalgamation 12_amalgamation_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."12_amalgamation"
    ADD CONSTRAINT "12_amalgamation_pkey" PRIMARY KEY (id_mo, amalgamation);


--
-- Name: 13_new_distribution_area 13_new_distribution_area_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."13_new_distribution_area"
    ADD CONSTRAINT "13_new_distribution_area_pkey" PRIMARY KEY (id_mo, new_distribution_area);


--
-- Name: 14_new_sector 14_new_sector_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."14_new_sector"
    ADD CONSTRAINT "14_new_sector_pkey" PRIMARY KEY (id_mo, new_sector);


--
-- Name: 19_interruption 19_interruption_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."19_interruption"
    ADD CONSTRAINT "19_interruption_pkey" PRIMARY KEY (id_mo, interruption);


--
-- Name: 21_split_off 21_split_off_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."21_split_off"
    ADD CONSTRAINT "21_split_off_pkey" PRIMARY KEY (id_mo, split_off);


--
-- Name: 22_offshoot 22_offshoot_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."22_offshoot"
    ADD CONSTRAINT "22_offshoot_pkey" PRIMARY KEY (id_mo, offshoot);


--
-- Name: 23_merger 23_merger_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."23_merger"
    ADD CONSTRAINT "23_merger_pkey" PRIMARY KEY (id_mo, merger);


--
-- Name: 31_main_media_outlet 31_main_media_outlet_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."31_main_media_outlet"
    ADD CONSTRAINT "31_main_media_outlet_pkey" PRIMARY KEY (id_mo, main_media_outlet);


--
-- Name: 33_umbrella 33_umbrella_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."33_umbrella"
    ADD CONSTRAINT "33_umbrella_pkey" PRIMARY KEY (id_mo, umbrella);


--
-- Name: 34_collaboration 34_collaboration_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."34_collaboration"
    ADD CONSTRAINT "34_collaboration_pkey" PRIMARY KEY (id_mo, collaboration);


--
-- Name: mo_constant mo_constant_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.mo_constant
    ADD CONSTRAINT mo_constant_pkey PRIMARY KEY (id_mo);


--
-- Name: mo_year mo_year11_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.mo_year
    ADD CONSTRAINT mo_year11_pkey PRIMARY KEY (mo_year);


--
-- Name: nd_company nd_company_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_company
    ADD CONSTRAINT nd_company_pkey PRIMARY KEY (nd_id);


--
-- Name: nd_crawl_log nd_crawl_log_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_crawl_log
    ADD CONSTRAINT nd_crawl_log_pkey PRIMARY KEY (id);


--
-- Name: nd_ownership nd_ownership_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_ownership
    ADD CONSTRAINT nd_ownership_pkey PRIMARY KEY (id);


--
-- Name: nd_person nd_person_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_person
    ADD CONSTRAINT nd_person_pkey PRIMARY KEY (nd_id);


--
-- Name: sources_names sources_names_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.sources_names
    ADD CONSTRAINT sources_names_pkey PRIMARY KEY (source_name);


--
-- PostgreSQL database dump complete
--

\unrestrict bFE5qkyyZVj22O9Tnae0bvkkDH9rcgCan5kjOKE6E6F5wew0f3vPiXKmDcc04d7

