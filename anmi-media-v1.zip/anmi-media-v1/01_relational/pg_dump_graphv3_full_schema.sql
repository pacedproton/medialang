--
-- PostgreSQL database dump
--

\restrict lo7yebtiaMkVmsmaYLsvwfgVM9F0dRzI7aaMTJQOZJ4fw6IiaXUCqRAuu30Fnfx

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: graphv3; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA graphv3;


ALTER SCHEMA graphv3 OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: 11_succession; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."11_succession" (
    id_mo numeric(6,0) NOT NULL,
    succession numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."11_succession" OWNER TO postgres;

--
-- Name: 12_amalgamation; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."12_amalgamation" (
    id_mo numeric(6,0) NOT NULL,
    amalgamation numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."12_amalgamation" OWNER TO postgres;

--
-- Name: 13_new_distribution_area; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."13_new_distribution_area" (
    id_mo numeric(6,0) NOT NULL,
    new_distribution_area numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."13_new_distribution_area" OWNER TO postgres;

--
-- Name: 14_new_sector; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."14_new_sector" (
    id_mo numeric(6,0) NOT NULL,
    new_sector numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."14_new_sector" OWNER TO postgres;

--
-- Name: 19_interruption; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."19_interruption" (
    id_mo numeric(6,0) NOT NULL,
    interruption numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."19_interruption" OWNER TO postgres;

--
-- Name: 21_split_off; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."21_split_off" (
    id_mo numeric(6,0) NOT NULL,
    split_off numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."21_split_off" OWNER TO postgres;

--
-- Name: 22_offshoot; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."22_offshoot" (
    id_mo numeric(6,0) NOT NULL,
    offshoot numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."22_offshoot" OWNER TO postgres;

--
-- Name: 23_merger; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."23_merger" (
    id_mo numeric(6,0) NOT NULL,
    merger numeric(6,0) NOT NULL
);


ALTER TABLE graphv3."23_merger" OWNER TO postgres;

--
-- Name: 31_main_media_outlet; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."31_main_media_outlet" (
    id_mo numeric(6,0) NOT NULL,
    main_media_outlet numeric(6,0) NOT NULL,
    start_rel date NOT NULL,
    end_rel date NOT NULL
);


ALTER TABLE graphv3."31_main_media_outlet" OWNER TO postgres;

--
-- Name: 33_umbrella; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."33_umbrella" (
    id_mo numeric(6,0) NOT NULL,
    umbrella numeric(6,0) NOT NULL,
    start_rel date NOT NULL,
    end_rel date NOT NULL
);


ALTER TABLE graphv3."33_umbrella" OWNER TO postgres;

--
-- Name: 34_collaboration; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3."34_collaboration" (
    id_mo numeric(6,0) NOT NULL,
    collaboration numeric(6,0) NOT NULL,
    start_rel date NOT NULL,
    end_rel date NOT NULL
);


ALTER TABLE graphv3."34_collaboration" OWNER TO postgres;

--
-- Name: mo_constant; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.mo_constant (
    id_mo numeric(6,0) NOT NULL,
    mo_title character varying(120) NOT NULL,
    id_sector numeric(2,0) NOT NULL,
    mandate numeric(2,0) NOT NULL,
    location character varying(25) NOT NULL,
    primary_distr_area numeric(2,0) NOT NULL,
    local numeric(1,0) NOT NULL,
    language character varying(25) NOT NULL,
    start_date date NOT NULL,
    start_fake_date numeric(1,0) NOT NULL,
    end_date date NOT NULL,
    end_fake_date numeric(1,0) NOT NULL,
    editorial_line_s character varying(1800) NOT NULL,
    editorial_line_e character varying(250) NOT NULL,
    comments character varying(1000) NOT NULL
);


ALTER TABLE graphv3.mo_constant OWNER TO postgres;

--
-- Name: mo_year; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.mo_year (
    id_mo numeric(6,0) NOT NULL,
    year date NOT NULL,
    mo_year numeric(10,0) NOT NULL,
    calc integer NOT NULL,
    circulation numeric(7,0) NOT NULL,
    circulation_source numeric(7,0) NOT NULL,
    unique_users numeric(8,0) NOT NULL,
    unique_users_source numeric(7,0) NOT NULL,
    reach_nat numeric(3,1) NOT NULL,
    reach_nat_source numeric(7,0) NOT NULL,
    reach_reg numeric(3,1) NOT NULL,
    reach_reg_source numeric(7,0) NOT NULL,
    market_share numeric(3,1) NOT NULL,
    market_share_source numeric(7,0) NOT NULL,
    comments character varying(1000) NOT NULL
);


ALTER TABLE graphv3.mo_year OWNER TO postgres;

--
-- Name: nd_company; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.nd_company (
    nd_id text NOT NULL,
    name character varying(300) NOT NULL,
    legal_form character varying(50),
    registry_id character varying(100),
    jurisdiction character varying(5) DEFAULT 'DE'::character varying NOT NULL,
    northdata_url text,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    is_media_company boolean DEFAULT false NOT NULL,
    sector character varying(50),
    region character varying(50),
    scraped_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE graphv3.nd_company OWNER TO postgres;

--
-- Name: nd_crawl_log; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.nd_crawl_log (
    id bigint NOT NULL,
    url text NOT NULL,
    company_name character varying(300),
    slice_id character varying(50),
    nodes_found integer DEFAULT 0 NOT NULL,
    edges_found integer DEFAULT 0 NOT NULL,
    svg_bytes integer DEFAULT 0 NOT NULL,
    success boolean DEFAULT false NOT NULL,
    error_msg text,
    duration_ms integer,
    crawled_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE graphv3.nd_crawl_log OWNER TO postgres;

--
-- Name: nd_crawl_log_id_seq; Type: SEQUENCE; Schema: graphv3; Owner: postgres
--

CREATE SEQUENCE graphv3.nd_crawl_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE graphv3.nd_crawl_log_id_seq OWNER TO postgres;

--
-- Name: nd_crawl_log_id_seq; Type: SEQUENCE OWNED BY; Schema: graphv3; Owner: postgres
--

ALTER SEQUENCE graphv3.nd_crawl_log_id_seq OWNED BY graphv3.nd_crawl_log.id;


--
-- Name: nd_ownership; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.nd_ownership (
    id bigint NOT NULL,
    owner_company_id text,
    owner_person_id text,
    owned_company_id text NOT NULL,
    share_pct real,
    role character varying(200),
    is_current boolean DEFAULT true NOT NULL,
    source_url text,
    scraped_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE graphv3.nd_ownership OWNER TO postgres;

--
-- Name: nd_ownership_id_seq; Type: SEQUENCE; Schema: graphv3; Owner: postgres
--

CREATE SEQUENCE graphv3.nd_ownership_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE graphv3.nd_ownership_id_seq OWNER TO postgres;

--
-- Name: nd_ownership_id_seq; Type: SEQUENCE OWNED BY; Schema: graphv3; Owner: postgres
--

ALTER SEQUENCE graphv3.nd_ownership_id_seq OWNED BY graphv3.nd_ownership.id;


--
-- Name: nd_person; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.nd_person (
    nd_id text NOT NULL,
    full_name character varying(200) NOT NULL,
    scraped_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE graphv3.nd_person OWNER TO postgres;

--
-- Name: sources_names; Type: TABLE; Schema: graphv3; Owner: postgres
--

CREATE TABLE graphv3.sources_names (
    id_source numeric(7,0) NOT NULL,
    source_name character varying(250) NOT NULL
);


ALTER TABLE graphv3.sources_names OWNER TO postgres;

--
-- Name: nd_crawl_log id; Type: DEFAULT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_crawl_log ALTER COLUMN id SET DEFAULT nextval('graphv3.nd_crawl_log_id_seq'::regclass);


--
-- Name: nd_ownership id; Type: DEFAULT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_ownership ALTER COLUMN id SET DEFAULT nextval('graphv3.nd_ownership_id_seq'::regclass);


--
-- Name: 11_succession 11_succession_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."11_succession"
    ADD CONSTRAINT "11_succession_pkey" PRIMARY KEY (id_mo, succession);


--
-- Name: 12_amalgamation 12_amalgamation_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."12_amalgamation"
    ADD CONSTRAINT "12_amalgamation_pkey" PRIMARY KEY (id_mo, amalgamation);


--
-- Name: 13_new_distribution_area 13_new_distribution_area_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."13_new_distribution_area"
    ADD CONSTRAINT "13_new_distribution_area_pkey" PRIMARY KEY (id_mo, new_distribution_area);


--
-- Name: 14_new_sector 14_new_sector_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."14_new_sector"
    ADD CONSTRAINT "14_new_sector_pkey" PRIMARY KEY (id_mo, new_sector);


--
-- Name: 19_interruption 19_interruption_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."19_interruption"
    ADD CONSTRAINT "19_interruption_pkey" PRIMARY KEY (id_mo, interruption);


--
-- Name: 21_split_off 21_split_off_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."21_split_off"
    ADD CONSTRAINT "21_split_off_pkey" PRIMARY KEY (id_mo, split_off);


--
-- Name: 22_offshoot 22_offshoot_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."22_offshoot"
    ADD CONSTRAINT "22_offshoot_pkey" PRIMARY KEY (id_mo, offshoot);


--
-- Name: 23_merger 23_merger_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."23_merger"
    ADD CONSTRAINT "23_merger_pkey" PRIMARY KEY (id_mo, merger);


--
-- Name: 31_main_media_outlet 31_main_media_outlet_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."31_main_media_outlet"
    ADD CONSTRAINT "31_main_media_outlet_pkey" PRIMARY KEY (id_mo, main_media_outlet);


--
-- Name: 33_umbrella 33_umbrella_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."33_umbrella"
    ADD CONSTRAINT "33_umbrella_pkey" PRIMARY KEY (id_mo, umbrella);


--
-- Name: 34_collaboration 34_collaboration_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3."34_collaboration"
    ADD CONSTRAINT "34_collaboration_pkey" PRIMARY KEY (id_mo, collaboration);


--
-- Name: mo_constant mo_constant_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.mo_constant
    ADD CONSTRAINT mo_constant_pkey PRIMARY KEY (id_mo);


--
-- Name: mo_year mo_year11_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.mo_year
    ADD CONSTRAINT mo_year11_pkey PRIMARY KEY (mo_year);


--
-- Name: nd_company nd_company_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_company
    ADD CONSTRAINT nd_company_pkey PRIMARY KEY (nd_id);


--
-- Name: nd_crawl_log nd_crawl_log_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_crawl_log
    ADD CONSTRAINT nd_crawl_log_pkey PRIMARY KEY (id);


--
-- Name: nd_ownership nd_ownership_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_ownership
    ADD CONSTRAINT nd_ownership_pkey PRIMARY KEY (id);


--
-- Name: nd_person nd_person_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.nd_person
    ADD CONSTRAINT nd_person_pkey PRIMARY KEY (nd_id);


--
-- Name: sources_names sources_names_pkey; Type: CONSTRAINT; Schema: graphv3; Owner: postgres
--

ALTER TABLE ONLY graphv3.sources_names
    ADD CONSTRAINT sources_names_pkey PRIMARY KEY (source_name);


--
-- PostgreSQL database dump complete
--

\unrestrict lo7yebtiaMkVmsmaYLsvwfgVM9F0dRzI7aaMTJQOZJ4fw6IiaXUCqRAuu30Fnfx

